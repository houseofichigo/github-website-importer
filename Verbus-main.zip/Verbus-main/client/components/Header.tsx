import { Link } from "react-router-dom";
import { useState } from "react";

export default function Header() {
  const [isVehiclesDropdownOpen, setIsVehiclesDropdownOpen] = useState(false);
  const [isServicesDropdownOpen, setIsServicesDropdownOpen] = useState(false);

  return (
    <header className="bg-white sticky top-0 z-50 border-b border-gray-100">
      <div className="max-w-[1920px] mx-auto px-8 py-8 flex items-center gap-6">
        {/* Logo */}
        <Link to="/" className="flex-shrink-0">
          <svg
            width="148"
            height="150"
            viewBox="0 0 148 150"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-[100px] h-[100px] lg:w-[148px] lg:h-[150px]"
          >
            <path
              d="M27.6192 121.115C-5.18817 88.4772 -5.18817 61.4699 27.6192 28.8839C60.4266 -3.75427 87.5739 -3.75427 120.329 28.8839C153.136 61.5221 153.136 88.5294 120.329 121.115C87.5215 153.754 60.3742 153.754 27.6192 121.115Z"
              fill="#51AD32"
            />
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M65.5623 42.9094C68.4971 45.412 70.8031 48.5924 72.3229 52.5549C73.4235 55.266 73.4235 57.143 72.7946 58.6028C61.5793 57.5079 57.5439 47.1326 56.0765 37.6435C59.745 38.9469 62.9419 40.6675 65.6147 42.9094M72.7422 47.6018C72.7422 46.4026 73.2663 44.3693 73.7903 43.5872C74.262 42.9094 74.8385 42.388 75.5722 42.0752C76.2535 41.8145 77.092 41.7624 77.9306 42.0231C79.7124 42.4923 81.7039 44.3171 81.7039 44.3171C76.2011 46.7676 80.8654 52.1899 77.1969 56.9866C76.568 57.8208 75.677 58.3943 74.5241 58.5507C74.9957 56.9344 74.8385 54.9011 73.6855 52.0335C72.0609 47.8103 69.6501 44.4735 66.5056 41.8145C63.4136 39.1555 59.6402 37.2264 55.2903 35.8708L54.085 35.5059L54.347 36.705C56.4433 47.1326 58.9065 57.7165 71.7988 59.9584C70.6983 61.1576 68.9688 61.9918 67.1869 62.9303C64.4093 64.2858 61.4221 65.7978 59.5878 68.6133C59.5878 68.6133 57.3343 71.6372 58.2252 75.7561C60.2691 69.3953 60.1643 69.1868 67.8158 64.2337C70.2266 63.0345 72.4802 61.9396 73.6855 60.1148C75.677 60.1148 77.2493 59.3328 78.245 57.8729C83.5382 50.1044 74.9433 44.9428 87.6785 44.9428H93.7578C93.7578 44.8906 83.2762 43.7957 83.2762 43.7957C83.2762 43.7957 80.7082 41.3453 78.4022 40.6675C77.1445 40.3025 75.8867 40.3547 74.8909 40.7196C73.8952 41.1367 73.0042 41.9709 72.5326 43.0137C71.694 44.9428 72.6374 47.6018 72.6374 47.6018H72.7422Z"
              fill="#E61B73"
            />
            <path
              d="M28.9289 101.565L21.9062 84.2549H26.5181L31.4445 97.1329L36.4757 84.2549H40.9303L33.8029 101.565H28.9289Z"
              fill="white"
            />
            <path
              d="M42.1885 101.565V84.2549H55.9194V87.9567H46.4859V91.0849H52.7225V94.6303H46.4859V97.9149H56.0242V101.617H42.1885V101.565Z"
              fill="white"
            />
            <path
              d="M58.5391 101.565V84.2549H67.4484C68.6538 84.2549 69.702 84.5156 70.6453 84.9848C71.5886 85.454 72.3223 86.1318 72.794 86.9139C73.3181 87.7481 73.5801 88.6866 73.5801 89.7815C73.5801 90.8764 73.2657 91.867 72.6892 92.7012C72.1127 93.5354 71.3266 94.2132 70.3308 94.6303L74.1566 101.565H69.3875L66.0858 95.2559H62.8365V101.565H58.5391ZM62.8365 91.8148H67.0816C67.7629 91.8148 68.2869 91.6584 68.7062 91.2935C69.1255 90.9285 69.3351 90.4593 69.3351 89.8857C69.3351 89.3122 69.1255 88.843 68.7062 88.478C68.2869 88.1131 67.7629 87.9567 67.0816 87.9567H62.8365V91.867V91.8148Z"
              fill="white"
            />
            <path
              d="M75.7812 101.565V84.2549H84.4286C85.6339 84.2549 86.6821 84.4634 87.573 84.8805C88.464 85.2976 89.1977 85.8711 89.7218 86.6011C90.2458 87.331 90.5079 88.1652 90.5079 89.1558C90.5079 90.1464 90.3507 90.5114 89.9838 91.137C89.6169 91.7627 89.1453 92.2841 88.5164 92.7012C89.3025 93.1183 89.9314 93.6397 90.3506 94.3174C90.8223 94.9952 91.032 95.7252 91.032 96.5072C91.032 97.2893 90.7699 98.3842 90.2458 99.1662C89.7218 99.9483 88.988 100.522 88.0971 100.939C87.1538 101.356 86.1056 101.565 84.8478 101.565H75.7812ZM80.0263 91.137H84.1141C84.743 91.137 85.2147 90.9806 85.5815 90.6678C85.9484 90.355 86.1056 89.9379 86.1056 89.4165C86.1056 88.8951 85.9484 88.478 85.5815 88.1652C85.2147 87.8524 84.743 87.696 84.1141 87.696H80.0263V91.0849V91.137ZM80.0263 98.0714H84.481C85.1623 98.0714 85.6863 97.9149 86.0532 97.6021C86.4201 97.2893 86.6297 96.8201 86.6297 96.2465C86.6297 95.673 86.4201 95.2559 86.0532 94.891C85.6863 94.5781 85.1623 94.4217 84.481 94.4217H80.0263V98.0714Z"
              fill="white"
            />
            <path
              d="M100.937 101.825C99.3127 101.825 97.9501 101.512 96.7447 100.886C95.5393 100.261 94.6484 99.3744 94.0195 98.1753C93.3906 97.0282 93.0762 95.6205 93.0762 94.0564V84.3066H97.3736V94.0564C97.3736 94.8384 97.5308 95.5162 97.8453 96.0897C98.1597 96.6633 98.579 97.1325 99.1031 97.4453C99.6796 97.7581 100.308 97.9146 101.042 97.9146C101.776 97.9146 102.405 97.7581 102.981 97.4453C103.505 97.1325 103.925 96.6633 104.239 96.0897C104.554 95.5162 104.711 94.8384 104.711 94.0564V84.3066H109.008V94.0564C109.008 95.6205 108.694 96.9761 108.012 98.1753C107.384 99.3223 106.44 100.261 105.235 100.886C104.029 101.512 102.667 101.825 101.042 101.825H100.937Z"
              fill="white"
            />
            <path
              d="M117.918 101.825C116.503 101.825 115.14 101.564 113.725 101.043C112.363 100.521 111.105 99.8436 110.057 98.9051L112.467 95.829C113.516 96.6632 114.511 97.2889 115.402 97.6538C116.293 98.0188 117.237 98.2273 118.285 98.2273C119.333 98.2273 119.49 98.1752 119.962 98.0188C120.433 97.8624 120.8 97.706 121.01 97.4453C121.272 97.1846 121.377 96.8718 121.377 96.5589C121.377 96.2461 121.22 95.7247 120.853 95.464C120.486 95.2034 119.857 94.9948 118.966 94.8384L115.14 94.1606C113.725 93.8999 112.625 93.3785 111.891 92.5443C111.105 91.7101 110.738 90.6674 110.738 89.4161C110.738 88.1648 111 87.3306 111.576 86.5485C112.153 85.7664 112.991 85.1408 114.04 84.6715C115.088 84.2544 116.398 84.0459 117.865 84.0459C119.333 84.0459 120.433 84.2545 121.744 84.7237C123.054 85.1408 124.207 85.7664 125.15 86.5485L122.897 89.6768C121.115 88.3212 119.333 87.6434 117.551 87.6434C115.769 87.6434 116.45 87.6955 116.031 87.8519C115.612 88.0084 115.297 88.1648 115.088 88.3733C114.878 88.5819 114.773 88.8426 114.773 89.1554C114.773 89.4682 114.931 89.9375 115.245 90.146C115.559 90.3546 116.084 90.5631 116.817 90.6674L120.433 91.2409C122.11 91.5016 123.368 92.0751 124.259 92.9093C125.15 93.7435 125.569 94.8384 125.569 96.194C125.569 97.5495 125.255 98.3838 124.626 99.218C123.997 100.052 123.159 100.73 122.006 101.199C120.853 101.668 119.49 101.877 117.918 101.877V101.825Z"
              fill="white"
            />
          </svg>
        </Link>

        {/* Navigation */}
        <nav className="hidden lg:flex items-center gap-2 flex-1 justify-end">
          {/* Nos Services with Dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setIsServicesDropdownOpen(true)}
            onMouseLeave={() => setIsServicesDropdownOpen(false)}
          >
            <Link
              to="/services"
              className="px-3 py-2 rounded-lg text-sm font-normal text-verbus-dark hover:bg-gray-100 transition-colors flex items-center gap-1"
            >
              nos services
              <svg
                className={`w-4 h-4 transition-transform ${
                  isServicesDropdownOpen ? "rotate-180" : ""
                }`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M19 9l-7 7-7-7"
                />
              </svg>
            </Link>

            {/* Dropdown Menu */}
            {isServicesDropdownOpen && (
              <div className="absolute top-full left-0 mt-1 w-56 bg-white rounded-lg shadow-lg border border-gray-100 py-2 z-50">
                <Link
                  to="/groupes-scolaires"
                  className="block px-4 py-2 text-sm text-verbus-dark hover:bg-gray-50 transition-colors"
                >
                  Groupes Scolaires
                </Link>
                <Link
                  to="/evenements-professionnels"
                  className="block px-4 py-2 text-sm text-verbus-dark hover:bg-gray-50 transition-colors"
                >
                  Événements Professionnels
                </Link>
                <Link
                  to="/tourisme"
                  className="block px-4 py-2 text-sm text-verbus-dark hover:bg-gray-50 transition-colors"
                >
                  Tourisme
                </Link>
                <Link
                  to="/sport-loisirs"
                  className="block px-4 py-2 text-sm text-verbus-dark hover:bg-gray-50 transition-colors"
                >
                  Sport & Loisirs
                </Link>
              </div>
            )}
          </div>

          {/* Nos Véhicules with Dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setIsVehiclesDropdownOpen(true)}
            onMouseLeave={() => setIsVehiclesDropdownOpen(false)}
          >
            <Link
              to="/vehicules"
              className="px-3 py-2 rounded-lg text-sm font-normal text-verbus-dark hover:bg-gray-100 transition-colors flex items-center gap-1"
            >
              nos véhicules
              <svg
                className={`w-4 h-4 transition-transform ${
                  isVehiclesDropdownOpen ? "rotate-180" : ""
                }`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M19 9l-7 7-7-7"
                />
              </svg>
            </Link>

            {/* Dropdown Menu */}
            {isVehiclesDropdownOpen && (
              <div className="absolute top-full left-0 mt-1 w-48 bg-white rounded-lg shadow-lg border border-gray-100 py-2 z-50">
                <Link
                  to="/classe-access"
                  className="block px-4 py-2 text-sm text-verbus-dark hover:bg-gray-50 transition-colors"
                >
                  Classe ACCESS
                </Link>
                <Link
                  to="/classe-eco"
                  className="block px-4 py-2 text-sm text-verbus-dark hover:bg-gray-50 transition-colors"
                >
                  Classe ECO
                </Link>
                <Link
                  to="/classe-confort"
                  className="block px-4 py-2 text-sm text-verbus-dark hover:bg-gray-50 transition-colors"
                >
                  Classe CONFORT
                </Link>
                <Link
                  to="/classe-star"
                  className="block px-4 py-2 text-sm text-verbus-dark hover:bg-gray-50 transition-colors"
                >
                  Classe STAR
                </Link>
              </div>
            )}
          </div>

          <Link
            to="/nos-sorties-du-moment"
            className="px-3 py-2 rounded-lg text-sm font-normal text-verbus-dark hover:bg-gray-100 transition-colors"
          >
            nos sorties du moment
          </Link>

          <Link
            to="/pourquoi-verbus"
            className="px-3 py-2 rounded-lg text-sm font-normal text-verbus-dark hover:bg-gray-100 transition-colors"
          >
            pourquoi VERBUS
          </Link>
          <Link
            to="/mode-vert"
            className="px-3 py-2 rounded-lg text-sm font-normal text-verbus-dark hover:bg-gray-100 transition-colors"
          >
            mode vert
          </Link>
          <Link
            to="/contact"
            className="px-3 py-2 rounded-lg text-sm font-normal text-verbus-dark hover:bg-gray-100 transition-colors"
          >
            contact
          </Link>
        </nav>

        {/* CTA Button */}
        <Link
          to="/devis"
          className="px-4 py-2 rounded-full bg-[#51AD32] text-white text-sm font-normal hover:bg-[#51AD32]/90 transition-colors whitespace-nowrap"
        >
          demander un devis
        </Link>

        {/* Mobile Menu Button */}
        <button className="lg:hidden p-2">
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <line x1="3" y1="12" x2="21" y2="12" />
            <line x1="3" y1="6" x2="21" y2="6" />
            <line x1="3" y1="18" x2="21" y2="18" />
          </svg>
        </button>
      </div>
    </header>
  );
}
