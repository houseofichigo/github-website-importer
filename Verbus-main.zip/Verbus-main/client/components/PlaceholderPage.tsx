import { Link } from "react-router-dom";
import Layout from "./Layout";

interface PlaceholderPageProps {
  title: string;
  description?: string;
}

export default function PlaceholderPage({ title, description }: PlaceholderPageProps) {
  return (
    <Layout>
      <div className="min-h-screen flex items-center justify-center bg-verbus-gray py-20">
        <div className="text-center max-w-2xl mx-auto px-8">
          <div className="mb-8">
            <svg width="148" height="150" viewBox="0 0 148 150" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-32 h-32 mx-auto opacity-20">
              <path d="M27.6192 121.115C-5.18817 88.4772 -5.18817 61.4699 27.6192 28.8839C60.4266 -3.75427 87.5739 -3.75427 120.329 28.8839C153.136 61.5221 153.136 88.5294 120.329 121.115C87.5215 153.754 60.3742 153.754 27.6192 121.115Z" fill="#51AD32"/>
              <path fillRule="evenodd" clipRule="evenodd" d="M65.5623 42.9094C68.4971 45.412 70.8031 48.5924 72.3229 52.5549C73.4235 55.266 73.4235 57.143 72.7946 58.6028C61.5793 57.5079 57.5439 47.1326 56.0765 37.6435C59.745 38.9469 62.9419 40.6675 65.6147 42.9094M72.7422 47.6018C72.7422 46.4026 73.2663 44.3693 73.7903 43.5872C74.262 42.9094 74.8385 42.388 75.5722 42.0752C76.2535 41.8145 77.092 41.7624 77.9306 42.0231C79.7124 42.4923 81.7039 44.3171 81.7039 44.3171C76.2011 46.7676 80.8654 52.1899 77.1969 56.9866C76.568 57.8208 75.677 58.3943 74.5241 58.5507C74.9957 56.9344 74.8385 54.9011 73.6855 52.0335C72.0609 47.8103 69.6501 44.4735 66.5056 41.8145C63.4136 39.1555 59.6402 37.2264 55.2903 35.8708L54.085 35.5059L54.347 36.705C56.4433 47.1326 58.9065 57.7165 71.7988 59.9584C70.6983 61.1576 68.9688 61.9918 67.1869 62.9303C64.4093 64.2858 61.4221 65.7978 59.5878 68.6133C59.5878 68.6133 57.3343 71.6372 58.2252 75.7561C60.2691 69.3953 60.1643 69.1868 67.8158 64.2337C70.2266 63.0345 72.4802 61.9396 73.6855 60.1148C75.677 60.1148 77.2493 59.3328 78.245 57.8729C83.5382 50.1044 74.9433 44.9428 87.6785 44.9428H93.7578C93.7578 44.8906 83.2762 43.7957 83.2762 43.7957C83.2762 43.7957 80.7082 41.3453 78.4022 40.6675C77.1445 40.3025 75.8867 40.3547 74.8909 40.7196C73.8952 41.1367 73.0042 41.9709 72.5326 43.0137C71.694 44.9428 72.6374 47.6018 72.6374 47.6018H72.7422Z" fill="#E61B73"/>
            </svg>
          </div>
          
          <h1 className="text-5xl font-bold text-verbus-dark mb-6">{title}</h1>
          
          {description && (
            <p className="text-xl text-verbus-dark mb-8">{description}</p>
          )}
          
          <p className="text-lg text-gray-600 mb-8">
            Cette page est en cours de construction. Nous travaillons activement à créer un contenu de qualité pour vous offrir la meilleure expérience possible.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/"
              className="px-6 py-3 rounded-full bg-verbus-green text-white font-normal text-base hover:bg-verbus-green/90 transition-colors"
            >
              Retour à l'accueil
            </Link>
            <Link
              to="/contact"
              className="px-6 py-3 rounded-full border-2 border-verbus-green text-verbus-green font-normal text-base hover:bg-verbus-green hover:text-white transition-colors"
            >
              Nous contacter
            </Link>
          </div>
        </div>
      </div>
    </Layout>
  );
}
