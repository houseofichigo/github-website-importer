export default function Services() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative h-[926px] overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/1bf925bcd32ff528a7989ce399843845143a2bb3?width=4456"
            alt="Transport VERBUS"
            className="w-full h-full object-cover rounded-[40px]"
          />
        </div>

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#63595A] via-[#63595A]/80 to-transparent rounded-[40px]" />

        {/* Decorative SVG - Top Left Curve */}
        <div className="absolute -left-[111px] top-[1573px]">
          <svg
            width="526"
            height="516"
            viewBox="0 0 526 516"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M52.0339 343.495C31.8759 331.377 13.3997 315.901 0.521601 296.039C-11.3276 277.768 -17.5896 256.614 -18.7181 234.94C-19.4372 221.253 -18.2313 207.533 -15.8194 194.067C-15.8194 194.023 -20.0568 193.88 -20.2338 194.819C-24.3605 217.873 -24.8805 241.866 -18.4857 264.567C-12.5446 285.633 -0.684343 304.39 14.9928 319.602C24.8616 329.179 36.0359 337.342 47.8076 344.423C48.4382 344.799 49.8986 344.357 50.5624 344.214C50.7616 344.169 52.3879 343.727 52.0228 343.518L52.0339 343.495Z"
              fill="#E72475"
            />
            <path
              d="M53.4832 343.617C60.9069 349.748 69.105 354.807 78.1329 358.232C88.2894 362.087 99.1981 363.7 110.04 363.689C133.119 363.667 156.441 360.209 178.679 354.167C198.35 348.831 217.391 341.33 235.347 331.687C250.958 323.291 265.761 313.404 279.303 301.96C290.389 292.582 300.744 282.231 309.584 270.687C310.525 269.461 311.443 268.213 312.35 266.953C313.999 264.667 310.171 263.054 308.799 264.965C300.755 276.155 291.219 286.285 280.94 295.454C268.372 306.666 254.543 316.475 239.961 324.893C222.967 334.691 204.823 342.512 186.081 348.279C165.005 354.763 143.065 358.574 121.049 359.712C109.786 360.298 98.5564 360.154 87.5813 357.249C78.4095 354.818 69.8684 350.654 62.157 345.153C60.3869 343.882 58.672 342.546 56.9903 341.154C56.1163 340.425 54.8108 340.347 53.8704 341.032C53.0959 341.596 52.6091 342.877 53.4942 343.606L53.4832 343.617Z"
              fill="#E72475"
            />
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M373.786 201.391C388.689 213.929 400.361 229.881 408.117 249.986L408.15 250.052C413.748 263.717 413.903 273.272 410.672 280.53C354.071 275.36 333.293 222.999 325.549 175.012C343.981 181.375 360.233 189.991 373.786 201.391ZM409.964 224.987C410.02 219.044 412.509 208.605 415.043 204.573C417.277 201.038 420.32 198.398 423.894 196.962C427.445 195.526 431.505 195.448 435.909 196.509C444.914 198.696 455.115 207.876 455.115 207.876C427.434 220.358 451.088 247.776 432.8 272.167C429.58 276.464 425.199 279.237 419.435 280.264C421.791 272.134 420.873 261.651 415.021 247.334C406.789 226.003 394.387 209.069 378.544 195.736C362.778 182.468 343.649 172.825 321.876 166.02L315.868 164.142L317.152 170.295C328.138 223.142 340.883 276.564 406.081 287.423C400.461 293.576 391.931 297.906 382.847 302.512C368.985 309.538 353.993 317.138 344.6 331.554C344.6 331.554 333.382 346.986 338.095 367.787C348.119 335.454 347.554 334.415 386.189 309.129C398.292 302.998 409.555 297.287 415.717 288.141C425.819 287.82 433.74 284.042 438.697 276.597C465.072 236.984 421.637 211.168 485.872 210.726L516.54 210.118L463.546 205.158C463.546 205.158 450.491 192.775 438.907 189.605C432.523 187.848 426.117 188.08 421.094 190.091C416.094 192.112 411.591 196.431 409.29 201.734C405.063 211.477 409.942 224.998 409.942 224.998L409.964 224.987Z"
              fill="#E72475"
            />
            <path
              d="M-97.9561 267.362C-89.946 221.673 -51.522 190.212 -12.1133 197.105C27.2954 203.987 42.1096 246.406 44.7427 292.294C45.9597 313.471 56.8353 465.859 214.437 419.883C214.437 419.883 239.297 411.465 260.816 416.768C300.324 426.489 313.7 499.695 313.7 499.695"
              stroke="#57AD32"
              strokeWidth="15.36"
              strokeMiterlimit="10"
              strokeLinecap="square"
            />
          </svg>
        </div>

        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-8 h-full flex flex-col justify-center">
          <div className="max-w-[549px] space-y-8">
            <h1 className="text-white font-bold text-[40px] leading-[100%]">
              Des solutions de transport pensées pour vos groupes
            </h1>

            <p className="text-white text-base leading-tight">
              Depuis près de 60 ans, VERBUS accompagne les déplacements de
              groupes en proposant des solutions de location d'autocar avec
              conducteur, adaptées aux territoires, aux usages et aux
              contraintes de chaque projet.
              <br />
              <br />
              <span className="font-bold">
                Écoles, entreprises, associations, clubs ou organisateurs
                d'événements :{" "}
              </span>
              nos équipes vous accompagnent de la demande de devis jusqu'au
              retour, avec un même objectif : faire simple, sûr et fiable.
            </p>

            <button className="bg-verbus-green text-white px-6 py-3 rounded-full text-base hover:bg-verbus-green/90 transition-colors">
              demander un devis
            </button>
          </div>
        </div>
      </section>

      {/* Ce qui guide VERBUS Section */}
      <section className="bg-[#FAFAFC] py-24 px-8 relative overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-center text-[40px] font-bold uppercase leading-[45px] text-verbus-dark mb-16">
            Ce qui guide VERBUS
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
            {/* Feature 1 - Connaissance fine */}
            <div className="text-center space-y-6">
              <div className="flex justify-center">
                <svg
                  width="107"
                  height="107"
                  viewBox="0 0 107 107"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M93.625 44.5835C93.625 75.7918 53.5 102.542 53.5 102.542C53.5 102.542 13.375 75.7918 13.375 44.5835C13.375 33.9417 17.6024 23.7357 25.1273 16.2108C32.6522 8.68594 42.8582 4.4585 53.5 4.4585C64.1418 4.4585 74.3478 8.68594 81.8727 16.2108C89.3976 23.7357 93.625 33.9417 93.625 44.5835Z"
                    stroke="#51AD32"
                    strokeWidth="4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M53.5 57.9585C60.8868 57.9585 66.875 51.9703 66.875 44.5835C66.875 37.1967 60.8868 31.2085 53.5 31.2085C46.1132 31.2085 40.125 37.1967 40.125 44.5835C40.125 51.9703 46.1132 57.9585 53.5 57.9585Z"
                    stroke="#51AD32"
                    strokeWidth="4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <h3 className="text-[30px] font-bold leading-[35px] text-verbus-dark">
                Connaissance fine <br />
                des territoires
              </h3>
            </div>

            {/* Feature 2 - Sécurité */}
            <div className="text-center space-y-6">
              <div className="flex justify-center">
                <svg
                  width="103"
                  height="103"
                  viewBox="0 0 103 103"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M51.5 5.15089C51.5 5.15089 30.5 12.9509 30.5 12.9509C30.5 12.9509 30.5 38.6759 30.5 38.6759C30.5 55.7547 40.625 71.4797 55.25 79.3297L51.5 81.3509L47.75 79.3297C33.125 71.4797 23 55.7547 23 38.6759V12.9509L51.5 5.15089Z"
                    stroke="#51AD32"
                    strokeWidth="4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M51.5 5.15089V81.3509M72.5 12.9509L51.5 5.15089L72.5 12.9509ZM72.5 12.9509V38.6759C72.5 55.7547 62.375 71.4797 47.75 79.3297L51.5 81.3509L72.5 12.9509Z"
                    stroke="#51AD32"
                    strokeWidth="4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <h3 className="text-[30px] font-bold leading-[35px] text-verbus-dark">
                Sécurité travaillée <br />
                au quotidien
              </h3>
            </div>

            {/* Feature 3 - Accompagnement humain */}
            <div className="text-center space-y-6">
              <div className="flex justify-center">
                <svg
                  width="107"
                  height="107"
                  viewBox="0 0 107 107"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M35.6667 93.625V80.25C35.6667 73.3486 38.4092 66.7296 43.3476 61.7912C48.286 56.8527 54.905 54.1102 61.8063 54.1102H80.25C87.1514 54.1102 93.7704 56.8527 98.7088 61.7912C103.647 66.7296 106.39 73.3486 106.39 80.25V93.625M80.25 27.3602C80.25 34.2615 77.5075 40.8805 72.5691 45.819C67.6306 50.7574 61.0116 53.4999 54.1103 53.4999C47.209 53.4999 40.59 50.7574 35.6516 45.819C30.7131 40.8805 27.9707 34.2615 27.9707 27.3602C27.9707 20.4588 30.7131 13.8398 35.6516 8.90137C40.59 3.96295 47.209 1.2205 54.1103 1.2205C61.0116 1.2205 67.6306 3.96295 72.5691 8.90137C77.5075 13.8398 80.25 20.4588 80.25 27.3602ZM26.75 93.625V80.25C26.7361 74.8208 28.3633 69.5105 31.4167 65.0268C34.47 60.5432 38.8198 57.0826 43.9167 55.0768M17.8333 1.83133C12.7479 3.84516 8.41199 7.30673 5.36889 11.7825C2.32579 16.2583 0.700195 21.5568 0.700195 26.9748C0.700195 32.3928 2.32579 37.6913 5.36889 42.1671C8.41199 46.6429 12.7479 50.1045 17.8333 52.1183"
                    stroke="#51AD32"
                    strokeWidth="4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <h3 className="text-[30px] font-bold leading-[35px] text-verbus-dark">
                Accompagnement humain <br />
                du début à la fin
              </h3>
            </div>

            {/* Feature 4 - Solutions adaptées */}
            <div className="text-center space-y-6">
              <div className="flex justify-center">
                <svg
                  width="130"
                  height="134"
                  viewBox="0 0 130 134"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clipPath="url(#clip0_126_690)">
                    <path
                      d="M65.3585 19.9804C66.4036 19.9804 67.2517 19.1287 67.2517 18.0794V1.90096C67.2517 0.851631 66.4036 0 65.3585 0C64.3135 0 63.4653 0.851631 63.4653 1.90096V18.0794C63.4653 19.1287 64.3135 19.9804 65.3585 19.9804Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M30.6851 32.9906C31.0537 33.3606 31.5383 33.5482 32.023 33.5482C32.5076 33.5482 32.9923 33.3632 33.3608 32.9906C34.1005 32.2479 34.1005 31.044 33.3608 30.3014L21.9688 18.8626C21.2292 18.12 20.0302 18.12 19.2905 18.8626C18.5509 19.6053 18.5509 20.8092 19.2905 21.5519L30.6826 32.9906H30.6851Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M19.8988 64.9063C19.8988 63.857 19.0507 63.0054 18.0056 63.0054H1.8932C0.848155 63.0054 0 63.857 0 64.9063C0 65.9557 0.848155 66.8073 1.8932 66.8073H18.0056C19.0507 66.8073 19.8988 65.9557 19.8988 64.9063Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M30.1778 97.035L18.7832 108.474C18.0436 109.216 18.0436 110.42 18.7832 111.163C19.1518 111.533 19.6364 111.721 20.1211 111.721C20.6057 111.721 21.0904 111.536 21.459 111.163L32.8535 99.7242C33.5931 98.9816 33.5931 97.7777 32.8535 97.035C32.1139 96.2924 30.9149 96.2924 30.1753 97.035H30.1778Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M99.315 97.5423C98.5754 96.7997 97.3764 96.7997 96.6367 97.5423C95.8971 98.285 95.8971 99.4889 96.6367 100.232L108.029 111.67C108.397 112.04 108.882 112.228 109.367 112.228C109.851 112.228 110.336 112.043 110.705 111.67C111.444 110.928 111.444 109.724 110.705 108.981L99.3125 97.5423H99.315Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M128.107 63.7251H111.994C110.949 63.7251 110.101 64.5767 110.101 65.6261C110.101 66.6754 110.949 67.527 111.994 67.527H128.107C129.152 67.527 130 66.6754 130 65.6261C130 64.5767 129.152 63.7251 128.107 63.7251Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M98.4845 34.055C98.9691 34.055 99.4538 33.87 99.8223 33.4974L111.214 22.0587C111.954 21.3161 111.954 20.1121 111.214 19.3695C110.475 18.6268 109.276 18.6268 108.536 19.3695L97.1441 30.8082C96.4045 31.5508 96.4045 32.7548 97.1441 33.4974C97.5126 33.8675 97.9973 34.055 98.4819 34.055H98.4845Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M95.3595 78.5426C98.6259 73.0932 100.355 66.8479 100.355 60.4505C100.355 51.0573 96.71 42.2292 90.0913 35.5885C83.4828 28.958 74.7008 25.3081 65.3585 25.3081H65.3206C55.9405 25.3182 47.1408 28.9884 40.5449 35.6392C33.9465 42.2926 30.3317 51.146 30.362 60.5671C30.3822 67.0051 32.1568 73.2985 35.4888 78.7657C36.6045 80.5957 37.897 82.3344 39.3257 83.9312C40.5121 85.2568 41.5092 86.6889 42.2917 88.1868C43.8694 91.2081 44.8412 94.1584 45.1795 96.954V107.184C45.1795 107.724 45.2072 108.258 45.2476 108.788C45.2476 108.877 45.2552 108.966 45.2678 109.049C45.8232 115.115 49.0492 120.409 53.7544 123.742C53.7519 123.826 53.7469 123.91 53.7469 123.993V127.347C53.7469 131.009 56.7154 133.99 60.363 133.99H70.354C74.0016 133.99 76.9702 131.009 76.9702 127.347V123.993C76.9702 123.91 76.9651 123.826 76.9626 123.742C81.6678 120.409 84.8939 115.112 85.4492 109.049C85.4618 108.963 85.4694 108.877 85.4694 108.788C85.5098 108.258 85.5375 107.724 85.5375 107.184V101.471C85.5375 101.471 85.5375 101.468 85.5375 101.466V101.362C85.5375 101.362 85.5375 101.359 85.5375 101.357C85.5375 101.357 85.5375 101.354 85.5375 101.352V97.0732C85.7975 94.8224 86.4715 92.4551 87.5443 90.0396C88.5566 87.7635 89.9626 85.5787 91.7271 83.551C92.9715 82.1215 94.0999 80.5804 95.0944 78.9735C95.2055 78.8392 95.2913 78.6922 95.3595 78.5375V78.5426Z"
                      fill="#51AD32"
                    />
                  </g>
                </svg>
              </div>
              <h3 className="text-[30px] font-bold leading-[35px] text-verbus-dark">
                Solutions adaptées <br />
                aux besoins réels
              </h3>
            </div>

            {/* Feature 5 - Fiabilité */}
            <div className="text-center space-y-6">
              <div className="flex justify-center">
                <div className="relative">
                  <svg
                    width="105"
                    height="104"
                    viewBox="0 0 105 104"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M52.5 8.6665L66.0188 35.7932L96.25 40.1698L74.375 61.2732L79.5375 91.0865L52.5 77.0032L25.4625 91.0865L30.625 61.2732L8.75 40.1698L38.9812 35.7932L52.5 8.6665Z"
                      stroke="#51AD32"
                      strokeWidth="4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <svg
                    className="absolute -left-6 top-10"
                    width="63"
                    height="63"
                    viewBox="0 0 63 63"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M31.5 5.25L39.6113 21.6825L57.75 24.3338L44.625 37.1175L47.7225 55.1775L31.5 46.6463L15.2775 55.1775L18.375 37.1175L5.25 24.3338L23.3887 21.6825L31.5 5.25Z"
                      stroke="#51AD32"
                      strokeWidth="4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <svg
                    className="absolute -right-6 top-10"
                    width="63"
                    height="63"
                    viewBox="0 0 63 63"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M31.5 5.25L39.6113 21.6825L57.75 24.3338L44.625 37.1175L47.7225 55.1775L31.5 46.6463L15.2775 55.1775L18.375 37.1175L5.25 24.3338L23.3887 21.6825L31.5 5.25Z"
                      stroke="#51AD32"
                      strokeWidth="4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
              </div>
              <h3 className="text-[30px] font-bold leading-[35px] text-verbus-dark">
                Fiabilité opérationnelle <br />
                reconnue depuis 60 ans
              </h3>
            </div>

            {/* Feature 6 - Flotte moderne */}
            <div className="text-center space-y-6">
              <div className="flex justify-center">
                <svg
                  width="107"
                  height="107"
                  viewBox="0 0 107 107"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M28.0502 8.77502H4.20015C2.55015 9.07502 1.27515 10.425 1.12515 12.15C0.900149 14.85 1.27515 17.85 1.12515 20.625C1.27515 22.875 3.30015 24.3 5.47515 24C6.15015 28.35 12.3751 28.275 12.9751 24H22.9501C23.7001 28.275 29.7752 28.35 30.5252 24C32.5501 24.3 34.6502 22.95 34.8751 20.775C35.3251 16.05 33.6752 9.30002 28.0502 8.77502ZM33.6002 17.4H28.5001V12H31.8002C33.0002 13.5 33.5252 15.525 33.6752 17.4H33.6002ZM2.25015 11.925H8.10015V17.325H2.25015V11.925ZM11.3251 25.125C9.67515 27.15 6.37515 25.875 6.52515 23.25C6.52515 22.125 7.57515 20.925 8.70015 20.775C11.2501 20.4 12.9751 23.1 11.3251 25.125ZM27.8251 25.875C25.6501 26.775 23.4751 24.75 24.2251 22.5C24.5251 21.675 25.4251 20.85 26.2501 20.7C29.6251 20.25 30.6751 24.6 27.8251 25.8V25.875ZM33.7501 20.7C33.7501 20.925 33.5252 21.45 33.3751 21.675C32.7752 22.65 31.6502 22.95 30.5252 22.875C29.7001 18.525 23.7001 18.525 22.9501 22.875H12.9751C12.3001 18.6 6.15015 18.525 5.47515 22.875C4.35015 23.025 3.15015 22.725 2.55015 21.6C2.47515 21.45 2.25015 20.925 2.25015 20.7V18.45H25.8002C26.0252 18.45 26.1752 18.075 26.1752 17.85C26.4002 15.75 26.0252 13.425 26.1752 11.325C26.1752 11.175 25.9502 10.8 25.8002 10.8H2.85015C3.22515 10.275 3.82515 9.97502 4.42515 9.90002H27.9002L29.4002 10.275L30.4501 10.8H27.7501C27.5252 10.8 27.3751 11.175 27.3751 11.4C27.1502 13.5 27.5252 15.825 27.3751 17.925C27.3751 18.075 27.6001 18.45 27.7501 18.45H33.7501V20.7ZM9.22515 17.4V12H18.1501V17.4H9.22515ZM19.2751 17.4V12H25.0501V17.4H19.2751Z"
                    fill="black"
                  />
                </svg>
              </div>
              <h3 className="text-[30px] font-bold leading-[35px] text-verbus-dark">
                Flotte moderne en <br />4 classes d'expérience
              </h3>
            </div>
          </div>
        </div>
      </section>

      {/* Groupes Scolaires Section */}
      <section className="py-24 px-8 relative overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Image */}
            <div>
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/bf56be4fbe073006a5fd1d3d804880ccf7bdd39f?width=1452"
                alt="Groupes scolaires"
                className="rounded-[40px] w-full h-auto"
              />
            </div>

            {/* Content */}
            <div className="space-y-8">
              {/* Icon */}
              <div>
                <svg
                  width="70"
                  height="84"
                  viewBox="0 0 70 84"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clipPath="url(#clip0_127_778)">
                    <path
                      d="M49.6717 63.0933H20.3289C19.0168 63.0933 17.9492 64.1666 17.9492 65.4866V72.4822C17.9492 73.8015 19.0168 74.8749 20.3289 74.8749H49.6717C50.9839 74.8749 52.0514 73.8015 52.0514 72.4822V65.4866C52.0514 64.1672 50.9839 63.0933 49.6717 63.0933Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M28.0422 37.7679H41.9571C43.5197 37.7679 44.7908 36.4899 44.7908 34.9188V30.6607C44.7908 29.0896 43.5197 27.8115 41.9571 27.8115H28.0422C26.4796 27.8115 25.2085 29.0896 25.2085 30.6607V34.9188C25.2085 36.4899 26.4796 37.7679 28.0422 37.7679Z"
                      fill="#51AD32"
                    />
                  </g>
                </svg>
              </div>

              <h2 className="text-[40px] font-bold leading-[45px] text-verbus-dark lowercase">
                Groupes Scolaires
              </h2>

              <p className="text-base text-verbus-dark leading-[105%]">
                Sorties pédagogiques, séjours scolaires, transferts et voyages
                éducatifs : <span className="font-bold">VERBUS</span> accompagne
                les établissements avec sérieux, sécurité et proximité.
                <br />
                <br />
                Nos équipes connaissent les enjeux propres aux déplacements
                scolaires et assurent une organisation rigoureuse, adaptée à
                l'âge des élèves et aux contraintes pédagogiques.
              </p>

              <ul className="space-y-4 text-base text-verbus-dark">
                <li>Sortes de classe</li>
                <li>Journées pédagogiques</li>
                <li>Séjours France & étranger</li>
                <li>Transferts aéroport</li>
              </ul>

              <div className="flex gap-4 flex-wrap">
                <button className="bg-verbus-green text-white px-6 py-3 rounded-full text-base hover:bg-verbus-green/90 transition-colors">
                  Personnaliser mon trajet
                </button>
                <button className="border border-verbus-dark text-verbus-dark bg-white px-6 py-3 rounded-full text-base hover:bg-gray-50 transition-colors">
                  En savoir plus
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Événements Professionnels Section */}
      <section className="py-24 px-8 relative overflow-hidden">
        {/* Decorative SVG */}
        <div className="absolute -left-8 top-1/2 -translate-y-1/2">
          <svg
            width="258"
            height="388"
            viewBox="0 0 229 388"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M-5.04004 54.9418C21.93 30.9418 45.24 16.8918 79.69 9.95183C100.69 5.72183 146.71 12.5318 164.91 29.4618"
              stroke="#53AF32"
              strokeWidth="17.46"
              strokeMiterlimit="10"
            />
            <path
              d="M-37 153.412C-14.47 97.3118 52.14 52.6918 114.4 56.3218C167.34 59.4118 195.9 98.4518 220.61 131.452"
              stroke="#53AF32"
              strokeWidth="17.46"
              strokeMiterlimit="10"
            />
            <path
              d="M11.8998 337.402C-20.0602 272.042 -34.8502 203.332 18.2098 140.302C32.5298 123.292 55.0098 106.592 92.3598 100.082C126.29 94.1618 157.55 114.682 174.64 130.942C209.2 163.822 249.1 269.912 188.6 286.912C160.41 294.832 142.59 231.162 127.17 212.582C103.85 184.492 74.5198 196.442 67.6998 234.122C59.1498 281.332 105.43 356.412 155.01 379.572"
              stroke="#53AF32"
              strokeWidth="17.46"
              strokeMiterlimit="10"
            />
          </svg>
        </div>

        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Content */}
            <div className="space-y-8 order-2 lg:order-1">
              {/* Icon */}
              <div>
                <svg
                  width="41"
                  height="95"
                  viewBox="0 0 41 95"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clipPath="url(#clip0_127_767)">
                    <path
                      d="M36.081 33.7319H32.1579V6.14103C32.1579 2.7547 29.3672 0 25.9366 0H15.0634C11.6328 0 8.84207 2.7547 8.84207 6.14103V33.7319H4.91896C2.20696 33.7319 0 35.9103 0 38.5873V86.3316C0 89.0086 2.20696 91.1871 4.91896 91.1871H5.96423C6.12169 93.3159 7.92578 95.0008 10.1219 95.0008C12.3179 95.0008 14.1212 93.3159 14.2795 91.1871H26.7205C26.878 93.3159 28.6821 95.0008 30.8781 95.0008C33.0742 95.0008 34.8775 93.3159 35.0358 91.1871H36.081C38.793 91.1871 41 89.0086 41 86.3316V38.5873C41 35.9103 38.793 33.7319 36.081 33.7319Z"
                      fill="#51AD32"
                    />
                  </g>
                </svg>
              </div>

              <h2 className="text-[40px] font-bold leading-[45px] text-verbus-dark lowercase">
                Événements Professionnels
              </h2>

              <p className="text-base text-verbus-dark leading-[105%]">
                Séminaires, congrès, conventions, incentives ou transferts VIP :
                VERBUS organise des déplacements professionnels fiables, précis
                et à l'image de votre entreprise.
                <br />
                <br />
                Nous vous accompagnons dans la logistique transport afin de
                garantir ponctualité, confort et sérénité à vos équipes et à vos
                invités.
              </p>

              <ul className="space-y-4 text-base text-verbus-dark">
                <li>Séminaires d'entreprise</li>
                <li>Incentive</li>
                <li>Congrès et conventions</li>
                <li>Transferts aéroport VIP</li>
              </ul>

              <div className="flex gap-4 flex-wrap">
                <button className="bg-verbus-green text-white px-6 py-3 rounded-full text-base hover:bg-verbus-green/90 transition-colors">
                  Personnaliser mon trajet
                </button>
                <button className="border border-verbus-dark text-verbus-dark bg-white px-6 py-3 rounded-full text-base hover:bg-gray-50 transition-colors">
                  En savoir plus
                </button>
              </div>
            </div>

            {/* Image */}
            <div className="order-1 lg:order-2">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/c8838802023c6a7a3ab0b8fbb3760127fab7be38?width=1452"
                alt="Événements professionnels"
                className="rounded-[40px] w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Tourisme Section */}
      <section className="py-24 px-8 relative overflow-hidden">
        {/* Decorative SVG */}
        <div className="absolute right-0 top-1/4">
          <svg
            width="229"
            height="336"
            viewBox="0 0 229 336"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M128.798 108.81C131.348 108.992 135.529 91.9815 132.322 87.2062C130.319 84.2207 128.339 85.3056 127.135 86.6915C126.905 86.9528 125.923 88.3624 125.868 91.3559C125.757 97.8734 127.048 108.691 128.79 108.818L128.798 108.81Z"
              fill="#E72475"
            />
            <path
              d="M375.892 220.652C373.255 220.652 370.594 220.604 367.893 220.501L367.03 220.47C319.959 218.759 285.946 217.524 239.238 157.275C223.368 136.803 208.544 112.42 198.565 90.3732C181.753 53.2243 146.552 11.1338 98.166 4.41044C74.741 1.15565 48.1404 10.231 24.668 18.2453C20.1857 19.7737 15.846 21.2545 11.7043 22.5929L10.9678 20.2963C15.1016 18.9659 19.4255 17.4929 23.8919 15.9645C47.6178 7.8632 74.5034 -1.31514 98.4986 2.02675C147.851 8.88477 183.685 51.6484 200.759 89.3833C210.658 111.264 225.38 135.473 241.139 155.802C287.157 215.156 320.695 216.375 367.109 218.062L367.973 218.094C438.248 220.636 487.505 188.825 539.677 155.128C550.7 148.009 562.096 140.652 573.808 133.533C618.678 106.275 662.899 102.363 704 102.197V104.612C663.255 104.778 619.423 108.643 575.059 135.6C563.371 142.695 551.991 150.052 540.983 157.156C490.475 189.775 442.659 220.652 375.884 220.652H375.892Z"
              fill="#E72475"
            />
          </svg>
        </div>

        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Image */}
            <div>
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/48b8468507c2ada01f919680b4fceeb97a760928?width=1452"
                alt="Tourisme"
                className="rounded-[40px] w-full h-auto"
              />
            </div>

            {/* Content */}
            <div className="space-y-8">
              {/* Icon */}
              <div>
                <svg
                  width="122"
                  height="102"
                  viewBox="0 0 122 102"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clipPath="url(#clip0_127_824)">
                    <path
                      d="M95.3595 78.5426C98.6259 73.0932 100.355 66.8479 100.355 60.4505C100.355 51.0573 96.71 42.2292 90.0913 35.5885C83.4828 28.958 74.7008 25.3081 65.3585 25.3081H65.3206C55.9405 25.3182 47.1408 28.9884 40.5449 35.6392C33.9465 42.2926 30.3317 51.146 30.362 60.5671C30.3822 67.0051 32.1568 73.2985 35.4888 78.7657C36.6045 80.5957 37.897 82.3344 39.3257 83.9312C40.5121 85.2568 41.5092 86.6889 42.2917 88.1868C43.8694 91.2081 44.8412 94.1584 45.1795 96.954V107.184C45.1795 107.724 45.2072 108.258 45.2476 108.788C45.2476 108.877 45.2552 108.966 45.2678 109.049C45.8232 115.115 49.0492 120.409 53.7544 123.742C53.7519 123.826 53.7469 123.91 53.7469 123.993V127.347C53.7469 131.009 56.7154 133.99 60.363 133.99H70.354C74.0016 133.99 76.9702 131.009 76.9702 127.347V123.993C76.9702 123.91 76.9651 123.826 76.9626 123.742C81.6678 120.409 84.8939 115.112 85.4492 109.049C85.4618 108.963 85.4694 108.877 85.4694 108.788C85.5098 108.258 85.5375 107.724 85.5375 107.184V101.471C85.5375 101.471 85.5375 101.468 85.5375 101.466V101.362C85.5375 101.362 85.5375 101.359 85.5375 101.357C85.5375 101.357 85.5375 101.354 85.5375 101.352V97.0732C85.7975 94.8224 86.4715 92.4551 87.5443 90.0396C88.5566 87.7635 89.9626 85.5787 91.7271 83.551C92.9715 82.1215 94.0999 80.5804 95.0944 78.9735C95.2055 78.8392 95.2913 78.6922 95.3595 78.5375V78.5426Z"
                      fill="#51AD32"
                    />
                  </g>
                </svg>
              </div>

              <h2 className="text-[40px] font-bold leading-[45px] text-verbus-dark lowercase">
                Tourisme
              </h2>

              <p className="text-base text-verbus-dark leading-[105%]">
                Circuits découverte, séjours organisés, voyages de clubs ou
                d'associations : VERBUS propose des solutions de transport
                confortables et accompagnées, pensées pour profiter pleinement
                du voyage.
                <br />
                <br />
                Nos conducteurs et nos équipes assurent un service attentif, sur
                des trajets en France comme en Europe.
              </p>

              <ul className="space-y-4 text-base text-verbus-dark">
                <li>Voyages France & Europe</li>
                <li>Séjours organisés</li>
                <li>Clubs & associations</li>
                <li>Différents niveaux de confort proposés</li>
              </ul>

              <div className="flex gap-4 flex-wrap">
                <button className="bg-verbus-green text-white px-6 py-3 rounded-full text-base hover:bg-verbus-green/90 transition-colors">
                  Personnaliser mon trajet
                </button>
                <button className="border border-verbus-dark text-verbus-dark bg-white px-6 py-3 rounded-full text-base hover:bg-gray-50 transition-colors">
                  En savoir plus
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sport & Loisirs Section */}
      <section className="py-24 px-8 relative overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Content */}
            <div className="space-y-8 order-2 lg:order-1">
              {/* Icon */}
              <div>
                <svg
                  width="111"
                  height="85"
                  viewBox="0 0 111 85"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clipPath="url(#clip0_127_864)">
                    <path
                      d="M110.933 69.0479L107.812 36.5115C107.09 28.9941 100.82 23.326 93.2269 23.326H83.2324C82.2776 17.5765 79.5855 12.3669 75.3825 8.18606C70.0695 2.90798 63.0106 0 55.4991 0C47.9876 0 40.9287 2.90798 35.6179 8.1882C31.4149 12.3669 28.7207 17.5786 27.768 23.3281H17.7735C10.1801 23.3281 3.9079 28.9962 3.18585 36.5137L0.0670135 69.0479C-0.323111 73.1238 1.04125 77.2018 3.81091 80.2319C6.58273 83.2621 10.5335 85 14.6525 85H96.3458C100.465 85 104.416 83.2621 107.187 80.2319C109.959 77.2018 111.324 73.1259 110.931 69.0479H110.933Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M70.4204 46.3562H40.577C39.6847 46.3562 38.9604 47.0762 38.9604 47.9634C38.9604 48.8506 39.6847 49.5706 40.577 49.5706H43.948V52.8343C43.948 53.7215 44.6722 54.4415 45.5645 54.4415C46.4569 54.4415 47.1811 53.7215 47.1811 52.8343V49.5706H70.4204C71.3127 49.5706 72.0369 48.8506 72.0369 47.9634C72.0369 47.0762 71.3127 46.3562 70.4204 46.3562Z"
                      fill="#51AD32"
                    />
                  </g>
                </svg>
              </div>

              <h2 className="text-[40px] font-bold leading-[45px] text-verbus-dark lowercase">
                sport & loisirs
              </h2>

              <p className="text-base text-verbus-dark leading-[105%]">
                Déplacements de clubs sportifs, événements, sorties loisirs ou
                colonies : VERBUS organise des trajets simples et fiables,
                spécifiquement pensés pour les groupes.
                <br />
                <br />
                Nous adaptons les véhicules, les horaires et l'organisation aux
                contraintes sportives et événementielles.
              </p>

              <ul className="space-y-4 text-base text-verbus-dark">
                <li>Clubs sportifs</li>
                <li>Événements & spectacles</li>
                <li>Colonies de vacances</li>
                <li>Solutions économiques ou confort</li>
              </ul>

              <div className="flex gap-4 flex-wrap">
                <button className="bg-verbus-green text-white px-6 py-3 rounded-full text-base hover:bg-verbus-green/90 transition-colors">
                  Personnaliser mon trajet
                </button>
                <button className="border border-verbus-dark text-verbus-dark bg-white px-6 py-3 rounded-full text-base hover:bg-gray-50 transition-colors">
                  En savoir plus
                </button>
              </div>
            </div>

            {/* Image */}
            <div className="order-1 lg:order-2">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/7ba0a57f18ba24fac4588fdfd5450a461f013cd4?width=1452"
                alt="Sport & Loisirs"
                className="rounded-[40px] w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section - Voyage sur-mesure */}
      <section className="relative overflow-hidden mx-8 my-24">
        <div className="bg-verbus-green rounded-r-[40px] py-24 px-8 relative">
          <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Image */}
            <div className="relative -ml-16">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/1448e48681df571db83d99c2db4a889da7419ccd?width=1040"
                alt="Voyage sur-mesure"
                className="rounded-[40px] w-full h-auto"
              />
            </div>

            {/* Right Content */}
            <div className="text-center space-y-8">
              <div className="space-y-2">
                <div className="text-verbus-dark font-extrabold text-base uppercase">
                  voyage sur-mesure
                </div>
                <div className="w-[263px] h-px bg-black mx-auto"></div>
              </div>

              <h2 className="text-white font-bold text-[40px] leading-tight">
                Prêt à organiser <br />
                votre prochain <br />
                déplacement de groupe ?
              </h2>

              <p className="text-white text-xl leading-tight max-w-[526px] mx-auto">
                En quelques questions, nous préparons avec vous un devis adapté
                à votre projet, au nombre de voyageurs et à votre budget.
              </p>

              <button className="bg-white text-verbus-green px-8 py-6 rounded-full text-base font-normal hover:bg-gray-50 transition-colors">
                personnaliser mon trajet
              </button>

              <p className="text-white text-[13px] italic">
                Réponse garantie sous 24h • Sans engagement
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
