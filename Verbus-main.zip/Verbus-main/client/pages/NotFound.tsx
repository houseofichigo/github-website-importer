import { Link } from "react-router-dom";
import Layout from "@/components/Layout";

export default function NotFound() {
  return (
    <Layout>
      <div className="min-h-screen flex items-center justify-center bg-verbus-gray py-20">
        <div className="text-center max-w-2xl mx-auto px-8">
          <div className="mb-8">
            <h1 className="text-[120px] font-bold text-verbus-green leading-none">404</h1>
          </div>
          
          <h2 className="text-4xl font-bold text-verbus-dark mb-6">Page non trouvée</h2>
          
          <p className="text-lg text-gray-600 mb-8">
            Désolé, la page que vous recherchez n'existe pas ou a été déplacée.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/"
              className="px-6 py-3 rounded-full bg-verbus-green text-white font-normal text-base hover:bg-verbus-green/90 transition-colors"
            >
              Retour à l'accueil
            </Link>
            <Link
              to="/contact"
              className="px-6 py-3 rounded-full border-2 border-verbus-green text-verbus-green font-normal text-base hover:bg-verbus-green hover:text-white transition-colors"
            >
              Nous contacter
            </Link>
          </div>
        </div>
      </div>
    </Layout>
  );
}
