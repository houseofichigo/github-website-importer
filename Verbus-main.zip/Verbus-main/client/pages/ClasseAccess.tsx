import Layout from "@/components/Layout";
import { Link } from "react-router-dom";

export default function ClasseAccess() {
  return (
    <Layout>
      {/* Breadcrumb */}
      <div className="bg-white py-6 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex items-center gap-2 text-base italic text-verbus-dark">
            <Link
              to="/vehicules"
              className="hover:text-verbus-green transition-colors"
            >
              Nos véhicules
            </Link>
            <span className="mx-2">|</span>
            <span>Classe access</span>
          </div>
          <div className="w-[206px] h-px bg-verbus-green mt-2"></div>
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative bg-white">
        <div className="max-w-7xl mx-auto px-8 py-16">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            {/* Left Content */}
            <div className="relative">
              {/* Decorative SVG */}
              <div className="absolute -left-20 top-0">
                <svg
                  width="82"
                  height="359"
                  viewBox="0 0 82 359"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M77.3474 168.141C75.2361 162.938 72.9077 157.805 70.3623 152.762C67.6327 147.345 64.6531 142.03 61.4434 136.832C58.0429 131.327 54.3727 125.952 50.4592 120.725C46.3681 115.261 41.9942 109.969 37.3572 104.872C32.4439 99.4675 27.2281 94.2879 21.7491 89.345C16.2702 84.4021 10.0809 79.3586 3.83244 74.7946C-2.78436 69.9583 -9.684 65.4357 -16.8467 61.2742C-24.4501 56.8463 -32.3298 52.8032 -40.4331 49.1568C-49.0099 45.2972 -57.8367 41.8756 -66.828 38.8922C-76.4572 35.6956 -86.2837 32.9962 -96.2418 30.7527C-98.7938 30.1785 -101.352 29.6339 -103.924 29.1189C-104.404 29.0242 -105.148 29.0538 -104.904 29.6576C-104.661 30.2614 -103.648 30.6817 -103.036 30.806C-93.0124 32.8186 -83.0937 35.2753 -73.3724 38.2469C-64.3483 40.9995 -55.4755 44.1784 -46.8394 47.813C-38.7559 51.2168 -30.863 55.0053 -23.2531 59.1964C-15.6431 63.3875 -8.99995 67.5253 -2.28448 72.2018C4.0495 76.606 10.1138 81.3239 15.8953 86.3023C21.4137 91.0558 26.6624 96.0578 31.6283 101.285C36.3969 106.305 40.8958 111.526 45.1184 116.919C49.1174 122.027 52.8665 127.296 56.3525 132.706C59.8385 138.117 62.7589 143.125 65.6003 148.494C68.2707 153.537 70.724 158.67 72.9538 163.885C73.4734 165.098 73.9798 166.312 74.4731 167.537C74.7165 168.141 75.7031 168.555 76.3411 168.686C76.8212 168.786 77.5711 168.762 77.3211 168.147L77.3474 168.141Z"
                    fill="#E71D74"
                  />
                </svg>
              </div>

              {/* Title */}
              <div className="mb-6">
                <p className="text-base font-bold uppercase text-verbus-dark mb-2">
                  L'efficacité au service du collectif
                </p>
                <h1 className="text-verbus-green font-bold uppercase">
                  <span className="text-[40px] leading-tight">Classe</span>
                  <br />
                  <span className="text-[60px] leading-tight">Access</span>
                </h1>
              </div>

              {/* Large Star Icon */}
              <div className="relative mb-6 flex items-center">
                <svg
                  width="42"
                  height="45"
                  viewBox="0 0 42 45"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M21.0123 0.5C22.5146 0.500124 23.7234 1.45364 24.3112 2.84668L24.3151 2.85645L28.3981 13.0967L38.2731 14.3037C39.729 14.4622 40.8773 15.5639 41.318 17.0068C41.7646 18.4692 41.3675 20.0335 40.3229 21.0957L40.3239 21.0967L32.9059 28.6758L34.9547 39.7324L34.9996 40.0146C35.1802 41.4245 34.6412 42.8126 33.6041 43.6748L33.5953 43.6816C32.4327 44.6059 30.891 44.7191 29.6539 43.9336L29.65 43.9316L21.0553 38.3818L12.4606 43.9307L12.4615 43.9316C11.9165 44.2841 11.2988 44.5 10.6608 44.5H10.5299C9.75215 44.4999 9.03451 44.2335 8.38831 43.7285L8.3844 43.7256C7.21758 42.7976 6.73206 41.2697 7.026 39.7764L9.07385 28.7207L1.65491 21.0957V21.0947C0.60296 20.0237 0.266969 18.4611 0.657837 17.0215L0.660767 17.0107C1.10076 15.521 2.20473 14.4654 3.69983 14.3047L13.5826 13.0967L17.7096 2.85449L17.7125 2.84668C18.3003 1.45347 19.5099 0.5 21.0123 0.5Z"
                    fill="#E71D73"
                    stroke="#E72475"
                  />
                </svg>
                <div className="ml-4">
                  <p className="text-[15px] font-semibold uppercase text-verbus-pink">
                    CAPACITÉ : 8 à 63 places
                    <br />
                    écartement de sièges : 70 cm
                  </p>
                  <p className="text-[15px] font-semibold uppercase text-verbus-green mt-2">
                    trajet quotidien
                  </p>
                </div>
              </div>

              {/* Description */}
              <p className="text-base text-verbus-dark leading-tight mb-8">
                Le choix idéal pour les courtes distances et les groupes qui
                cherchent avant tout la simplicité.
                <br />
                <br />
                Fiable, fonctionnelle et accessible, la{" "}
                <span className="font-bold">Classe ACCESS</span> propose une
                solution rassurante, sans superflu, avec tout le nécessaire pour
                être transporté simplement et dans de bonnes conditions.
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap gap-4">
                <Link
                  to="/voyage-sur-mesure"
                  className="px-6 py-3 rounded-full bg-verbus-green text-white text-base hover:bg-verbus-green/90 transition-colors"
                >
                  Personnaliser mon trajet
                </Link>
                <Link
                  to="/devis"
                  className="px-6 py-3 rounded-full border border-verbus-dark text-verbus-dark bg-white text-base hover:bg-gray-50 transition-colors"
                >
                  Demander un devis
                </Link>
              </div>
            </div>

            {/* Right Image */}
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/7eb713ee761663fc15c0a683cc574c9fd2e4cb3a?width=4024"
                alt="Classe Access"
                className="rounded-t-[40px] w-full shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Green Banner */}
      <section className="bg-verbus-green py-6">
        <div className="max-w-7xl mx-auto px-8">
          <p className="text-white text-xl text-center leading-tight">
            Idéale pour les navettes locales, les sorties sportives ou les
            événements à proximité
          </p>
        </div>
      </section>

      {/* Spirit Section */}
      <section className="bg-[#FAFAFC] py-16">
        <div className="max-w-7xl mx-auto px-8">
          <p className="text-verbus-green text-[25px] font-normal uppercase text-center mb-8">
            l'esprit de cette classe
          </p>

          <h2 className="text-[35px] font-bold text-verbus-dark text-center mb-6">
            "simple et efficace"
          </h2>

          <p className="text-[25px] font-bold text-verbus-dark text-center max-w-3xl mx-auto leading-tight">
            La Classe ACCESS a été pensée pour répondre à un besoin clair :
            proposer une solution de transport collective fiable, sans superflu,
            adaptée aux déplacements courts et aux usages du quotidien.
          </p>
        </div>
      </section>

      {/* Experience Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-verbus-dark text-center mb-16">
            L'expérience à bord
          </h2>

          <div className="grid md:grid-cols-2 gap-8 mb-16">
            {/* Left Image */}
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/db2e2f7fb840597ebbb0e0cacae4106b7e2fe5a4?width=1200"
                alt="Sécurité avant tout"
                className="rounded-[40px] w-full h-auto"
              />
            </div>

            {/* Right Content */}
            <div className="flex flex-col justify-center text-center">
              <div className="mb-6">
                <svg
                  className="mx-auto mb-4"
                  width="92"
                  height="111"
                  viewBox="0 0 92 111"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clipPath="url(#clip0_133_880)">
                    <path
                      d="M0.166303 50.3606C-0.625316 46.6499 1.46897 42.9297 5.03689 41.7082C7.03097 41.0233 9.23109 41.227 11.0698 42.2707C11.3999 42.4574 11.6917 42.6945 11.9855 42.9266L11.5258 40.771C10.7555 37.1612 11.6366 33.4449 13.9401 30.5742C15.1676 29.0442 16.7195 27.875 18.4499 27.1044C13.2574 25.0605 9.56427 19.98 9.56427 14.0362C9.56364 6.29633 15.8177 0 23.504 0C31.1904 0 37.4438 6.29633 37.4438 14.0368C37.4438 19.449 34.3813 24.1473 29.914 26.4889C31.2699 26.8193 32.582 27.3257 33.7976 28.0339L51.8727 38.2995L60.4565 31.1544C63.8691 28.4432 68.6783 28.7907 71.6619 31.937C72.7779 33.1144 73.4756 34.5863 73.7749 36.1491L77.8639 27.3371C78.3875 26.2076 79.3163 25.3525 80.4787 24.9268C81.6423 24.5023 82.8986 24.556 84.0221 25.0857C85.1426 25.6135 85.9918 26.5488 86.4146 27.7193C86.836 28.891 86.7803 30.1573 86.2567 31.2862L83.2243 37.8215H90.997C91.5507 37.8215 91.9991 38.2731 91.9991 38.8305V68.9721C91.9991 69.3883 91.7454 69.7617 91.3603 69.9124C91.2419 69.9591 91.1198 69.9811 90.997 69.9811C90.7208 69.9811 90.4522 69.867 90.258 69.6532L75.8223 53.7742L74.1883 57.2958C73.6059 58.5501 72.5099 59.4727 71.1821 59.8284C70.7913 59.9337 70.3912 59.9861 69.9922 59.9861C69.319 59.9861 68.6476 59.8385 68.0301 59.5478C66.9097 59.0206 66.0604 58.0847 65.6377 56.9136C65.215 55.7418 65.2713 54.4755 65.7955 53.3467L69.5557 45.2435L56.9662 54.548C54.7811 56.1631 51.9616 56.5503 49.4295 55.5873L37.3561 50.9994L39.1949 61.8017C40.2821 61.7998 41.3273 62.1574 42.1716 62.8694C43.1198 63.6697 43.7022 64.7928 43.8105 66.0346C43.8206 66.1493 43.8055 66.261 43.8074 66.3751L65.9064 69.8506C68.5893 70.2731 70.8909 71.9973 72.0614 74.4663L83.4109 98.396C84.505 100.703 84.5489 103.369 83.5337 105.711C82.5178 108.054 80.5457 109.833 78.1232 110.594C77.2464 110.868 76.3596 111 75.4878 111C72.2205 111 69.1618 109.15 67.6593 106.035L59.1438 88.3807C58.6866 87.4348 57.7171 86.8231 56.6719 86.8231H54.7723V95.2775C54.7723 98.7479 51.9691 101.571 48.5221 101.571H16.1452C13.2192 101.571 10.6496 99.4801 10.0352 96.5999L0.166303 50.3606Z"
                      fill="#51AD32"
                    />
                  </g>
                </svg>
              </div>
              <h3 className="text-verbus-green text-[25px] font-normal uppercase mb-4">
                Sécurité
                <br />
                avant tout
              </h3>
              <p className="text-verbus-green text-base">
                Des véhicules entretenus et fiables
              </p>
              <p className="text-verbus-dark text-base font-bold mt-6 leading-tight">
                Ceintures de sécurité pour tous
                <br />
                Véhicules entretenus
                <br />
                Conducteurs professionnels
              </p>
            </div>
          </div>

          {/* Bottom Row */}
          <div className="grid md:grid-cols-2 gap-8">
            {/* Left Content */}
            <div className="flex flex-col justify-center text-center">
              <p className="text-verbus-dark text-base font-bold leading-tight mb-6">
                Simplicité et fluidité dans l'embarquement. Un confort essentiel
                qui va droit au but. Une montée et descente facilitée pour les
                groupes pressés ou les enfants.
              </p>
            </div>

            {/* Right Image */}
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/0992b9c4a78d795d0cf0b759186c859fc7d45529?width=1200"
                alt="Budget maîtrisé"
                className="rounded-[40px] w-full h-auto"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mt-8">
            <div className="text-center">
              <div className="mb-4">
                <svg
                  className="mx-auto"
                  width="172"
                  height="78"
                  viewBox="0 0 172 78"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <image
                    href="https://api.builder.io/api/v1/image/assets/TEMP/e96a2c6e8c89e641431bd4adb92c2185275eaaec?width=344"
                    width="172"
                    height="78"
                  />
                </svg>
              </div>
              <h3 className="text-verbus-green text-[25px] font-normal uppercase">
                Budget maîtrisé
              </h3>
              <p className="text-verbus-green text-base">
                solution adaptée à vos besoins
              </p>
              <p className="text-verbus-dark text-base font-bold mt-6 leading-tight">
                Tarifs adaptés aux réalités du terrain
                <br />
                La Classe ACCESS est disponible selon les sites en :<br />
                8, 22, 33, 55, 59 et 63 places
                <br />
                Idéal pour les trajets locaux
                <br />
                Pas de superflu, l'essentiel
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="py-16 bg-[#FAFAFC]">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Clubs sportifs locaux */}
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/6cf4d424e7d159a71768f1de431f464da334eadb?width=1574"
                alt="Clubs sportifs locaux"
                className="rounded-[40px] w-full h-auto mb-6"
              />
              <div className="text-center">
                <div className="w-80 h-80 bg-white rounded-full mx-auto flex items-center justify-center mb-4 -mt-32">
                  <svg
                    width="147"
                    height="136"
                    viewBox="0 0 147 136"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <g clipPath="url(#clip0_133_932)">
                      <path
                        d="M144.594 70.5325H133.492C132.131 70.5243 131.226 69.5383 131.234 68.4045C131.242 67.1515 132.217 66.3299 133.566 66.3258L144.594 66.2847C146.05 66.2806 147.012 67.1186 147.004 68.4086C146.996 69.6985 146.042 70.5325 144.594 70.5325Z"
                        fill="#E9678F"
                      />
                      <path
                        d="M76.0906 14.1854C76.0948 15.8163 75.2765 16.679 74.0593 16.7489C72.8421 16.8187 71.777 15.9273 71.7853 14.4155L71.8511 2.46488C71.8593 1.03114 72.4967 0.110912 73.7138 0.0123166C74.931 -0.0862788 76.0536 0.591564 76.0578 2.05817L76.0906 14.1854Z"
                        fill="#F1BDBF"
                      />
                      <path
                        d="M13.6234 65.9727C15.2683 65.9727 16.2305 66.6217 16.2799 67.9733C16.3292 69.2345 15.3875 70.1589 13.8373 70.163L2.29868 70.1753C0.937565 70.1753 0.0699079 69.4194 0.00411402 68.3143C-0.0822405 66.9299 0.756632 65.9973 2.30279 65.9973L13.6276 65.9768L13.6234 65.9727Z"
                        fill="#EA6A92"
                      />
                      <path
                        d="M112.043 18.2687L108.346 23.3464C107.705 24.2297 106.335 24.127 105.533 23.6792C104.875 23.3135 104.238 21.9866 104.867 21.0623L111.336 11.5643C112.076 10.4797 113.47 10.2291 114.564 10.9439C115.365 11.4698 115.645 12.9035 114.925 13.9716L112.043 18.2646V18.2687Z"
                        fill="#E9668B"
                      />
                      <path
                        d="M43.0127 19.682C43.6871 20.668 43.4692 21.9333 42.7948 22.5372C41.9395 23.3013 40.3234 23.4122 39.5915 22.3318L33.4356 13.2651C32.7777 12.2956 32.7941 11.174 33.3123 10.4715C33.9496 9.60473 35.8823 9.25554 36.5608 10.2538L43.0127 19.6861V19.682Z"
                        fill="#E7668C"
                      />
                    </g>
                  </svg>
                </div>
                <h3 className="text-[35px] font-bold text-white -mt-16">
                  clubs sportifs locaux
                </h3>
              </div>
            </div>

            {/* Centre de loisirs */}
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/ccccaba4cc0d6c50cfd758abfe2ba55177b2459f?width=1572"
                alt="Centre de loisirs"
                className="rounded-[40px] w-full h-auto mb-6"
              />
              <div className="text-center">
                <div className="w-80 h-80 bg-white rounded-full mx-auto flex items-center justify-center mb-4 -mt-32">
                  <svg
                    width="135"
                    height="130"
                    viewBox="0 0 135 130"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <g clipPath="url(#clip0_133_947)">
                      <path
                        d="M12.8903 68.8835L1.53854 68.7797C0.631477 68.772 0.137757 67.8112 0.0267656 67.1809C-0.099535 66.4584 0.264057 65.0594 1.27446 65.0479L12.8865 64.9172C14.2528 64.9018 15.179 65.7089 15.179 66.8965C15.179 68.0841 14.249 68.8989 12.8903 68.8873V68.8835Z"
                        fill="#EB6C93"
                      />
                    </g>
                  </svg>
                </div>
                <h3 className="text-[35px] font-bold text-white -mt-16">
                  centre de loisirs
                </h3>
              </div>
            </div>

            {/* Association */}
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/93b5664dce10618aa8c208d4ff9861b5ab3cbe08?width=1570"
                alt="Association"
                className="rounded-[40px] w-full h-auto mb-6"
              />
              <div className="text-center">
                <div className="w-80 h-80 bg-white rounded-full mx-auto flex items-center justify-center mb-4 -mt-32">
                  <svg
                    width="130"
                    height="132"
                    viewBox="0 0 130 132"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <image
                      href="https://api.builder.io/api/v1/image/assets/TEMP/304851c07ceedcdfebf6287f8e7a3b1d60b0fcd9?width=260"
                      width="130"
                      height="132"
                    />
                  </svg>
                </div>
                <h3 className="text-[35px] font-bold text-white -mt-16">
                  association
                </h3>
              </div>
            </div>

            {/* Déplacement de proximité */}
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/34412b3b779a175232041117742f2c9bbd094406?width=1572"
                alt="Déplacement de proximité"
                className="rounded-[40px] w-full h-auto mb-6"
              />
              <div className="text-center">
                <div className="w-80 h-80 bg-white rounded-full mx-auto flex items-center justify-center mb-4 -mt-32">
                  <svg
                    width="136"
                    height="132"
                    viewBox="0 0 136 132"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <g clipPath="url(#clip0_133_1009)">
                      <path
                        d="M70.1882 13.1482C70.1958 14.4948 69.5467 15.3521 68.5143 15.5532C67.7362 15.7011 66.328 15.1852 66.3243 14.051L66.3129 1.61234C66.3129 0.535007 67.4895 0.000132855 68.2334 0.00392629C69.1178 0.00771972 70.1312 0.614669 70.135 1.692L70.1882 13.152V13.1482Z"
                        fill="#F1BDBF"
                      />
                    </g>
                  </svg>
                  <svg
                    className="absolute"
                    width="88"
                    height="88"
                    viewBox="0 0 88 88"
                  >
                    <image
                      href="https://api.builder.io/api/v1/image/assets/TEMP/b81b777c6f998a2a53a2032a7346548d717587f1?width=176"
                      width="88"
                      height="88"
                    />
                  </svg>
                </div>
                <h3 className="text-[35px] font-bold text-white -mt-16">
                  déplacement de proximité
                </h3>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Découvrez nos véhicules */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-verbus-dark text-center mb-8">
            Découvrez nos véhicules
          </h2>
          <p className="text-base font-bold text-verbus-dark text-center mb-12">
            La Classe ACCESS est disponible selon les sites en :<br />
            8, 22, 33, 55, 59 et 63 places
          </p>

          {/* Vehicle Images Grid */}
          <div className="grid md:grid-cols-3 gap-6">
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/f91faab22f591a6f7966595f0fb5c32006504a9c?width=1750"
                alt="Sièges confortables"
                className="w-full h-auto"
              />
              <div className="bg-verbus-dark text-white px-4 py-2 text-base italic uppercase mt-2">
                Sièges confortables
              </div>
            </div>
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/8b108c9f58e6ce52a459541a557336361de0428b?width=1012"
                alt="équipements de sécurité"
                className="w-full h-auto"
              />
              <div className="bg-verbus-dark text-white px-4 py-2 text-base italic uppercase mt-2">
                équipements de sécurité
              </div>
            </div>
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/bcccecab63bfcb4f7eee5d6f598dfb168a9167c1?width=1230"
                alt="véhicules pratiques et fiables"
                className="w-full h-auto"
              />
              <div className="bg-verbus-dark text-white px-4 py-2 text-base italic uppercase mt-2">
                véhicules pratiques et fiables
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Caractéristiques principales */}
      <section className="bg-verbus-dark py-20">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-white text-center mb-12">
            Caractéristiques principales
          </h2>

          {/* Bus Icon */}
          <div className="flex justify-center mb-12">
            <svg
              width="190"
              height="176"
              viewBox="0 0 190 176"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M150.399 152.927H136.152C125.246 152.927 114.344 152.927 103.438 152.927C91.396 152.927 79.3536 152.927 67.3076 152.927C59.141 152.927 50.9745 152.927 42.8079 152.927C41.119 152.927 39.2424 153.094 37.5896 152.721C32.7467 151.623 30.0004 147.422 29.9896 142.623C29.9788 136.77 29.9896 130.916 29.9896 125.063C29.9896 114.093 29.9896 103.122 29.9896 92.1508C29.9896 79.8579 29.9896 67.565 29.9896 55.2757C29.9896 45.4603 29.9896 35.6448 29.9896 25.8293C29.9896 23.0477 29.9896 20.2624 29.9896 17.4807C29.9896 15.3402 29.8922 13.2503 30.7835 11.2184C32.5663 7.14369 36.4709 5.45948 40.6462 5.45948C43.1435 5.45948 45.6371 5.45948 48.1344 5.45948C58.0115 5.45948 67.8886 5.45948 77.7658 5.45948C89.9922 5.45948 102.222 5.45948 114.449 5.45948C124.012 5.45948 133.571 5.45948 143.135 5.45948C145.343 5.45948 147.552 5.45586 149.76 5.45948C154.78 5.47035 159.331 8.67939 159.944 13.9457C160.106 15.3257 159.998 16.7817 159.998 18.1653C159.998 21.1896 159.998 24.2175 159.998 27.2419C159.998 37.3254 159.998 47.4089 159.998 57.4924C159.998 69.8142 159.998 82.1361 159.998 94.4543C159.998 106.773 159.998 115.976 159.998 126.74C159.998 132.144 160.027 137.552 159.998 142.956C159.969 148.36 155.928 152.822 150.399 152.934C146.92 153.007 146.909 158.44 150.399 158.367C158.706 158.197 165.289 151.58 165.411 143.235C165.433 141.742 165.411 140.25 165.411 138.762V113.705C165.411 101.481 165.411 89.2532 165.411 77.0292C165.411 64.8051 165.411 53.041 165.411 41.0451C165.411 33.3811 165.411 25.717 165.411 18.053C165.411 16.1478 165.473 14.2608 165.155 12.3738C163.924 5.10815 157.349 0.0736463 150.179 0.019317C144.232 -0.0241463 138.284 0.019317 132.337 0.019317C120.731 0.019317 109.126 0.019317 97.52 0.019317C85.9143 0.019317 73.5038 0.019317 61.4975 0.019317C54.5218 0.019317 47.5461 0.019317 40.5741 0.019317C35.3847 0.019317 30.6175 1.94257 27.4707 6.23096C25.208 9.31323 24.5837 12.8809 24.5837 16.5933C24.5837 23.4352 24.5837 30.2771 24.5837 37.1189C24.5837 48.7925 24.5837 60.4624 24.5837 72.1359C24.5837 83.8094 24.5837 96.8738 24.5837 109.243C24.5837 118.363 24.5837 127.479 24.5837 136.599C24.5837 138.642 24.5765 140.685 24.5837 142.731C24.6018 148.537 27.4815 154.068 32.79 156.716C35.7275 158.179 38.7336 158.36 41.8985 158.36C45.0633 158.36 48.0153 158.36 51.0755 158.36C61.8368 158.36 72.598 158.36 83.3629 158.36C95.777 158.36 108.191 158.36 120.605 158.36C129.259 158.36 137.913 158.36 146.566 158.36H150.406C153.889 158.36 153.896 152.927 150.406 152.927H150.399Z"
                fill="#51AD32"
              />
            </svg>
          </div>

          <div className="grid md:grid-cols-2 gap-x-24 gap-y-6 max-w-4xl mx-auto">
            <div className="flex items-center gap-4">
              <svg
                width="13"
                height="12"
                viewBox="0 0 13 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M0.752563 5.64014L4.25256 9.64014L11.7526 0.640137"
                  stroke="#51AD32"
                  strokeWidth="2"
                />
              </svg>
              <span className="text-white text-[25px]">climatisation</span>
            </div>
            <div className="flex items-center gap-4">
              <svg
                width="13"
                height="12"
                viewBox="0 0 13 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M0.752563 5.64014L4.25256 9.64014L11.7526 0.640137"
                  stroke="#51AD32"
                  strokeWidth="2"
                />
              </svg>
              <span className="text-white text-[25px]">liseuses</span>
            </div>
            <div className="flex items-center gap-4">
              <svg
                width="13"
                height="12"
                viewBox="0 0 13 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M0.752563 5.64014L4.25256 9.64014L11.7526 0.640137"
                  stroke="#51AD32"
                  strokeWidth="2"
                />
              </svg>
              <span className="text-white text-[25px]">géolocalisation</span>
            </div>
            <div className="flex items-center gap-4">
              <svg
                width="13"
                height="12"
                viewBox="0 0 13 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M0.752563 5.64014L4.25256 9.64014L11.7526 0.640137"
                  stroke="#51AD32"
                  strokeWidth="2"
                />
              </svg>
              <span className="text-white text-[25px]">radio</span>
            </div>
            <div className="flex items-center gap-4">
              <svg
                width="13"
                height="12"
                viewBox="0 0 13 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M0.752563 5.64014L4.25256 9.64014L11.7526 0.640137"
                  stroke="#51AD32"
                  strokeWidth="2"
                />
              </svg>
              <span className="text-white text-[25px]">
                ceintures de sécurité
              </span>
            </div>
            <div className="flex items-center gap-4">
              <svg
                width="13"
                height="12"
                viewBox="0 0 13 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M0.752563 5.64014L4.25256 9.64014L11.7526 0.640137"
                  stroke="#51AD32"
                  strokeWidth="2"
                />
              </svg>
              <span className="text-white text-[25px]">soute à bagages</span>
            </div>
            <div className="flex items-center gap-4">
              <svg
                width="13"
                height="12"
                viewBox="0 0 13 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M0.752563 5.64014L4.25256 9.64014L11.7526 0.640137"
                  stroke="#51AD32"
                  strokeWidth="2"
                />
              </svg>
              <span className="text-white text-[25px]">
                microphone conducteur
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Pourquoi cette classe */}
      <section className="relative py-20 bg-verbus-green overflow-hidden">
        {/* Decorative Star */}
        <div className="absolute right-12 top-12">
          <svg
            width="70"
            height="74"
            viewBox="0 0 70 74"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M35.0211 0.5C37.4055 0.500168 39.3497 1.98743 40.3063 4.2207L40.3102 4.23047L47.3268 21.5664L64.3258 23.6113H64.3268C66.6349 23.8588 68.4881 25.5845 69.2057 27.8984C69.9293 30.2318 69.2852 32.7259 67.5973 34.416L67.5983 34.417L54.8639 47.2334L58.3785 65.918L58.4196 66.1426C58.8037 68.4734 57.9251 70.7863 56.2008 72.1982L56.192 72.2051C54.3269 73.6657 51.8709 73.8379 49.902 72.6064L49.899 72.6045L35.0944 63.1895L20.2916 72.6045C19.4103 73.1657 18.4275 73.5 17.4244 73.5H17.2018C15.9673 73.5 14.8219 73.0849 13.778 72.2812L13.775 72.2793C11.9039 70.8138 11.11 68.3869 11.5885 65.9922L15.1022 47.3076L2.3678 34.416V34.415C0.672074 32.7159 0.119568 30.2236 0.75647 27.9131L0.759399 27.9023C1.47621 25.5116 3.25562 23.862 5.63342 23.6123L22.6412 21.5654L29.7321 4.22852L29.735 4.2207C30.6916 1.98727 32.6365 0.5 35.0211 0.5Z"
              fill="#E71D73"
              stroke="#E72475"
            />
          </svg>
        </div>

        <div className="max-w-4xl mx-auto px-8 relative z-10">
          <h2 className="text-[40px] font-bold text-white uppercase mb-12 text-center">
            Pourquoi
            <br />
            cette classe ?
          </h2>

          <div className="space-y-8">
            <div className="flex gap-6">
              <span className="text-[40px] font-medium text-black">1 )</span>
              <p className="text-[25px] font-medium text-verbus-dark leading-[35px]">
                simple et pragmatique
              </p>
            </div>
            <div className="flex gap-6">
              <span className="text-[40px] font-medium text-black">2 )</span>
              <p className="text-[25px] font-medium text-verbus-dark leading-[35px]">
                fiabilité quotidienne
                <br />
                au service de vos projets
              </p>
            </div>
            <div className="flex gap-6">
              <span className="text-[40px] font-medium text-black">3 )</span>
              <p className="text-[25px] font-medium text-verbus-dark leading-[35px]">
                adaptée aux réalités concrètes
                <br />
                des territoires
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="relative overflow-hidden my-24">
        <div className="bg-verbus-green rounded-r-[40px] py-16 px-8 relative ml-8">
          <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Image */}
            <div className="relative -ml-16">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/02ad66be908d49d76636739feca12a8a54c09030?width=700"
                alt="Voyage sur-mesure"
                className="rounded-[40px] w-full h-auto"
              />
            </div>

            {/* Right Content */}
            <div className="text-center space-y-6">
              <div className="space-y-2">
                <p className="text-verbus-dark font-extrabold text-base uppercase">
                  voyage sur-mesure
                </p>
                <div className="w-[185px] h-px bg-black mx-auto"></div>
              </div>

              <h2 className="text-white font-bold text-[40px] leading-tight">
                Prêt pour vos
                <br />
                déplacements
                <br />
                de proximité ?
              </h2>

              <p className="text-white text-xl leading-tight max-w-2xl mx-auto">
                Configurez votre transport en quelques clics
                <br />
                et recevez un devis personnalisé
                <br />
                adapté à vos besoins.
              </p>

              <Link
                to="/voyage-sur-mesure"
                className="inline-block bg-white text-verbus-green px-8 py-4 rounded-full text-base font-normal hover:bg-gray-50 transition-colors"
              >
                personnaliser mon trajet
              </Link>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
