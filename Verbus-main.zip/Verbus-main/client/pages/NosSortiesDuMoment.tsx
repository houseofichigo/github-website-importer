export default function NosSortiesDuMoment() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative h-[928px] overflow-hidden rounded-b-[40px]">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/f6a29d58e50f1350785a691309eb25bc1786d473?width=4024"
            alt="Nos sorties du moment"
            className="w-full h-full object-cover rounded-b-[40px]"
          />
        </div>

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#1E1E1E] via-[#1E1E1E]/80 to-transparent rounded-b-[40px]" />

        {/* Decorative SVG Elements */}
        <div className="absolute -left-[326px] top-[22px]">
          <svg
            width="82"
            height="359"
            viewBox="0 0 82 359"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M77.3481 168.141C75.2368 162.938 72.9084 157.805 70.363 152.762C67.6334 147.345 64.6539 142.03 61.4441 136.832C58.0436 131.327 54.3735 125.952 50.46 120.725C46.3689 115.261 41.9949 109.969 37.3579 104.872C32.4446 99.4675 27.2288 94.2879 21.7499 89.345C16.2709 84.4021 10.0816 79.3586 3.83318 74.7946C-2.78363 69.9583 -9.68327 65.4357 -16.846 61.2742C-24.4494 56.8463 -32.3291 52.8032 -40.4323 49.1568C-49.0092 45.2972 -57.836 41.8756 -66.8272 38.8922C-76.4565 35.6956 -86.283 32.9962 -96.2411 30.7527C-98.7931 30.1785 -101.352 29.6339 -103.923 29.1189C-104.404 29.0242 -105.147 29.0538 -104.903 29.6576C-104.66 30.2614 -103.647 30.6817 -103.036 30.806C-93.0116 32.8186 -83.093 35.2753 -73.3717 38.2469C-64.3476 40.9995 -55.4747 44.1784 -46.8387 47.813C-38.7551 51.2168 -30.8623 55.0053 -23.2523 59.1964C-15.6423 63.3875 -8.99921 67.5253 -2.28374 72.2018C4.05023 76.606 10.1145 81.3239 15.896 86.3023C21.4144 91.0558 26.6631 96.0578 31.629 101.285C36.3976 106.305 40.8965 111.526 45.1192 116.919C49.1182 122.027 52.8673 127.296 56.3533 132.706C59.8393 138.117 62.7596 143.125 65.601 148.494C68.2714 153.537 70.7248 158.67 72.9545 163.885C73.4741 165.098 73.9805 166.312 74.4738 167.537C74.7172 168.141 75.7038 168.555 76.3418 168.686C76.822 168.786 77.5718 168.762 77.3219 168.147L77.3481 168.141Z"
              fill="#E71D74"
            />
          </svg>
        </div>

        {/* Main Content */}
        <div className="relative z-10 max-w-[600px] pt-[514px] pl-[93px]">
          <h1 className="text-[#51AD32] text-[60px] font-bold leading-[63px] uppercase mb-8">
            Nos sorties
            <br />
            du moment
          </h1>
        </div>
      </section>

      {/* Introduction Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-8">
          <div className="max-w-4xl">
            <h2 className="text-[40px] font-bold text-[#1E1E1E] text-center leading-[45px] mb-12">
              Découvrez nos sorties organisées en autocar,
              <br />
              ouvertes à la réservation individuelle
            </h2>

            <div className="space-y-6">
              <p className="text-[25px] font-bold text-[#1E1E1E] leading-[30px]">
                VERBUS vous propose une sélection d'excursions en autocar
                ouvertes à tous, sur des dates et des destinations à découvrir
                régulièrement sur cette page !
              </p>

              <p className="text-base font-semibold text-[#1E1E1E] leading-[18px]">
                L'objectif : vous permettre de réserver une ou plusieurs places
                pour une sortie organisée, au départ de votre territoire. Chaque
                sortie est pensée pour vous permettre de voyager simplement, en
                toute sérénité, dans des autocars confortables et conduits par
                des professionnels VERBUS.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Comment ça fonctionne Section */}
      <section className="py-24 bg-[#FAFAFC]">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-[#1E1E1E] leading-[40px] mb-16">
            Comment
            <br />
            ça fonctionne ?
          </h2>

          <div className="max-w-2xl">
            <ul className="space-y-6 text-base font-medium text-[#1E1E1E] leading-[16px]">
              <li>vous choisissez une sortie parmi celles proposées</li>
              <li>
                vous réservez une ou plusieurs places directement en ligne
              </li>
              <li>le paiement se fait en toute sécurité</li>
              <li>
                une fois le nombre de places mises à disposition vendues, la
                sortie sera confirmée par nos équipes et vous en serez informé.e
              </li>
              <li>
                le jour J, vous montez à bord et profitez de l'excursion !
              </li>
            </ul>

            <p className="mt-8 text-base font-medium text-[#1E1E1E] leading-[16px]">
              Les sorties sont proposées en nombre de places limité, selon les
              dates et les destinations.
            </p>
          </div>
        </div>
      </section>

      {/* Calendrier LUMA Section */}
      <section className="py-24 bg-white relative">
        <div className="max-w-7xl mx-auto px-8">
          {/* Decorative SVG */}
          <div className="absolute right-0 top-0">
            <svg
              width="466"
              height="317"
              viewBox="0 0 292 317"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M106.293 26.8813C103.929 26.8468 101.426 10.9028 104.753 6.77697C106.834 4.19502 108.566 5.34844 109.568 6.71314C109.758 6.96826 110.555 8.34343 110.361 11.0876C109.945 17.0793 107.911 26.9009 106.293 26.8743L106.293 26.8813Z"
                fill="#E72475"
              />
            </svg>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Left - Calendar Placeholder */}
            <div className="bg-[#D9D9D9] rounded-[40px] h-[730px] flex items-center justify-center">
              <div className="text-center text-white">
                <h3 className="text-[40px] font-bold uppercase mb-4">
                  calendrier luma
                </h3>
                <p className="text-base">
                  Le calendrier des sorties sera affiché ici
                </p>
              </div>
            </div>

            {/* Right - Images */}
            <div className="grid grid-cols-2 gap-4">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/0e7558b19bb3802c763b68f5af27271fd1e0786f?width=1308"
                alt="Sortie en groupe"
                className="w-full h-[335px] object-cover rounded-[20px]"
              />
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/6aa79143ec297baee0467088e4a3b04fc8f4b6c2?width=1308"
                alt="Autocar Verbus"
                className="w-full h-[335px] object-cover rounded-[20px]"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Une envie de sortie Section */}
      <section className="py-24 bg-[#51AD32] relative">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Left - Form */}
            <div>
              <h2 className="text-[40px] font-bold text-[#1E1E1E] leading-[40px] mb-8">
                Une envie de sortie ?<br />
                Dites-le nous
              </h2>

              <p className="text-base font-normal text-[#1E1E1E] leading-[16.8px] mb-12 max-w-md">
                Vous ne trouvez pas la sortie que vous aimeriez faire ? Vous
                pouvez nous suggérer vos idées de destinations ou d'excursions
                directement via le formulaire ci-dessous. Nous étudions
                régulièrement les propositions pour construire de nouvelles
                sorties au plus près de vos envies.
              </p>

              <form className="space-y-4">
                <div>
                  <input
                    type="text"
                    placeholder="Nom*"
                    className="w-full px-4 py-3 rounded-[10px] border border-white bg-[#51AD32] text-white placeholder:text-white placeholder:italic"
                  />
                </div>

                <div>
                  <input
                    type="text"
                    placeholder="Prénom*"
                    className="w-full px-4 py-3 rounded-[10px] border border-white bg-[#51AD32] text-white placeholder:text-white placeholder:italic"
                  />
                </div>

                <div>
                  <input
                    type="email"
                    placeholder="Email*"
                    className="w-full px-4 py-3 rounded-[10px] border border-white bg-[#51AD32] text-white placeholder:text-white placeholder:italic"
                  />
                </div>

                <div>
                  <textarea
                    placeholder="Idées de sorties*"
                    rows={4}
                    className="w-full px-4 py-3 rounded-[10px] border border-white bg-[#51AD32] text-white placeholder:text-white placeholder:italic resize-none"
                  />
                </div>

                <div className="space-y-2 text-white text-base italic">
                  <p>*champs obligatoires</p>
                  <label className="flex items-start gap-2">
                    <input type="checkbox" className="mt-1" />
                    <span className="text-sm">
                      J'ai lu et j'accepte la politique de confidentialité des
                      données.
                    </span>
                  </label>
                </div>

                <button
                  type="submit"
                  className="bg-white text-[#1E1E1E] px-8 py-3 rounded-full text-base font-normal hover:bg-gray-50 transition-colors"
                >
                  envoyer
                </button>
              </form>
            </div>

            {/* Right - Image */}
            <div className="hidden lg:block">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/0e7558b19bb3802c763b68f5af27271fd1e0786f?width=1308"
                alt="Groupe en sortie"
                className="w-full h-full max-h-[600px] object-cover rounded-[20px]"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Dedicated Page Notice Section */}
      <section className="py-24 bg-[#1E1E1E] relative">
        <div className="max-w-4xl mx-auto px-8 text-center">
          {/* Decorative SVG */}
          <div className="flex justify-center mb-12">
            <svg
              width="95"
              height="88"
              viewBox="0 0 95 88"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M75.198 76.4631H68.0743C62.6216 76.4631 57.1706 76.4631 51.7178 76.4631C45.6966 76.4631 39.6755 76.4631 33.6525 76.4631C29.5692 76.4631 25.486 76.4631 21.4027 76.4631C20.5583 76.4631 19.62 76.5464 18.7936 76.3599C16.3721 75.8112 14.999 73.7105 14.9936 71.3109C14.9882 68.3844 14.9936 65.4579 14.9936 62.5314C14.9936 57.046 14.9936 51.5606 14.9936 46.0752C14.9936 39.9287 14.9936 33.7823 14.9936 27.6377C14.9936 22.73 14.9936 17.8223 14.9936 12.9146C14.9936 11.5238 14.9936 10.1311 14.9936 8.74032C14.9936 7.67004 14.9449 6.62511 15.3906 5.60916C16.2819 3.57183 18.2342 2.72973 20.3219 2.72973C21.5705 2.72973 22.8173 2.72973 24.0659 2.72973C29.0045 2.72973 33.943 2.72973 38.8816 2.72973C44.9947 2.72973 51.1097 2.72973 57.2229 2.72973C62.0045 2.72973 66.7842 2.72973 71.5658 2.72973C72.67 2.72973 73.7743 2.72792 74.8786 2.72973C77.3885 2.73516 79.6637 4.33967 79.9705 6.97282C80.0517 7.66279 79.9976 8.3908 79.9976 9.08259C79.9976 10.5947 79.9976 12.1087 79.9976 13.6209C79.9976 18.6626 79.9976 23.7043 79.9976 28.746C79.9976 34.9069 79.9976 41.0678 79.9976 47.2269C79.9976 53.386 79.9976 57.9877 79.9976 63.3699C79.9976 66.0718 80.012 68.7756 79.9976 71.4775C79.9831 74.1795 77.9622 76.4106 75.198 76.4668C73.4586 76.503 73.4531 79.2194 75.198 79.1832C79.3516 79.0981 82.6428 75.7895 82.7041 71.617C82.7149 70.8709 82.7041 70.1248 82.7041 69.3804V56.8522C82.7041 50.7402 82.7041 44.6264 82.7041 38.5144C82.7041 32.4024 82.7041 26.5204 82.7041 20.5224C82.7041 16.6905 82.7041 12.8584 82.7041 9.02645C82.7041 8.07388 82.7348 7.13037 82.576 6.18686C81.9607 2.55406 78.6732 0.0368229 75.0879 0.00965848C72.1143 -0.0120731 69.1407 0.00965848 66.1671 0.00965848C60.3643 0.00965848 54.5615 0.00965848 48.7586 0.00965848C42.9558 0.00965848 36.7506 0.00965848 30.7475 0.00965848C27.2597 0.00965848 23.7718 0.00965848 20.2858 0.00965848C17.6911 0.00965848 15.3076 0.971281 13.7342 3.11546C12.6028 4.65659 12.2907 6.44039 12.2907 8.29663C12.2907 11.7175 12.2907 15.1385 12.2907 18.5594C12.2907 24.3961 12.2907 30.231 12.2907 36.0678C12.2907 41.9045 12.2907 48.4366 12.2907 54.6211C12.2907 59.1811 12.2907 63.7393 12.2907 68.2993C12.2907 69.3207 12.2871 70.3421 12.2907 71.3653C12.2997 74.2682 13.7396 77.0336 16.3938 78.3574C17.8625 79.089 19.3656 79.1796 20.948 79.1796C22.5304 79.1796 24.0064 79.1796 25.5365 79.1796C30.9171 79.1796 36.2977 79.1796 41.6801 79.1796C47.8871 79.1796 54.0941 79.1796 60.3011 79.1796C64.628 79.1796 68.9549 79.1796 73.2817 79.1796H75.2016C76.9428 79.1796 76.9464 76.4631 75.2016 76.4631H75.198Z"
                fill="#51AD32"
              />
            </svg>
          </div>

          <h2 className="text-[40px] font-bold text-white text-center leading-[40px] mb-8">
            Cette page est dédiée exclusivement
            <br />
            à la vente de places individuelles
            <br />
            pour des sorties organisées.
          </h2>

          <p className="text-base font-normal text-white text-center leading-[16.8px] mb-12 max-w-2xl mx-auto">
            Pour toute demande de location d'autocar avec conducteur (groupes,
            associations, entreprises, scolaires…)
          </p>

          <button className="bg-white text-[#1E1E1E] px-8 py-4 rounded-full text-base font-normal hover:bg-gray-50 transition-colors border border-[#1E1E1E]">
            Demander un devis
          </button>
        </div>
      </section>

      {/* CTA Section - Prêt pour vos déplacements */}
      <section className="py-24 relative">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex items-stretch gap-0">
            {/* Left - Image */}
            <div className="w-[350px] flex-shrink-0">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/02ad66be908d49d76636739feca12a8a54c09030?width=700"
                alt="Prêt pour vos déplacements"
                className="w-full h-full object-cover rounded-l-[40px]"
              />
            </div>

            {/* Right - Content */}
            <div className="flex-1 bg-[#51AD32] rounded-r-[40px] px-16 py-12 flex flex-col justify-center">
              <div className="text-center uppercase text-[#1E1E1E] text-base font-extrabold mb-4">
                voyage sur-mesure
              </div>
              <div className="w-[185px] h-[1px] bg-black mx-auto mb-12"></div>

              <h2 className="text-white text-[40px] font-bold text-center leading-tight mb-8">
                Prêt pour vos
                <br />
                déplacements
                <br />
                de proximité ?
              </h2>

              <p className="text-white text-xl text-center mb-12 max-w-[795px] mx-auto">
                Configurez votre transport en quelques clics
                <br />
                et recevez un devis personnalisé
                <br />
                adapté à vos besoins.
              </p>

              <div className="text-center">
                <button className="bg-white text-[#51AD32] px-12 py-4 rounded-full text-base hover:bg-gray-50 transition-colors">
                  personnaliser mon trajet
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
