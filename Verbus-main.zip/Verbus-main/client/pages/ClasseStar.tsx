import Layout from "@/components/Layout";
import { Link } from "react-router-dom";

export default function ClasseStar() {
  return (
    <Layout>
      {/* Breadcrumb */}
      <div className="bg-white py-6 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex items-center gap-2 text-base italic text-verbus-dark">
            <Link
              to="/vehicules"
              className="hover:text-verbus-green transition-colors"
            >
              Nos véhicules
            </Link>
            <span className="mx-2">|</span>
            <span>Classe star</span>
          </div>
          <div className="w-[206px] h-px bg-white mt-2"></div>
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 items-stretch">
            {/* Left Content - Black Background */}
            <div className="relative bg-black px-8 lg:px-16 py-16 lg:py-24 flex flex-col justify-center min-h-[600px]">
              {/* Decorative SVG - Pink Curve */}
              <div className="absolute -left-60 top-4">
                <svg
                  width="407"
                  height="359"
                  viewBox="0 0 82 359"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M77.3474 168.141C75.2361 162.938 72.9077 157.805 70.3623 152.762C67.6327 147.345 64.6531 142.03 61.4434 136.832C58.0429 131.327 54.3727 125.952 50.4592 120.725C46.3681 115.261 41.9942 109.969 37.3572 104.872C32.4439 99.4675 27.2281 94.2879 21.7491 89.345C16.2702 84.4021 10.0809 79.3586 3.83244 74.7946C-2.78436 69.9583 -9.684 65.4357 -16.8467 61.2742C-24.4501 56.8463 -32.3298 52.8032 -40.4331 49.1568C-49.0099 45.2972 -57.8367 41.8756 -66.828 38.8922C-76.4572 35.6956 -86.2837 32.9962 -96.2418 30.7527C-98.7938 30.1785 -101.352 29.6339 -103.924 29.1189C-104.404 29.0242 -105.148 29.0538 -104.904 29.6576C-104.661 30.2614 -103.648 30.6817 -103.036 30.806C-93.0124 32.8186 -83.0937 35.2753 -73.3724 38.2469C-64.3483 40.9995 -55.4755 44.1784 -46.8394 47.813C-38.7559 51.2168 -30.863 55.0053 -23.2531 59.1964C-15.6431 63.3875 -8.99995 67.5253 -2.28448 72.2018C4.0495 76.606 10.1138 81.3239 15.8953 86.3023C21.4137 91.0558 26.6624 96.0578 31.6283 101.285C36.3969 106.305 40.8958 111.526 45.1184 116.919C49.1174 122.027 52.8665 127.296 56.3525 132.706C59.8385 138.117 62.7589 143.125 65.6003 148.494C68.2707 153.537 70.724 158.67 72.9538 163.885C73.4734 165.098 73.9798 166.312 74.4731 167.537C74.7165 168.141 75.7031 168.555 76.3411 168.686C76.8212 168.786 77.5711 168.762 77.3211 168.147L77.3474 168.141Z"
                    fill="#E71D74"
                  />
                  <path
                    d="M-154.491 352.697C-104.937 365.649 -51.154 357.716 -6.67798 335.044C15.606 323.685 35.3512 307.572 49.8871 288.575C67.4618 265.607 77.5712 238.59 80.6362 210.928C83.425 185.764 77.4397 160.357 63.1471 138.561C49.578 117.866 29.1949 101.605 7.42383 88.1079C-11.6965 76.2569 -32.494 66.4777 -53.6073 57.8409C-73.8655 49.5594 -94.5052 42.373 -115.836 36.6428C-138.093 30.664 -160.752 25.9816 -183.477 21.6721C-214.963 15.6993 -246.587 10.3302 -278.191 4.87821C-287.142 3.33319 -296.094 1.78817 -305.046 0.237232C-314.465 -1.39658 -326.534 5.61816 -325.982 14.8291C-325.712 19.2747 -323.64 23.6374 -319.911 26.6505C-315.478 30.226 -310.591 31.7414 -304.789 32.7537C-271.107 38.6022 -237.378 44.2377 -203.762 50.3822C-203.163 50.4947 -202.558 50.6013 -201.959 50.7137C-198.184 51.4063 -207.747 49.6423 -203.992 50.3408C-202.236 50.6664 -200.486 50.992 -198.73 51.3175C-195.323 51.9569 -191.916 52.6021 -188.515 53.2592C-182.333 54.4549 -176.15 55.6862 -169.987 56.9648C-158.477 59.3564 -147.012 61.9196 -135.64 64.7965C-115.132 69.9761 -94.9722 76.2391 -75.4441 83.9109C-74.1813 84.4082 -72.925 84.9113 -71.6621 85.4145C-70.1625 86.0124 -68.0117 86.9299 -74.9771 84.0648C-74.3457 84.3253 -73.7143 84.5798 -73.0828 84.8462C-70.5308 85.8999 -67.992 86.9773 -65.4597 88.0724C-60.1255 90.381 -54.8373 92.7844 -49.6017 95.2588C-38.5452 100.48 -27.686 106.062 -17.2938 112.295C-14.3866 114.036 -11.5189 115.835 -8.69064 117.682C-8.03949 118.108 -7.3949 118.535 -6.75034 118.967C-2.896 121.554 -10.5192 116.327 -7.8685 118.191C-6.61221 119.073 -5.35593 119.961 -4.11938 120.867C1.18195 124.738 6.25964 128.864 11.015 133.275C13.3632 135.453 15.606 137.714 17.8029 140.017C19.9997 142.32 14.4287 136.222 16.5137 138.59C17.1517 139.318 17.7963 140.047 18.4277 140.781C19.3683 141.888 20.2891 143.006 21.1836 144.137C25.2287 149.263 28.7542 154.698 31.7271 160.386L29.6552 156.379C33.9568 164.761 36.9166 173.587 38.5346 182.703L37.7914 178.471C39.8304 190.505 39.5081 202.676 37.5152 214.699L38.2452 210.443C35.417 226.846 29.9183 242.894 21.519 257.687L23.7027 253.851C16.4545 266.436 7.17389 277.938 -3.87604 288.037L-0.515015 285C-11.315 294.773 -23.6015 303.073 -36.9535 309.815L-32.6651 307.66C-40.354 311.502 -48.3455 314.835 -56.5869 317.605C-60.7174 318.996 -64.9006 320.245 -69.1364 321.352C-70.1296 321.613 -71.1228 321.855 -72.116 322.11C-74.2865 322.661 -67.1961 320.973 -69.3798 321.465C-69.8797 321.577 -70.373 321.696 -70.8728 321.808C-72.9842 322.282 -75.1087 322.72 -77.2397 323.128C-85.5074 324.697 -93.9001 325.739 -102.339 326.218C-103.332 326.277 -104.325 326.325 -105.312 326.366C-106.239 326.402 -110.39 326.508 -105.943 326.414C-101.497 326.319 -105.634 326.396 -106.562 326.402C-107.667 326.402 -108.765 326.402 -109.87 326.39C-113.987 326.337 -118.111 326.141 -122.209 325.804C-126.701 325.431 -131.174 324.88 -135.607 324.14C-136.067 324.064 -136.528 323.981 -136.988 323.904C-139.988 323.395 -131.404 324.975 -133.785 324.49C-134.805 324.283 -135.824 324.087 -136.844 323.868C-139.08 323.389 -141.303 322.856 -143.513 322.276C-148.643 320.932 -154.451 320.695 -159.496 322.548C-163.646 324.069 -168.125 327.503 -169.323 331.576C-172.092 340.976 -164.442 350.116 -154.464 352.726L-154.491 352.697Z"
                    fill="#55AD32"
                  />
                </svg>
              </div>

              {/* Black Triangle on Left Edge */}
              <div className="absolute left-0 top-0 bottom-0 w-32 lg:w-48">
                <svg
                  viewBox="0 0 114 850"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-full w-full"
                  preserveAspectRatio="none"
                >
                  <path
                    d="M114.001 424.5L0.380536 0.000323736L9.45882e-05 849.381L114.001 424.5Z"
                    fill="black"
                  />
                </svg>
              </div>

              {/* Content - positioned above decorative elements */}
              <div className="relative z-10 max-w-md ml-16 lg:ml-24">
                {/* Title */}
                <div className="mb-4">
                  <div className="text-[40px] lg:text-[60px] font-bold leading-none text-verbus-green uppercase">
                    Classe
                  </div>
                  <div className="text-[60px] lg:text-[80px] font-bold leading-none text-verbus-green uppercase">
                    STAR
                  </div>
                </div>

                {/* Subtitle */}
                <div className="text-base font-bold uppercase text-verbus-dark mb-6">
                  Plus qu'un trajet... une expérience !
                </div>

                {/* Large Decorative Parenthesis */}
                <div className="text-[100px] font-light text-verbus-pink leading-none mb-4">
                  (
                </div>

                {/* Specs */}
                <div className="text-[15px] font-semibold uppercase text-verbus-pink mb-2">
                  CAPACITÉ : 48 places
                  <br />
                  écartement de sièges : 78 cm
                </div>

                <div className="text-[15px] font-semibold uppercase text-verbus-green mb-6">
                  3 ESSIEUX
                </div>

                {/* Description */}
                <p className="text-base text-white mb-8 leading-tight">
                  La Classe STAR est le véhicule signature de VERBUS, conçue pour faire de chaque déplacement une expérience à vivre.
                  Plus d'espace, plus d'options, plus de liberté pour composer une ambiance unique. Le transport devient un art de recevoir.
                </p>

                {/* CTA Buttons */}
                <div className="flex flex-col gap-3">
                  <Link
                    to="/devis"
                    className="inline-flex items-center justify-center px-6 py-3 rounded-full bg-verbus-green text-white text-base hover:bg-verbus-green/90 transition-colors"
                  >
                    Personnaliser mon trajet
                  </Link>
                  <Link
                    to="/devis"
                    className="inline-flex items-center justify-center px-6 py-3 rounded-full bg-white text-verbus-dark text-base hover:bg-gray-50 transition-colors"
                  >
                    Demander un devis
                  </Link>
                </div>
              </div>
            </div>

            {/* Right Image */}
            <div className="relative min-h-[400px] lg:min-h-[600px]">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/6964a46aff8bc5743147510a2ca122cfb6fcbcd9?width=3892"
                alt="Classe STAR vehicle"
                className="absolute inset-0 w-full h-full object-cover rounded-bl-[40px] lg:rounded-bl-[60px]"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Tagline Banner */}
      <div className="bg-[#976D31] py-8">
        <div className="max-w-7xl mx-auto px-8">
          <p className="text-white text-center text-xl">
            Incontournable pour transformer votre trajet en une parenthèse privilégiée.
          </p>
        </div>
      </div>

      {/* L'esprit de cette classe Section */}
      <section className="bg-[#FAFAFC] py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid lg:grid-cols-3 gap-12 items-start">
            {/* Left Image */}
            <div className="lg:col-span-1">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/a5e4c9c539c662ea12e2a20f9aeabe2116421a66?width=1200"
                alt="Passenger confort"
                className="w-full h-auto object-cover"
              />
            </div>

            {/* Center Content */}
            <div className="lg:col-span-1 flex flex-col items-center justify-center text-center">
              <div className="text-verbus-green text-2xl font-normal uppercase mb-6">
                l'esprit de cette classe
              </div>

              <h2 className="text-[35px] font-bold leading-tight text-verbus-dark mb-6">
                "Exclusivité, prestige
                <br />
                et hospitalité sur mesure"
              </h2>

              <p className="text-2xl font-bold text-verbus-dark leading-relaxed">
                Au cœur de la Classe STAR, un véhicule pensé pour offrir plus d'espace, plus d'options et plus de liberté.
                Chaque détail contribue à créer une expérience singulière, où le confort premium et l'ambiance à bord occupent une place centrale.
              </p>
            </div>

            {/* Right Image */}
            <div className="lg:col-span-1">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/f436c2646274be573e9e468bdbbda879395eaa3f?width=1194"
                alt="Luxury interior"
                className="w-full h-auto object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* L'expérience à bord Section */}
      <section className="bg-white py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-4">
            L'expérience à bord
          </h2>

          <p className="text-base font-bold text-center text-verbus-dark mb-12 max-w-2xl mx-auto leading-tight">
            Le summum du confort et de l'élégance.
          </p>

          <div className="grid md:grid-cols-2 gap-12 mb-16">
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/c106dda8394be4aeca35de213adbbd8c30c0e833?width=1574"
                alt="Voyages incentives & Séminaires"
                className="w-full h-auto object-cover rounded-[40px]"
              />
              <div className="absolute bottom-8 left-0 right-0 flex items-center justify-center">
                <div className="bg-white rounded-full w-80 h-80 flex items-center justify-center">
                  <h3 className="text-[35px] font-bold text-white text-center leading-tight">
                    Voyages incentives
                    <br />& Séminaires
                  </h3>
                </div>
              </div>
            </div>

            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/4230d03e08935ce2397fef21f6518be89950bb35?width=1828"
                alt="Évènements VIP"
                className="w-full h-auto object-cover rounded-[40px]"
              />
              <div className="absolute bottom-8 left-0 right-0 flex items-center justify-center">
                <div className="bg-white rounded-full w-80 h-80 flex items-center justify-center">
                  <h3 className="text-[35px] font-bold text-white text-center">
                    Évènements VIP
                  </h3>
                </div>
              </div>
            </div>
          </div>

          <p className="text-base font-bold text-center text-verbus-dark max-w-2xl mx-auto leading-tight">
            Une ambiance premium, travaillée avec des matériaux nobles, une lumière douce et un confort acoustique soigné.
            L'espace est optimisé pour le bien-être des passagers sur les trajets longue distance.
          </p>

          <div className="grid md:grid-cols-3 gap-8 mt-12">
            <div className="text-center">
              <div className="w-28 h-28 bg-[#3C56DA] rounded-full mx-auto mb-4 flex items-center justify-center">
                <svg
                  width="92"
                  height="111"
                  viewBox="0 0 92 111"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M0.166211 50.3606C-0.625408 46.6499 1.46888 42.9297 5.0368 41.7082C7.03087 41.0233 9.231 41.227 11.0698 42.2707C11.3998 42.4574 11.6917 42.6945 11.9854 42.9266L11.5257 40.771C10.7554 37.1612 11.6365 33.4449 13.94 30.5742C15.1675 29.0442 16.7194 27.875 18.4499 27.1044C13.2574 25.0605 9.56418 19.98 9.56418 14.0362C9.56355 6.29633 15.8176 0 23.5039 0C31.1903 0 37.4437 6.29633 37.4437 14.0368C37.4437 19.449 34.3812 24.1473 29.9139 26.4889C31.2698 26.8193 32.5819 27.3257 33.7975 28.0339L51.8726 38.2995L60.4564 31.1544C63.869 28.4432 68.6782 28.7907 71.6618 31.937C72.7778 33.1144 73.4755 34.5863 73.7749 36.1491L77.8638 27.3371C78.3874 26.2076 79.3162 25.3525 80.4786 24.9268C81.6422 24.5023 82.8985 24.556 84.0221 25.0857C85.1425 25.6135 85.9917 26.5488 86.4145 27.7193C86.8359 28.891 86.7802 30.1573 86.2566 31.2862L83.2242 37.8215H90.9969C91.5506 37.8215 91.999 38.2731 91.999 38.8305V68.9721C91.999 69.3883 91.7454 69.7617 91.3602 69.9124C91.2418 69.9591 91.1197 69.9811 90.9969 69.9811C90.7208 69.9811 90.4521 69.867 90.2579 69.6532L75.8222 53.7742L74.1882 57.2958C73.6058 58.5501 72.5098 59.4727 71.1821 59.8284C70.7913 59.9337 70.3911 59.9861 69.9921 59.9861C69.3189 59.9861 68.6475 59.8385 68.03 59.5478C66.9096 59.0206 66.0603 58.0847 65.6376 56.9136C65.2149 55.7418 65.2712 54.4755 65.7954 53.3467L69.5556 45.2435L56.9661 54.548C54.781 56.1631 51.9615 56.5503 49.4294 55.5873L37.356 50.9994L39.1948 61.8017C40.282 61.7998 41.3273 62.1574 42.1715 62.8694C43.1197 63.6697 43.7021 64.7928 43.8105 66.0346C43.8205 66.1493 43.8054 66.261 43.8073 66.3751L65.9063 69.8506C68.5892 70.2731 70.8908 71.9973 72.0614 74.4663L83.4108 98.396C84.5049 100.703 84.5488 103.369 83.5336 105.711C82.5177 108.054 80.5456 109.833 78.1231 110.594C77.2463 110.868 76.3595 111 75.4877 111C72.2204 111 69.1617 109.15 67.6592 106.035L59.1437 88.3807C58.6865 87.4348 57.717 86.8231 56.6718 86.8231H54.7722V95.2775C54.7722 98.7479 51.969 101.571 48.522 101.571H16.1451C13.2192 101.571 10.6495 99.4801 10.0351 96.5999L0.166211 50.3606Z"
                    fill="#51AD32"
                  />
                </svg>
              </div>
              <div className="text-2xl font-normal uppercase text-verbus-green mb-2">
                Confort premium et stabilité
              </div>
              <p className="text-base font-bold text-verbus-dark leading-tight">
                • Sellerie haut de gamme
                <br />
                • Têtières réglables
                <br />
                • Repose-mollets
                <br />
                • Autocar 3 essieux pour plus de stabilité
              </p>
            </div>

            <div className="text-center">
              <div className="w-28 h-28 bg-[#3C56DA] rounded-full mx-auto mb-4"></div>
              <div className="text-2xl font-normal uppercase text-verbus-green mb-2">
                Équipements embarqués
              </div>
              <p className="text-base font-bold text-verbus-dark leading-tight">
                Climatisation premium
                <br />
                Connectiques USB
                <br />
                Prises 230 V
                <br />
                Vidéo et sonorisation
                <br />
                Machine à café
                <br />
                Réfrigérateur
                <br />
                Toilettes à bord
              </p>
            </div>

            <div className="text-center">
              <div className="w-28 h-28 bg-[#3C56DA] rounded-full mx-auto mb-4"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="bg-[#FAFAFC] py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="relative rounded-[40px] overflow-hidden h-[525px]">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/a49283bcb84f31833eded37a5b7283823fa5df95?width=1570"
                alt="Délégations officielles"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end justify-center pb-12">
                <h3 className="text-[35px] font-bold text-white text-center">
                  Délégations officielles
                </h3>
              </div>
            </div>

            <div className="relative rounded-[40px] overflow-hidden h-[525px]">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/0ca25f018be53c171322750c1a15d94d9173890c?width=1572"
                alt="Tourisme d'affaires"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end justify-center pb-12">
                <h3 className="text-[35px] font-bold text-white text-center">
                  Tourisme d'affaires
                </h3>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Découvrez notre véhicule STAR Section */}
      <section className="bg-white py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-4">
            Découvrez notre véhicule STAR
          </h2>

          <p className="text-base font-bold text-center text-verbus-dark mb-12 max-w-2xl mx-auto">
            Le summum du confort et de l'élégance.
          </p>

          {/* Vehicle Images Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/d1114eea8912360e7760327d53419afa1d9c4f52?width=1750"
                alt="Autocar moderne et confortable"
                className="w-full h-auto rounded-lg"
              />
              <div className="bg-verbus-dark text-white text-base italic uppercase px-4 py-2 mt-2">
                Autocar moderne et confortable
              </div>
            </div>

            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/cb5c10ab8ae7c3fc484efcf41ddd74b56623754f?width=1012"
                alt="équipements CONVIVAUX"
                className="w-full h-auto rounded-lg"
              />
              <div className="bg-verbus-dark text-white text-base italic uppercase px-4 py-2 mt-2">
                équipements CONVIVAUX
              </div>
            </div>

            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/5014862f433dac91d6cb7611883b944eed775190?width=1230"
                alt="Intérieur spacieux"
                className="w-full h-auto rounded-lg"
              />
              <div className="bg-verbus-dark text-white text-base italic uppercase px-4 py-2 mt-2">
                Intérieur spacieux
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Essieux Section */}
      <section className="bg-[#FAFAFC] py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-4">
            Essieux pour plus de stabilité
          </h2>

          <p className="text-base font-bold text-center text-verbus-dark mb-12 max-w-2xl mx-auto">
            Stabilité exceptionnelle, rayon de braquage amélioré, conduite plus douce et sécurité renforcée sur longue distance.
          </p>

          <div className="grid md:grid-cols-2 gap-12 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="w-44 h-44 mx-auto mb-4 flex items-center justify-center">
                <svg
                  width="170"
                  height="173"
                  viewBox="0 0 170 173"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M87.7355 17.1896C87.745 18.9507 86.9336 20.0719 85.6431 20.3348C84.6704 20.5283 82.9101 19.8536 82.9053 18.3703L82.8911 2.10346C82.8911 0.694555 84.362 -0.00493472 85.292 2.62018e-05C86.3975 0.00498712 87.6643 0.798734 87.6691 2.20764L87.7355 17.1946V17.1896Z"
                    fill="#F1BDBF"
                  />
                  <path
                    d="M167.154 89.5147L153.826 89.4651C152.336 89.4601 151.572 88.2744 151.472 87.0888C151.359 85.7096 152.331 84.3751 153.883 84.3751L167.6 84.3503C169.208 84.3503 170.067 85.8138 169.996 87.1185C169.911 88.6614 168.81 89.5246 167.154 89.5196V89.5147Z"
                    fill="#E8668B"
                  />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-verbus-dark mb-2">
                stabilité maximale
              </h3>
              <p className="text-base font-bold text-verbus-dark">
                Conduite fluide même sur les longs trajets
              </p>
            </div>

            <div className="text-center">
              <div className="w-44 h-44 mx-auto mb-4 flex items-center justify-center">
                <svg
                  width="170"
                  height="173"
                  viewBox="0 0 170 173"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M87.7355 17.1896C87.745 18.9507 86.9336 20.0719 85.6431 20.3348C84.6704 20.5283 82.9101 19.8536 82.9053 18.3703L82.8911 2.10346C82.8911 0.694555 84.362 -0.00493472 85.292 2.62018e-05C86.3975 0.00498712 87.6643 0.798734 87.6691 2.20764L87.7355 17.1946V17.1896Z"
                    fill="#F1BDBF"
                  />
                  <path
                    d="M167.154 89.5147L153.826 89.4651C152.336 89.4601 151.572 88.2744 151.472 87.0888C151.359 85.7096 152.331 84.3751 153.883 84.3751L167.6 84.3503C169.208 84.3503 170.067 85.8138 169.996 87.1185C169.911 88.6614 168.81 89.5246 167.154 89.5196V89.5147Z"
                    fill="#E8668B"
                  />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-verbus-dark mb-2">
                Conduite douce
                <br />& sécurisée
              </h3>
              <p className="text-base font-bold text-verbus-dark">
                Sécurité renforcée
                <br />
                sur longue distance
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Caractéristiques principales Section */}
      <section className="bg-verbus-dark py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-white mb-12">
            Caractéristiques principales
          </h2>

          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-x-16 gap-y-6">
              {/* Left Column */}
              <div className="space-y-6">
                <div className="flex items-start gap-3">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-1 flex-shrink-0"
                  >
                    <path
                      d="M0.752441 5.64014L4.25244 9.64014L11.7524 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <span className="text-2xl text-white">repose-pieds</span>
                </div>

                <div className="flex items-start gap-3">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-1 flex-shrink-0"
                  >
                    <path
                      d="M0.752441 5.64014L4.25244 9.64014L11.7524 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <span className="text-2xl text-white">climatisation premium</span>
                </div>

                <div className="flex items-start gap-3">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-1 flex-shrink-0"
                  >
                    <path
                      d="M0.752441 5.64014L4.25244 9.64014L11.7524 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <span className="text-2xl text-white">lumière douce</span>
                </div>

                <div className="flex items-start gap-3">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-1 flex-shrink-0"
                  >
                    <path
                      d="M0.752441 5.64014L4.25244 9.64014L11.7524 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <span className="text-2xl text-white">prises 230 V</span>
                </div>

                <div className="flex items-start gap-3">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-1 flex-shrink-0"
                  >
                    <path
                      d="M0.752441 5.64014L4.25244 9.64014L11.7524 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <span className="text-2xl text-white">connectiques USB</span>
                </div>
              </div>

              {/* Right Column */}
              <div className="space-y-6">
                <div className="flex items-start gap-3">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-1 flex-shrink-0"
                  >
                    <path
                      d="M0.752441 5.64014L4.25244 9.64014L11.7524 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <span className="text-2xl text-white">sellerie haut de gamme</span>
                </div>

                <div className="flex items-start gap-3">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-1 flex-shrink-0"
                  >
                    <path
                      d="M0.752441 5.64014L4.25244 9.64014L11.7524 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <span className="text-2xl text-white">confort acoustique</span>
                </div>

                <div className="flex items-start gap-3">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-1 flex-shrink-0"
                  >
                    <path
                      d="M0.752441 5.64014L4.25244 9.64014L11.7524 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <span className="text-2xl text-white">réfrigérateur</span>
                </div>

                <div className="flex items-start gap-3">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-1 flex-shrink-0"
                  >
                    <path
                      d="M0.752441 5.64014L4.25244 9.64014L11.7524 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <span className="text-2xl text-white">toilettes</span>
                </div>

                <div className="flex items-start gap-3">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-1 flex-shrink-0"
                  >
                    <path
                      d="M0.752441 5.64014L4.25244 9.64014L11.7524 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <span className="text-2xl text-white">vidéo / sonorisation</span>
                </div>
              </div>
            </div>

            {/* Centered Icon */}
            <div className="flex justify-center mt-12">
              <svg
                width="190"
                height="176"
                viewBox="0 0 190 176"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M150.399 152.927H136.152C125.246 152.927 114.344 152.927 103.438 152.927C91.396 152.927 79.3537 152.927 67.3077 152.927C59.1411 152.927 50.9745 152.927 42.8079 152.927C41.119 152.927 39.2425 153.094 37.5897 152.721C32.7468 151.623 30.0005 147.422 29.9897 142.623C29.9788 136.77 29.9897 130.916 29.9897 125.063C29.9897 114.093 29.9897 103.122 29.9897 92.1508C29.9897 79.8579 29.9897 67.565 29.9897 55.2757C29.9897 45.4603 29.9897 35.6448 29.9897 25.8293C29.9897 23.0477 29.9897 20.2624 29.9897 17.4807C29.9897 15.3402 29.8922 13.2503 30.7836 11.2184C32.5663 7.14369 36.471 5.45948 40.6463 5.45948C43.1435 5.45948 45.6372 5.45948 48.1344 5.45948C58.0116 5.45948 67.8887 5.45948 77.7658 5.45948C89.9922 5.45948 102.222 5.45948 114.449 5.45948C124.012 5.45948 133.571 5.45948 143.135 5.45948C145.343 5.45948 147.552 5.45586 149.76 5.45948C154.78 5.47035 159.331 8.67939 159.944 13.9457C160.107 15.3257 159.998 16.7817 159.998 18.1653C159.998 21.1896 159.998 24.2175 159.998 27.2419C159.998 37.3254 159.998 47.4089 159.998 57.4924C159.998 69.8142 159.998 82.1361 159.998 94.4543C159.998 106.773 159.998 115.976 159.998 126.74C159.998 132.144 160.027 137.552 159.998 142.956C159.969 148.36 155.928 152.822 150.399 152.934C146.92 153.007 146.909 158.44 150.399 158.367C158.706 158.197 165.289 151.58 165.411 143.235C165.433 141.742 165.411 140.25 165.411 138.762V113.705C165.411 101.481 165.411 89.2532 165.411 77.0292C165.411 64.8051 165.411 53.041 165.411 41.0451C165.411 33.3811 165.411 25.717 165.411 18.053C165.411 16.1478 165.473 14.2608 165.155 12.3738C163.925 5.10815 157.349 0.0736463 150.179 0.019317C144.232 -0.0241463 138.284 0.019317 132.337 0.019317C120.732 0.019317 109.126 0.019317 97.5201 0.019317C85.9144 0.019317 73.5039 0.019317 61.4976 0.019317C54.5219 0.019317 47.5462 0.019317 40.5741 0.019317C35.3847 0.019317 30.6176 1.94257 27.4708 6.23096C25.2081 9.31323 24.5838 12.8809 24.5838 16.5933C24.5838 23.4352 24.5838 30.2771 24.5838 37.1189C24.5838 48.7925 24.5838 60.4624 24.5838 72.1359C24.5838 83.8094 24.5838 96.8738 24.5838 109.243C24.5838 118.363 24.5838 127.479 24.5838 136.599C24.5838 138.642 24.5766 140.685 24.5838 142.731C24.6018 148.537 27.4816 154.068 32.7901 156.716C35.7276 158.179 38.7337 158.36 41.8985 158.36C45.0634 158.36 48.0153 158.36 51.0756 158.36C61.8368 158.36 72.5981 158.36 83.363 158.36C95.7771 158.36 108.191 158.36 120.605 158.36C129.259 158.36 137.913 158.36 146.567 158.36H150.406C153.889 158.36 153.896 152.927 150.406 152.927H150.399Z"
                  fill="#51AD32"
                />
              </svg>
            </div>
          </div>
        </div>
      </section>

      {/* Pourquoi cette classe Section */}
      <section className="bg-verbus-green py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex items-start gap-8 mb-8">
            {/* Stars Decoration */}
            <div className="flex gap-2">
              {[...Array(5)].map((_, i) => (
                <svg
                  key={i}
                  width="68"
                  height="72"
                  viewBox="0 0 70 74"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M35.021 0.5C37.4054 0.500168 39.3496 1.98743 40.3062 4.2207L40.3101 4.23047L47.3267 21.5664L64.3257 23.6113H64.3267C66.6348 23.8588 68.488 25.5845 69.2056 27.8984C69.9292 30.2318 69.2851 32.7259 67.5972 34.416L67.5981 34.417L54.8638 47.2334L58.3784 65.918L58.4194 66.1426C58.8036 68.4734 57.925 70.7863 56.2007 72.1982L56.1919 72.2051C54.3267 73.6657 51.8708 73.8379 49.9019 72.6064L49.8989 72.6045L35.0942 63.1895L20.2915 72.6045C19.4102 73.1657 18.4274 73.5 17.4243 73.5H17.2017C15.9671 73.5 14.8218 73.0849 13.7778 72.2812L13.7749 72.2793C11.9038 70.8138 11.1099 68.3869 11.5884 65.9922L15.1021 47.3076L2.36768 34.416V34.415C0.671951 32.7159 0.119446 30.2236 0.756348 27.9131L0.759277 27.9023C1.47608 25.5116 3.2555 23.862 5.6333 23.6123L22.6411 21.5654L29.7319 4.22852L29.7349 4.2207C30.6914 1.98727 32.6364 0.5 35.021 0.5Z"
                    fill="#E71D73"
                    stroke="#E72475"
                  />
                </svg>
              ))}
            </div>
          </div>

          <h2 className="text-[40px] font-bold uppercase text-white mb-12">
            Pourquoi
            <br />
            cette classe ?
          </h2>

          <div className="space-y-6 max-w-2xl">
            <div className="flex items-start gap-4">
              <span className="text-[40px] font-medium text-black">1 )</span>
              <p className="text-2xl font-medium text-verbus-dark pt-2">
                une expérience de transport d'exception
              </p>
            </div>

            <div className="flex items-start gap-4">
              <span className="text-[40px] font-medium text-black">2 )</span>
              <p className="text-2xl font-medium text-verbus-dark pt-2">
                un confort premium et une ambiance soignée
              </p>
            </div>

            <div className="flex items-start gap-4">
              <span className="text-[40px] font-medium text-black">3 )</span>
              <p className="text-2xl font-medium text-verbus-dark pt-2">
                un véhicule signature VERBUS, pensé pour marquer les esprits
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            {/* Left Image */}
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/f07739647149f370499aa620aa42aa385fa8ba1d?width=700"
                alt="Voyage sur-mesure"
                className="w-full h-auto rounded-[40px]"
              />
              <div className="absolute top-8 left-1/2 -translate-x-1/2">
                <div className="text-base font-extrabold text-verbus-dark text-center uppercase">
                  voyage sur-mesure
                </div>
                <div className="w-48 h-px bg-black mx-auto mt-2"></div>
              </div>
            </div>

            {/* Right Content - Green */}
            <div className="bg-verbus-green rounded-r-[40px] py-16 px-12">
              <h2 className="text-[40px] font-bold text-white text-center mb-6 leading-tight">
                Prêt à créer
                <br />
                votre voyage idéal ?
              </h2>

              <p className="text-xl text-white text-center mb-6 leading-tight">
                En quelques questions, nous préparons avec vous
                <br />
                un devis adapté à votre projet,
                <br />
                au nombre de voyageurs et à votre budget.
              </p>

              <div className="flex justify-center">
                <Link
                  to="/devis"
                  className="inline-flex items-center justify-center px-8 py-4 rounded-full bg-white text-verbus-green text-base hover:bg-gray-50 transition-colors"
                >
                  personnaliser mon trajet
                </Link>
              </div>

              <p className="text-[13px] italic text-white text-center mt-4">
                Réponse garantie sous 24h à 48h ouvrées • Sans engagement
              </p>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
