import PlaceholderPage from "@/components/PlaceholderPage";

export default function Contact() {
  return (
    <PlaceholderPage
      title="Contact"
      description="Contactez-nous pour toute demande d'information"
    />
  );
}
