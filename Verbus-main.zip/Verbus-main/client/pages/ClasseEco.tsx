import Layout from "@/components/Layout";
import { Link } from "react-router-dom";

export default function ClasseEco() {
  return (
    <Layout>
      {/* Breadcrumb */}
      <div className="bg-white py-6 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex items-center gap-2 text-base italic text-verbus-dark">
            <Link
              to="/vehicules"
              className="hover:text-verbus-green transition-colors"
            >
              Nos véhicules
            </Link>
            <span className="mx-2">|</span>
            <span>Classe eco</span>
          </div>
          <div className="w-[206px] h-px bg-verbus-green mt-2"></div>
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 items-stretch">
            {/* Left Content - Green Background */}
            <div className="relative bg-verbus-green px-8 lg:px-16 py-16 lg:py-24 flex flex-col justify-center">
              {/* Decorative SVG */}
              <div className="absolute -left-40 top-4">
                <svg
                  width="407"
                  height="359"
                  viewBox="0 0 82 359"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M77.3474 168.141C75.236 162.938 72.9076 157.805 70.3622 152.762C67.6326 147.345 64.6531 142.03 61.4433 136.832C58.0428 131.327 54.3727 125.952 50.4592 120.725C46.3681 115.261 41.9941 109.969 37.3571 104.872C32.4438 99.4675 27.228 94.2879 21.7491 89.345C16.2701 84.4021 10.0809 79.3586 3.83238 74.7946C-2.78442 69.9583 -9.68406 65.4357 -16.8468 61.2742C-24.4502 56.8463 -32.3298 52.8032 -40.4331 49.1568C-49.01 45.2972 -57.8368 41.8756 -66.828 38.8922C-76.4573 35.6956 -86.2838 32.9962 -96.2419 30.7527C-98.7939 30.1785 -101.352 29.6339 -103.924 29.1189C-104.404 29.0242 -105.148 29.0538 -104.904 29.6576C-104.661 30.2614 -103.648 30.6817 -103.036 30.806C-93.0124 32.8186 -83.0938 35.2753 -73.3725 38.2469C-64.3484 40.9995 -55.4755 44.1784 -46.8395 47.813C-38.7559 51.2168 -30.8631 55.0053 -23.2531 59.1964C-15.6431 63.3875 -9.00001 67.5253 -2.28454 72.2018C4.04944 76.606 10.1137 81.3239 15.8952 86.3023C21.4136 91.0558 26.6623 96.0578 31.6282 101.285C36.3968 106.305 40.8957 111.526 45.1184 116.919C49.1174 122.027 52.8665 127.296 56.3525 132.706C59.8385 138.117 62.7588 143.125 65.6002 148.494C68.2706 153.537 70.724 158.67 72.9537 163.885C73.4733 165.098 73.9798 166.312 74.4731 167.537C74.7164 168.141 75.703 168.555 76.341 168.686C76.8212 168.786 77.571 168.762 77.3211 168.147L77.3474 168.141Z"
                    fill="#E71D74"
                  />
                </svg>
              </div>

              {/* Green Triangle on Left Edge */}
              <div className="absolute left-0 top-0 bottom-0 w-32 lg:w-48">
                <svg
                  viewBox="0 0 114 850"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-full w-full"
                >
                  <path
                    d="M114 424.5L0.380414 0.000323736L-2.74821e-05 849.381L114 424.5Z"
                    fill="#51AD32"
                  />
                </svg>
              </div>

              {/* Title */}
              <div className="relative z-10 mb-6">
                <p className="text-base font-bold uppercase text-verbus-dark mb-2">
                  Responsable et bien pensée
                </p>
                <h1 className="text-white font-bold uppercase">
                  <span className="text-[40px] leading-tight">Classe</span>
                  <br />
                  <span className="text-[60px] leading-tight">eco</span>
                </h1>
              </div>

              {/* Stars */}
              <div className="relative z-10 flex gap-2 mb-6">
                <svg
                  width="40"
                  height="43"
                  viewBox="0 0 42 45"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M21.0123 0.5C22.5146 0.500124 23.7234 1.45364 24.3112 2.84668L24.3151 2.85645L28.3981 13.0967L38.2731 14.3037C39.729 14.4622 40.8773 15.5639 41.318 17.0068C41.7646 18.4692 41.3675 20.0335 40.3229 21.0957L40.3239 21.0967L32.9059 28.6758L34.9547 39.7324L34.9996 40.0146C35.1802 41.4245 34.6412 42.8126 33.6041 43.6748L33.5953 43.6816C32.4327 44.6059 30.891 44.7191 29.6539 43.9336L29.65 43.9316L21.0553 38.3818L12.4606 43.9307L12.4615 43.9316C11.9165 44.2841 11.2988 44.5 10.6608 44.5H10.5299C9.75215 44.4999 9.03451 44.2335 8.38831 43.7285L8.3844 43.7256C7.21758 42.7976 6.73206 41.2697 7.026 39.7764L9.07385 28.7207L1.65491 21.0957V21.0947C0.60296 20.0237 0.266969 18.4611 0.657837 17.0215L0.660767 17.0107C1.10076 15.521 2.20473 14.4654 3.69983 14.3047L13.5826 13.0967L17.7096 2.85449L17.7125 2.84668C18.3003 1.45347 19.5099 0.5 21.0123 0.5Z"
                    fill="#E71D73"
                    stroke="#E72475"
                  />
                </svg>
                <svg
                  width="40"
                  height="43"
                  viewBox="0 0 42 45"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M21.0123 0.5C22.5146 0.500124 23.7234 1.45364 24.3112 2.84668L24.3151 2.85645L28.3981 13.0967L38.2731 14.3037C39.729 14.4622 40.8773 15.5639 41.318 17.0068C41.7646 18.4692 41.3675 20.0335 40.3229 21.0957L40.3239 21.0967L32.9059 28.6758L34.9547 39.7324L34.9996 40.0146C35.1802 41.4245 34.6412 42.8126 33.6041 43.6748L33.5953 43.6816C32.4327 44.6059 30.891 44.7191 29.6539 43.9336L29.65 43.9316L21.0553 38.3818L12.4606 43.9307L12.4615 43.9316C11.9165 44.2841 11.2988 44.5 10.6608 44.5H10.5299C9.75215 44.4999 9.03451 44.2335 8.38831 43.7285L8.3844 43.7256C7.21758 42.7976 6.73206 41.2697 7.026 39.7764L9.07385 28.7207L1.65491 21.0957V21.0947C0.60296 20.0237 0.266969 18.4611 0.657837 17.0215L0.660767 17.0107C1.10076 15.521 2.20473 14.4654 3.69983 14.3047L13.5826 13.0967L17.7096 2.85449L17.7125 2.84668C18.3003 1.45347 19.5099 0.5 21.0123 0.5Z"
                    fill="#E71D73"
                    stroke="#E72475"
                  />
                </svg>
              </div>

              {/* Large Opening Parenthesis */}
              <div className="absolute left-16 lg:left-20 bottom-32 text-verbus-pink text-[100px] font-light leading-none">
                (
              </div>

              {/* Capacity & Specs */}
              <div className="relative z-10 mb-8">
                <p className="text-[15px] font-semibold uppercase text-verbus-pink leading-tight mb-2">
                  CAPACITÉ : 26 à 63 places
                  <br />
                  écartement de sièges : 73 cm
                </p>
                <p className="text-[15px] font-semibold uppercase text-verbus-dark">
                  CONFORT TOURISME SIMPLE
                </p>
              </div>

              {/* Description */}
              <p className="relative z-10 text-base text-white mb-8 leading-relaxed">
                Confortable et accessible, la Classe ÉCO permet de voyager dans
                de bonnes conditions, en conciliant confort simple et maîtrise
                des coûts. Elle est adaptée aux trajets quotidiens, aux sorties
                pédagogiques et aux séjours de plusieurs jours.
              </p>

              {/* CTA Buttons */}
              <div className="relative z-10 flex flex-col gap-4">
                <Link
                  to="/devis"
                  className="px-6 py-3 rounded-full bg-verbus-green border-2 border-verbus-dark text-verbus-dark font-normal text-base hover:bg-verbus-green/90 transition-colors text-center"
                >
                  Personnaliser mon trajet
                </Link>
                <Link
                  to="/devis"
                  className="px-6 py-3 rounded-full bg-white text-verbus-dark font-normal text-base hover:bg-white/90 transition-colors text-center"
                >
                  Demander un devis
                </Link>
              </div>
            </div>

            {/* Right Content - Bus Image */}
            <div className="relative h-[600px] lg:h-auto">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/9122c3545dd87b1844b22f484330acbf7800d895?width=4024"
                alt="Classe Eco Bus"
                className="w-full h-full object-cover rounded-tl-[40px]"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Green Bar with Text */}
      <section className="bg-verbus-green py-6">
        <div className="max-w-7xl mx-auto px-8">
          <p className="text-white text-center text-xl leading-tight">
            Parfaite pour les trajets de plusieurs heures où l'on veut voyager
            serein en maîtrisant le budget
          </p>
        </div>
      </section>

      {/* Quote Section */}
      <section className="bg-verbus-gray py-16">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid lg:grid-cols-3 gap-8 items-center">
            {/* Left Image */}
            <div className="hidden lg:block">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/e4291c5dd6b79c61a4f825c5116f5f075395ced9?width=1200"
                alt="Groupe voyageant ensemble"
                className="w-full h-auto rounded-[40px] object-cover"
              />
            </div>

            {/* Center Text */}
            <div className="text-center">
              <p className="text-verbus-green text-2xl uppercase font-normal mb-6">
                l'esprit de cette classe
              </p>
              <h2 className="text-verbus-dark text-4xl font-bold mb-6 leading-tight">
                "Confort sobre mais bien présent, pour un moment convivial"
              </h2>
              <p className="text-verbus-dark text-2xl font-bold leading-relaxed">
                La Classe ÉCO a été conçue pour permettre aux groupes de voyager
                sereinement, sur des trajets de plusieurs heures, avec un niveau de
                confort adapté et accessible.
              </p>
            </div>

            {/* Right Image */}
            <div className="hidden lg:block">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/7c7abcd54cf5034728634ade09ad16c6dbbcabcf?width=1200"
                alt="Intérieur de bus confortable"
                className="w-full h-auto rounded-[40px] object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Experience Section with Blue Icon */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-12">
            L'expérience à bord
          </h2>

          {/* Comfort Icon with Description */}
          <div className="flex flex-col items-center mb-12">
            <div className="relative w-24 h-24 mb-6">
              <svg
                width="110"
                height="110"
                viewBox="0 0 110 110"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="55" cy="55" r="55" fill="#3C56DA" />
              </svg>
            </div>
            <h3 className="text-2xl text-verbus-green uppercase font-normal mb-4 text-center">
              Confort essentiel
            </h3>
            <p className="text-base text-verbus-green uppercase text-center mb-6">
              Tout ce qu'il faut pour voyager agréablement
            </p>
            <div className="text-center text-base font-bold text-verbus-dark space-y-2">
              <p>Sièges inclinables avec repose-pieds</p>
              <p>Liseuses individuelles</p>
              <p>Ambiance feutrée et reposante</p>
            </div>
          </div>

          {/* Connected Icon with Description */}
          <div className="flex flex-col items-center">
            <div className="relative w-24 h-24 mb-6">
              <svg
                width="110"
                height="110"
                viewBox="0 0 110 110"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="55" cy="55" r="55" fill="#3C56DA" />
              </svg>
            </div>
            <h3 className="text-2xl text-verbus-green uppercase font-normal mb-4 text-center">
              Connecté et pratique
            </h3>
            <p className="text-base text-verbus-green uppercase text-center mb-6">
              Restez connectés tout au long du trajet
            </p>
            <div className="text-center text-base font-bold text-verbus-dark space-y-2">
              <p>Connectiques USB pour tous</p>
              <p>Prises 230V disponibles</p>
              <p>Lecteur DVD embarqué</p>
            </div>
          </div>

          {/* Note at bottom */}
          <p className="text-center text-base font-bold text-verbus-dark mt-12 leading-relaxed">
            Le confort classique du tourisme, dans une ambiance feutrée.
            <br />
            Pensée pour les sorties qui durent toute une journée.
          </p>

          <p className="text-center text-base font-bold text-verbus-dark mt-8">
            La Classe ÉCO est disponible selon les sites en : 26, 39, 55, 59 et
            63 places.
          </p>
        </div>
      </section>

      {/* Use Cases - 4 Images Grid */}
      <section className="py-20 bg-verbus-gray">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            {/* Sorties Scolaires */}
            <div className="relative rounded-[40px] overflow-hidden h-[525px]">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/78dc5fff7428bfc8818bf085bc418d89058dca0a?width=1574"
                alt="Sorties scolaires"
                className="w-full h-full object-cover"
              />
              <div className="absolute top-8 left-1/2 -translate-x-1/2">
                <div className="w-80 h-80 bg-white rounded-full flex items-center justify-center">
                  <svg
                    width="130"
                    height="132"
                    viewBox="0 0 130 132"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="w-32 h-32"
                  >
                    <path
                      d="M28.3001 28.7757H25.6192C23.5671 28.7757 21.5157 28.7757 19.4636 28.7757C17.1977 28.7757 14.9317 28.7757 12.6651 28.7757C11.1284 28.7757 9.5917 28.7757 8.05502 28.7757C7.73723 28.7757 7.38413 28.8071 7.07312 28.7369C6.16185 28.5304 5.64509 27.7398 5.64306 26.8368C5.64102 25.7354 5.64306 24.6341 5.64306 23.5327C5.64306 21.4684 5.64306 19.404 5.64306 17.3397C5.64306 15.0266 5.64306 12.7135 5.64306 10.401C5.64306 8.5541 5.64306 6.70715 5.64306 4.86021C5.64306 4.3368 5.64306 3.8127 5.64306 3.28929C5.64306 2.8865 5.62472 2.49326 5.79245 2.11092C6.12789 1.3442 6.86262 1.02729 7.64827 1.02729C8.11817 1.02729 8.58739 1.02729 9.05729 1.02729C10.9158 1.02729 12.7744 1.02729 14.6329 1.02729C16.9335 1.02729 19.2348 1.02729 21.5354 1.02729C23.3349 1.02729 25.1337 1.02729 26.9331 1.02729C27.3487 1.02729 27.7643 1.02661 28.1799 1.02729C29.1244 1.02934 29.9807 1.63317 30.0961 2.62411C30.1267 2.88378 30.1063 3.15775 30.1063 3.41809C30.1063 3.98717 30.1063 4.55693 30.1063 5.12601C30.1063 7.02338 30.1063 8.92076 30.1063 10.8181C30.1063 13.1367 30.1063 15.4553 30.1063 17.7731C30.1063 20.091 30.1063 21.8228 30.1063 23.8483C30.1063 24.8651 30.1117 25.8827 30.1063 26.8995C30.1009 27.9163 29.3404 28.756 28.3001 28.7771C27.6455 28.7907 27.6434 29.813 28.3001 29.7994C29.8632 29.7674 31.1018 28.5222 31.1249 26.952C31.129 26.6712 31.1249 26.3904 31.1249 26.1103V21.3955C31.1249 19.0953 31.1249 16.7945 31.1249 14.4943C31.1249 12.1941 31.1249 9.98054 31.1249 7.72331C31.1249 6.2812 31.1249 4.83908 31.1249 3.39697C31.1249 3.03848 31.1364 2.68341 31.0767 2.32833C30.8451 0.961183 29.6079 0.0138578 28.2586 0.00363482C27.1396 -0.00454353 26.0205 0.00363482 24.9014 0.00363482C22.7176 0.00363482 20.5338 0.00363482 18.35 0.00363482C16.1662 0.00363482 13.831 0.00363482 11.5718 0.00363482C10.2592 0.00363482 8.94661 0.00363482 7.63469 0.00363482C6.65823 0.00363482 5.76121 0.365527 5.16908 1.17246C4.74332 1.75244 4.62585 2.42374 4.62585 3.12231C4.62585 4.40972 4.62585 5.69713 4.62585 6.98454C4.62585 9.1811 4.62585 11.377 4.62585 13.5736C4.62585 15.7701 4.62585 18.2284 4.62585 20.5558C4.62585 22.2719 4.62585 23.9873 4.62585 25.7034C4.62585 26.0878 4.62449 26.4722 4.62585 26.8572C4.62924 27.9497 5.17112 28.9904 6.16999 29.4886C6.72274 29.764 7.28838 29.798 7.8839 29.798C8.47942 29.798 9.03488 29.798 9.61071 29.798C11.6356 29.798 13.6605 29.798 15.6861 29.798C18.022 29.798 20.358 29.798 22.6939 29.798C24.3222 29.798 25.9506 29.798 27.5789 29.798H28.3014C28.9567 29.798 28.958 28.7757 28.3014 28.7757H28.3001Z"
                      fill="#51AD32"
                    />
                  </svg>
                </div>
              </div>
              <div className="absolute bottom-8 left-0 right-0">
                <h3 className="text-white text-4xl font-bold text-center">
                  sorties scolaires
                </h3>
              </div>
            </div>

            {/* Colonies de Vacances */}
            <div className="relative rounded-[40px] overflow-hidden h-[525px]">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/c69e41dae9ee77ab8f80bd02d58c0d85c229d31b?width=1572"
                alt="Colonies de vacances"
                className="w-full h-full object-cover"
              />
              <div className="absolute top-8 left-1/2 -translate-x-1/2">
                <div className="w-80 h-80 bg-white rounded-full"></div>
              </div>
              <div className="absolute bottom-8 left-0 right-0">
                <h3 className="text-white text-4xl font-bold text-center">
                  colonies de vacances
                </h3>
              </div>
            </div>

            {/* Clubs Sportifs */}
            <div className="relative rounded-[40px] overflow-hidden h-[525px]">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/3d87de1f714ef7e456b3eddd5981f243e8b884fc?width=1570"
                alt="Clubs sportifs"
                className="w-full h-full object-cover"
              />
              <div className="absolute top-8 left-1/2 -translate-x-1/2">
                <div className="w-80 h-80 bg-white rounded-full"></div>
              </div>
              <div className="absolute bottom-8 left-0 right-0">
                <h3 className="text-white text-4xl font-bold text-center">
                  clubs sportifs
                </h3>
              </div>
            </div>

            {/* Associations */}
            <div className="relative rounded-[40px] overflow-hidden h-[525px]">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/5a781dbb9c561313fd715159886809983b17b14a?width=1572"
                alt="Associations"
                className="w-full h-full object-cover"
              />
              <div className="absolute top-8 left-1/2 -translate-x-1/2">
                <div className="w-80 h-80 bg-white rounded-full"></div>
              </div>
              <div className="absolute bottom-8 left-0 right-0">
                <h3 className="text-white text-4xl font-bold text-center">
                  associations
                </h3>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Découvrez nos véhicules - Gallery */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-12">
            Découvrez nos véhicules
          </h2>

          {/* Pink decorative curve */}
          <div className="relative">
            <svg
              width="279"
              height="317"
              viewBox="0 0 279 317"
              className="absolute -right-24 -top-12 w-64 h-auto opacity-50"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M-49.9025 235.113C-63.1434 235.113 -77.1287 232.5 -92.7374 226.529C-142.803 207.38 -167.051 161.346 -185.804 114.448C-199.757 79.5405 -222.351 58.2854 -252.943 51.269C-297.575 41.0295 -356.985 62.2846 -404.278 105.42L-416.505 116.571L-438.806 92.1162L-426.579 80.966C-371.501 30.7346 -300.434 6.41473 -245.53 19.0142C-204.319 28.4697 -173.03 57.2242 -155.061 102.166C-133.244 156.737 -111.759 183.812 -80.9062 195.612C-45.4836 209.162 -23.0882 200.102 19.5646 176.21C61.7343 152.579 105.868 140.106 147.238 140.106C147.507 140.106 147.776 140.106 148.045 140.106C196.503 140.297 238.894 158.083 270.634 191.55L282.022 203.555L258.003 226.339L246.616 214.333C188.441 152.999 99.5484 169.352 35.7514 205.091C4.68445 222.498 -20.8074 235.113 -49.8867 235.113H-49.9025Z"
                fill="#55AD32"
              />
            </svg>

            {/* Pink star decoration */}
            <div className="absolute right-0 -top-4">
              <svg
                width="126"
                height="129"
                viewBox="0 0 126 129"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M36.3556 23.3989C45.7146 31.2754 53.0342 41.3122 57.914 53.9462L57.9383 53.9947C61.4464 62.5873 61.5435 68.5948 59.5284 73.1459C23.9983 69.8934 10.9492 36.9795 6.08153 6.80851C17.6498 10.8135 27.8584 16.2263 36.3677 23.3989M59.0672 38.2296C59.1036 34.4916 60.6573 27.9258 62.2597 25.4014C63.6556 23.1805 65.5735 21.5178 67.8192 20.6197C70.0527 19.7216 72.6019 19.6731 75.3574 20.3406C81.014 21.712 87.4112 27.4889 87.4112 27.4889C70.0406 35.3411 84.8741 52.5748 73.403 67.903C71.388 70.5973 68.6325 72.3449 65.0151 72.9881C66.4961 67.8787 65.9134 61.2887 62.2475 52.2835C57.0764 38.8728 49.2955 28.2292 39.3538 19.8551C29.4608 11.5174 17.4434 5.44923 3.77517 1.17723L0 0L0.801162 3.87151C7.69597 37.0888 15.6954 70.6822 56.6394 77.5029C53.1192 81.3744 47.7539 84.0929 42.0486 86.9814C33.3452 91.399 23.9376 96.1807 18.0382 105.234C18.0382 105.234 10.9977 114.931 13.9596 128.014C20.2474 107.686 19.8954 107.043 44.1608 91.1441C51.7596 87.2848 58.8244 83.7046 62.6966 77.9519C69.0452 77.7456 74.01 75.3669 77.1175 70.6944C93.6747 45.7905 66.4111 29.5642 106.736 29.2851L125.988 28.9088L92.7158 25.7898C92.7158 25.7898 84.5221 18.0104 77.251 16.0079C73.2452 14.9035 69.2151 15.0491 66.0712 16.3113C62.9273 17.5735 60.099 20.292 58.6545 23.6295C55.9961 29.7584 59.0672 38.2538 59.0672 38.2538V38.2296Z"
                  fill="#E71D74"
                />
              </svg>
            </div>

            <div className="grid lg:grid-cols-3 gap-6">
              {/* Image 1 - Autocar */}
              <div className="relative">
                <img
                  src="https://api.builder.io/api/v1/image/assets/TEMP/b07e92311b097eff1a7edb525ab247c12a0401bd?width=1750"
                  alt="Autocar moderne et confortable"
                  className="w-full h-auto rounded-[40px]"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-verbus-dark py-2">
                  <p className="text-white text-center text-base italic uppercase">
                    Autocar moderne et confortable
                  </p>
                </div>
              </div>

              {/* Image 2 - Équipements */}
              <div className="relative">
                <img
                  src="https://api.builder.io/api/v1/image/assets/TEMP/ca31ae75dcfe82e3fe80fbe221dc6fcfffa4fd42?width=1012"
                  alt="équipements conviviaux"
                  className="w-full h-auto rounded-[40px]"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-verbus-dark py-2">
                  <p className="text-white text-center text-base italic uppercase">
                    équipements CONVIVAUX
                  </p>
                </div>
              </div>

              {/* Image 3 - Intérieur */}
              <div className="relative">
                <img
                  src="https://api.builder.io/api/v1/image/assets/TEMP/4e79cb602178e362d178b2abf2e40b57e65d1e1f?width=1230"
                  alt="Intérieur spacieux"
                  className="w-full h-auto rounded-[40px]"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-verbus-dark py-2">
                  <p className="text-white text-center text-base italic uppercase">
                    Intérieur spacieux
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Caractéristiques principales - Dark Section */}
      <section className="bg-verbus-dark py-20">
        <div className="max-w-6xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-white mb-16">
            Caractéristiques principales
          </h2>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Left Column */}
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <svg
                  width="13"
                  height="12"
                  viewBox="0 0 13 12"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="mt-1 flex-shrink-0"
                >
                  <path
                    d="M0.752563 5.64014L4.25256 9.64014L11.7526 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <p className="text-white text-2xl">climatisation</p>
              </div>
              <div className="flex items-start gap-4">
                <svg
                  width="13"
                  height="12"
                  viewBox="0 0 13 12"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="mt-1 flex-shrink-0"
                >
                  <path
                    d="M0.752563 5.64014L4.25256 9.64014L11.7526 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <p className="text-white text-2xl">repose-pieds</p>
              </div>
              <div className="flex items-start gap-4">
                <svg
                  width="13"
                  height="12"
                  viewBox="0 0 13 12"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="mt-1 flex-shrink-0"
                >
                  <path
                    d="M0.752563 5.64014L4.25256 9.64014L11.7526 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <p className="text-white text-2xl">connectiques USB</p>
              </div>
              <div className="flex items-start gap-4">
                <svg
                  width="13"
                  height="12"
                  viewBox="0 0 13 12"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="mt-1 flex-shrink-0"
                >
                  <path
                    d="M0.752563 5.64014L4.25256 9.64014L11.7526 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <p className="text-white text-2xl">prises 230 V</p>
              </div>
            </div>

            {/* Right Column */}
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <svg
                  width="13"
                  height="12"
                  viewBox="0 0 13 12"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="mt-1 flex-shrink-0"
                >
                  <path
                    d="M0.752563 5.64014L4.25256 9.64014L11.7526 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <p className="text-white text-2xl">liseuses</p>
              </div>
              <div className="flex items-start gap-4">
                <svg
                  width="13"
                  height="12"
                  viewBox="0 0 13 12"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="mt-1 flex-shrink-0"
                >
                  <path
                    d="M0.752563 5.64014L4.25256 9.64014L11.7526 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <p className="text-white text-2xl">ambiance feutrée</p>
              </div>
              <div className="flex items-start gap-4">
                <svg
                  width="13"
                  height="12"
                  viewBox="0 0 13 12"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="mt-1 flex-shrink-0"
                >
                  <path
                    d="M0.752563 5.64014L4.25256 9.64014L11.7526 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <p className="text-white text-2xl">soute à bagages</p>
              </div>
            </div>
          </div>

          {/* Bus Icon */}
          <div className="flex justify-center mt-16">
            <svg
              width="190"
              height="176"
              viewBox="0 0 190 176"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M150.399 152.927H136.152C125.246 152.927 114.344 152.927 103.438 152.927C91.3959 152.927 79.3535 152.927 67.3076 152.927C59.141 152.927 50.9744 152.927 42.8078 152.927C41.1189 152.927 39.2424 153.094 37.5896 152.721C32.7466 151.623 30.0004 147.422 29.9895 142.623C29.9787 136.77 29.9895 130.916 29.9895 125.063C29.9895 114.093 29.9895 103.122 29.9895 92.1508C29.9895 79.8579 29.9895 67.565 29.9895 55.2757C29.9895 45.4603 29.9895 35.6448 29.9895 25.8293C29.9895 23.0477 29.9895 20.2624 29.9895 17.4807C29.9895 15.3402 29.8921 13.2503 30.7835 11.2184C32.5662 7.14369 36.4708 5.45948 40.6462 5.45948C43.1434 5.45948 45.6371 5.45948 48.1343 5.45948C58.0114 5.45948 67.8886 5.45948 77.7657 5.45948C89.9921 5.45948 102.222 5.45948 114.449 5.45948C124.012 5.45948 133.571 5.45948 143.134 5.45948C145.343 5.45948 147.552 5.45586 149.76 5.45948C154.78 5.47035 159.331 8.67939 159.944 13.9457C160.106 15.3257 159.998 16.7817 159.998 18.1653C159.998 21.1896 159.998 24.2175 159.998 27.2419C159.998 37.3254 159.998 47.4089 159.998 57.4924C159.998 69.8142 159.998 82.1361 159.998 94.4543C159.998 106.773 159.998 115.976 159.998 126.74C159.998 132.144 160.027 137.552 159.998 142.956C159.969 148.36 155.927 152.822 150.399 152.934C146.92 153.007 146.909 158.44 150.399 158.367C158.706 158.197 165.289 151.58 165.411 143.235C165.433 141.742 165.411 140.25 165.411 138.762V113.705C165.411 101.481 165.411 89.2532 165.411 77.0292C165.411 64.8051 165.411 53.041 165.411 41.0451C165.411 33.3811 165.411 25.717 165.411 18.053C165.411 16.1478 165.473 14.2608 165.155 12.3738C163.924 5.10815 157.349 0.0736463 150.179 0.019317C144.232 -0.0241463 138.284 0.019317 132.337 0.019317C120.731 0.019317 109.126 0.019317 97.52 0.019317C85.9142 0.019317 73.5038 0.019317 61.4975 0.019317C54.5218 0.019317 47.5461 0.019317 40.574 0.019317C35.3846 0.019317 30.6175 1.94257 27.4706 6.23096C25.208 9.31323 24.5837 12.8809 24.5837 16.5933C24.5837 23.4352 24.5837 30.2771 24.5837 37.1189C24.5837 48.7925 24.5837 60.4624 24.5837 72.1359C24.5837 83.8094 24.5837 96.8738 24.5837 109.243C24.5837 118.363 24.5837 127.479 24.5837 136.599C24.5837 138.642 24.5764 140.685 24.5837 142.731C24.6017 148.537 27.4815 154.068 32.7899 156.716C35.7275 158.179 38.7335 158.36 41.8984 158.36C45.0633 158.36 48.0152 158.36 51.0754 158.36C61.8367 158.36 72.598 158.36 83.3629 158.36C95.7769 158.36 108.191 158.36 120.605 158.36C129.259 158.36 137.913 158.36 146.566 158.36H150.406C153.889 158.36 153.896 152.927 150.406 152.927H150.399Z"
                fill="#51AD32"
              />
            </svg>
          </div>
        </div>
      </section>

      {/* Pourquoi cette classe - Green Section */}
      <section className="relative bg-white py-20 overflow-hidden">
        <div className="absolute left-0 top-0 bottom-0 w-1/2 bg-verbus-green rounded-r-[40px]"></div>

        <div className="relative max-w-6xl mx-auto px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left - Green Content */}
            <div className="text-white">
              <div className="flex items-center gap-4 mb-8">
                <svg
                  width="68"
                  height="72"
                  viewBox="0 0 70 74"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M35.0211 0.5C37.4055 0.500168 39.3497 1.98743 40.3063 4.2207L40.3102 4.23047L47.3268 21.5664L64.3258 23.6113H64.3268C66.6349 23.8588 68.4881 25.5845 69.2057 27.8984C69.9293 30.2318 69.2852 32.7259 67.5973 34.416L67.5983 34.417L54.8639 47.2334L58.3785 65.918L58.4196 66.1426C58.8037 68.4734 57.9251 70.7863 56.2008 72.1982L56.192 72.2051C54.3269 73.6657 51.8709 73.8379 49.902 72.6064L49.899 72.6045L35.0944 63.1895L20.2916 72.6045C19.4103 73.1657 18.4275 73.5 17.4244 73.5H17.2018C15.9673 73.5 14.8219 73.0849 13.778 72.2812L13.775 72.2793C11.9039 70.8138 11.11 68.3869 11.5885 65.9922L15.1022 47.3076L2.3678 34.416V34.415C0.672074 32.7159 0.119568 30.2236 0.75647 27.9131L0.759399 27.9023C1.47621 25.5116 3.25562 23.862 5.63342 23.6123L22.6412 21.5654L29.7321 4.22852L29.735 4.2207C30.6916 1.98727 32.6365 0.5 35.0211 0.5Z"
                    fill="#E71D73"
                    stroke="#E72475"
                  />
                </svg>
                <svg
                  width="68"
                  height="72"
                  viewBox="0 0 70 74"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M35.0211 0.5C37.4055 0.500168 39.3497 1.98743 40.3063 4.2207L40.3102 4.23047L47.3268 21.5664L64.3258 23.6113H64.3268C66.6349 23.8588 68.4881 25.5845 69.2057 27.8984C69.9293 30.2318 69.2852 32.7259 67.5973 34.416L67.5983 34.417L54.8639 47.2334L58.3785 65.918L58.4196 66.1426C58.8037 68.4734 57.9251 70.7863 56.2008 72.1982L56.192 72.2051C54.3269 73.6657 51.8709 73.8379 49.902 72.6064L49.899 72.6045L35.0944 63.1895L20.2916 72.6045C19.4103 73.1657 18.4275 73.5 17.4244 73.5H17.2018C15.9673 73.5 14.8219 73.0849 13.778 72.2812L13.775 72.2793C11.9039 70.8138 11.11 68.3869 11.5885 65.9922L15.1022 47.3076L2.3678 34.416V34.415C0.672074 32.7159 0.119568 30.2236 0.75647 27.9131L0.759399 27.9023C1.47621 25.5116 3.25562 23.862 5.63342 23.6123L22.6412 21.5654L29.7321 4.22852L29.735 4.2207C30.6916 1.98727 32.6365 0.5 35.0211 0.5Z"
                    fill="#E71D73"
                    stroke="#E72475"
                  />
                </svg>
              </div>
              <h2 className="text-[40px] font-bold uppercase mb-8 leading-tight">
                Pourquoi
                <br />
                cette classe ?
              </h2>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <span className="text-[40px] font-medium">1 )</span>
                  <p className="text-2xl font-medium pt-2">
                    un bon niveau de confort pour les trajets de plusieurs
                    heures
                  </p>
                </div>
                <div className="flex items-start gap-4">
                  <span className="text-[40px] font-medium">2 )</span>
                  <p className="text-2xl font-medium pt-2">
                    une solution responsable et accessible, adaptée aux budgets
                    maîtrisés
                  </p>
                </div>
                <div className="flex items-start gap-4">
                  <span className="text-[40px] font-medium">3 )</span>
                  <p className="text-2xl font-medium pt-2">
                    des équipements utiles pour voyager sereinement en groupe
                  </p>
                </div>
              </div>
            </div>

            {/* Right - Empty Space for balance */}
            <div></div>
          </div>
        </div>
      </section>

      {/* Bottom CTA Section */}
      <section className="relative bg-white py-20">
        <div className="max-w-4xl mx-auto px-8">
          <div className="bg-verbus-green rounded-r-[40px] p-12 relative overflow-hidden">
            {/* Decorative Image on Left */}
            <div className="absolute left-0 top-0 bottom-0 w-1/3">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/f07739647149f370499aa620aa42aa385fa8ba1d?width=700"
                alt=""
                className="w-full h-full object-cover rounded-[40px]"
              />
            </div>

            {/* Content */}
            <div className="relative ml-auto max-w-xl text-center">
              <div className="mb-4">
                <p className="text-base font-bold uppercase text-verbus-dark">
                  voyage sur-mesure
                </p>
                <div className="w-48 h-px bg-black mx-auto mt-2"></div>
              </div>

              <h3 className="text-[40px] font-bold text-white leading-tight mb-6">
                Besoin d'un transport confortable pour vos trajets de plusieurs
                heures ?
              </h3>

              <p className="text-xl text-white mb-8">
                En quelques questions, nous préparons avec vous
                <br />
                un devis adapté à votre projet,
                <br />
                au nombre de voyageurs et à votre budget.
              </p>

              <Link
                to="/devis"
                className="inline-block px-8 py-4 rounded-full bg-white text-verbus-green font-normal text-base hover:bg-white/90 transition-colors"
              >
                personnaliser mon trajet
              </Link>

              <p className="text-sm italic text-white mt-4">
                Réponse garantie sous 24h à 48h ouvrées • Sans engagement
              </p>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
