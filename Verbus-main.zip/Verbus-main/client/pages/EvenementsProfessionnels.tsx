import { Link } from "react-router-dom";

export default function EvenementsProfessionnels() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative h-[926px] overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/302d71e49f5cac3e9ff3758018c15f436525f1a4?width=4456"
            alt="Événements Professionnels"
            className="w-full h-full object-cover rounded-[40px]"
          />
        </div>

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#1E1E1E] via-[#1E1E1E]/80 to-transparent" />

        {/* Decorative SVG Elements */}
        <div className="absolute left-[132px] top-[351px]">
          <svg width="36" height="33" viewBox="0 0 36 33" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M28.3742 28.7757H25.6863C23.6289 28.7757 21.5722 28.7757 19.5147 28.7757C17.2429 28.7757 14.971 28.7757 12.6984 28.7757C11.1578 28.7757 9.61708 28.7757 8.07641 28.7757C7.75778 28.7757 7.40376 28.8071 7.09195 28.7369C6.1783 28.5304 5.6602 27.7398 5.65816 26.8368C5.65612 25.7354 5.65816 24.6341 5.65816 23.5327C5.65816 21.4684 5.65816 19.404 5.65816 17.3397C5.65816 15.0266 5.65816 12.7135 5.65816 10.401C5.65816 8.5541 5.65816 6.70715 5.65816 4.86021C5.65816 4.3368 5.65816 3.8127 5.65816 3.28929C5.65816 2.8865 5.63978 2.49326 5.80794 2.11092C6.14426 1.3442 6.8809 1.02729 7.6686 1.02729C8.13972 1.02729 8.61016 1.02729 9.08128 1.02729C10.9447 1.02729 12.8081 1.02729 14.6714 1.02729C16.978 1.02729 19.2853 1.02729 21.5919 1.02729C23.3961 1.02729 25.1995 1.02729 27.0037 1.02729C27.4203 1.02729 27.837 1.02661 28.2537 1.02729C29.2007 1.02934 30.0592 1.63317 30.1749 2.62411C30.2055 2.88378 30.1851 3.15775 30.1851 3.41809C30.1851 3.98717 30.1851 4.55693 30.1851 5.12601C30.1851 7.02338 30.1851 8.92076 30.1851 10.8181C30.1851 13.1367 30.1851 15.4553 30.1851 17.7731C30.1851 20.091 30.1851 21.8228 30.1851 23.8483C30.1851 24.8651 30.1906 25.8827 30.1851 26.8995C30.1797 27.9163 29.4172 28.756 28.3742 28.7771C27.7179 28.7907 27.7158 29.813 28.3742 29.7994C29.9414 29.7674 31.1832 28.5222 31.2063 26.952C31.2104 26.6712 31.2063 26.3904 31.2063 26.1103V21.3955C31.2063 19.0953 31.2063 16.7945 31.2063 14.4943C31.2063 12.1941 31.2063 9.98054 31.2063 7.72331C31.2063 6.2812 31.2063 4.83908 31.2063 3.39697C31.2063 3.03848 31.2179 2.68341 31.158 2.32833C30.9258 0.961183 29.6854 0.0138578 28.3326 0.00363482C27.2106 -0.00454353 26.0887 0.00363482 24.9667 0.00363482C22.7772 0.00363482 20.5877 0.00363482 18.3982 0.00363482C16.2087 0.00363482 13.8674 0.00363482 11.6023 0.00363482C10.2863 0.00363482 8.97031 0.00363482 7.65498 0.00363482C6.67597 0.00363482 5.77662 0.365527 5.18295 1.17246C4.75608 1.75244 4.6383 2.42374 4.6383 3.12231C4.6383 4.40972 4.6383 5.69713 4.6383 6.98454C4.6383 9.1811 4.6383 11.377 4.6383 13.5736C4.6383 15.7701 4.6383 18.2284 4.6383 20.5558C4.6383 22.2719 4.6383 23.9873 4.6383 25.7034C4.6383 26.0878 4.63694 26.4722 4.6383 26.8572C4.6417 27.9497 5.18499 28.9904 6.18647 29.4886C6.74065 29.764 7.30777 29.798 7.90484 29.798C8.50191 29.798 9.05882 29.798 9.63615 29.798C11.6663 29.798 13.6965 29.798 15.7274 29.798C18.0694 29.798 20.4114 29.798 22.7534 29.798C24.386 29.798 26.0185 29.798 27.6511 29.798H28.3755C29.0325 29.798 29.0339 28.7757 28.3755 28.7757H28.3742Z" fill="#51AD32"/>
            <path d="M4.78605 15.2627C5.46891 15.9463 6.15176 16.6299 6.83462 17.3134C7.13418 17.6133 7.4242 17.9404 7.7755 18.1817C8.21326 18.4823 8.73613 18.6056 9.26103 18.609C10.752 18.6186 12.2437 18.609 13.7347 18.609H26.378C26.4713 18.609 26.5653 18.6111 26.6592 18.609C27.4108 18.5933 28.0447 18.2778 28.5689 17.7537C29.3294 16.9924 30.0905 16.2305 30.851 15.4692C30.9197 15.4004 30.9885 15.3315 31.0573 15.2627C31.5223 14.7972 30.8006 14.0741 30.3349 14.5396C29.6657 15.2095 28.9964 15.8795 28.3272 16.5494C28.0705 16.8064 27.8146 17.1267 27.5089 17.3284C27.2032 17.5302 26.888 17.5854 26.5428 17.586C25.0443 17.5908 23.5465 17.586 22.0481 17.586H9.5354C9.42103 17.586 9.30597 17.5881 9.19159 17.586C8.68439 17.5758 8.30858 17.3421 7.96409 16.9965C7.21451 16.2462 6.46494 15.4958 5.71536 14.7454C5.6466 14.6766 5.57784 14.6078 5.50907 14.5389C5.04408 14.0734 4.32174 14.7959 4.78673 15.262L4.78605 15.2627Z" fill="#51AD32"/>
          </svg>
        </div>

        <div className="absolute left-[187px] top-[224px] w-[262px] h-[1px] bg-[#51AD32]" />

        {/* Decorative Curve SVG - Left */}
        <div className="absolute -left-[445px] top-[4524px]">
          <svg width="261" height="336" viewBox="0 0 261 336" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M-74.9413 235.113C-88.2166 235.113 -102.238 232.5 -117.888 226.529C-168.083 207.38 -192.395 161.346 -211.196 114.448C-225.186 79.5405 -247.839 58.2854 -278.51 51.269C-323.259 41.0295 -382.823 62.2846 -430.24 105.42L-442.499 116.571L-464.857 92.1162L-452.598 80.966C-397.377 30.7346 -326.125 6.41473 -271.078 19.0142C-229.76 28.4697 -198.389 57.2242 -180.374 102.166C-158.5 156.737 -136.959 183.812 -106.026 195.612C-70.5109 209.162 -48.0571 200.102 -5.29327 176.21C36.9862 152.579 81.2347 140.106 122.712 140.106C122.982 140.106 123.252 140.106 123.522 140.106C172.106 140.297 214.608 158.083 246.43 191.55L257.848 203.555L233.766 226.339L222.349 214.333C164.023 152.999 74.8988 169.352 10.9357 205.091C-20.2122 222.498 -45.7704 235.113 -74.9254 235.113H-74.9413Z" fill="#55AD32"/>
          </svg>
        </div>

        {/* Main Content */}
        <div className="relative z-10 max-w-[600px] pt-[514px] pl-[119px]">
          <div className="flex items-center gap-2 mb-6">
            <span className="text-white text-base italic">Services l Événements Professionnels</span>
          </div>

          <h1 className="text-white text-[40px] font-bold leading-tight capitalize mb-8">
            évènements professionnels
          </h1>

          <p className="text-white text-base leading-tight mb-12 max-w-[401px]">
            Un transport professionnel fiable, précis et accueillant pour vos événements corporate.
            Séminaires, congrès, conventions, incentives ou transferts VIP : VERBUS organise des solutions de transport à la hauteur de l'image de votre entreprise, avec rigueur, discrétion et ponctualité.
          </p>

          <Link href="/contact">
            <button className="bg-[#51AD32] text-white px-8 py-3 rounded-full text-base font-normal hover:bg-[#459629] transition-colors">
              demander un devis
            </button>
          </Link>
        </div>
      </section>

      {/* Pourquoi les entreprises choisissent VERBUS Section */}
      <section className="py-24 bg-[#FAFAFC]">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-[#1E1E1E] text-center uppercase leading-[45px] mb-20">
            Pourquoi les entreprises choisissent Verbus ?
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-16 max-w-6xl mx-auto">
            {/* Benefit 1 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg width="103" height="103" viewBox="0 0 103 103" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="51.5" cy="51.5" r="51.5" fill="#51AD32" fillOpacity="0.1"/>
                  <path d="M67.092 13.1482C67.0993 14.4948 66.4789 15.3521 65.492 15.5532C64.7482 15.7011 63.4022 15.1852 63.3986 14.051L63.3877 1.61234C63.3877 0.535007 64.5124 0.000132855 65.2235 0.00392629C66.0689 0.00771972 67.0376 0.614669 67.0412 1.692L67.092 13.152V13.1482Z" fill="#F1BDBF" transform="translate(18, 18)"/>
                  <path d="M41.1265 78.0284C41.1265 78.0284 41.1216 78.0382 41.1167 78.0382C41.1167 78.0382 41.1216 78.0284 41.1265 78.0284Z" fill="#51AD32" transform="translate(18, 18)"/>
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-[#1E1E1E] mb-4">Ponctualité garantie</h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px]">
                Gestion précise des horaires, coordination multi-sites et respect des plannings serrés.
              </p>
            </div>

            {/* Benefit 2 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg width="103" height="103" viewBox="0 0 103 103" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="51.5" cy="51.5" r="51.5" fill="#51AD32" fillOpacity="0.1"/>
                  <path d="M20.4535 83.3795C9.1758 83.3795 0 74.1746 0 62.8656C0 51.5567 9.1758 42.3472 20.4535 42.3472C31.7311 42.3472 40.9069 51.5521 40.9069 62.8656C40.9069 74.1791 31.7311 83.3795 20.4535 83.3795Z" fill="#51AD32" transform="translate(31, 10)"/>
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-[#1E1E1E] mb-4">Discrétion assurée</h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px]">
                Conducteurs habitués aux accueils corporate, confidentialité et professionnalisme.
              </p>
            </div>

            {/* Benefit 3 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg width="116" height="121" viewBox="0 0 116 121" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M114.543 121H1.45724C0.652567 121 0 120.349 0 119.545V105.448C0 96.0293 6.33923 87.6582 15.4114 85.0818L41.3522 77.7198C43.0842 75.2805 44.1881 72.4396 44.6493 69.2606C44.7524 68.5455 45.4148 68.0508 46.1311 68.1537C46.8475 68.2565 47.343 68.9178 47.2351 69.6329C46.6905 73.38 45.3412 76.7304 43.2215 79.586C43.0351 79.8407 42.7554 80.0318 42.4463 80.1248L16.1277 87.5946C8.17427 89.8526 2.62008 97.195 2.62008 105.448V118.389H113.39V105.448C113.39 97.195 107.836 89.8526 99.8772 87.5946L73.5537 80.1248C73.2446 80.0367 72.9698 79.8456 72.7735 79.586C70.6049 76.6618 69.2408 73.2135 68.7257 69.3488C68.6324 68.6337 69.1329 67.9773 69.8493 67.8794C70.5607 67.7814 71.2231 68.2859 71.3212 69.001C71.7628 72.2877 72.8815 75.2168 74.6576 77.7198L100.598 85.0818C109.671 87.6582 116.01 96.0342 116.01 105.448V119.545C116.01 120.349 115.357 121 114.553 121H114.543Z" fill="#51AD32" transform="translate(0, 0)"/>
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-[#1E1E1E] mb-4">Interlocuteur dédié</h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px]">
                Un seul contact pour organiser l'ensemble de vos déplacements professionnels.
              </p>
            </div>

            {/* Benefit 4 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg width="94" height="105" viewBox="0 0 94 105" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M58.0002 107.712L40.7194 80.4139C40.3318 79.8066 40.5133 78.9984 41.1266 78.6114C41.74 78.2245 42.5446 78.4106 42.9322 79.018L58.0002 102.823L73.0681 79.018C73.4557 78.4106 74.2604 78.2245 74.8737 78.6114C75.487 78.9984 75.6686 79.8017 75.2809 80.4139L58.0002 107.712Z" fill="#51AD32" transform="translate(11, -20)"/>
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-[#1E1E1E] mb-4">Fiabilité opérationnelle</h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px]">
                Suivi en temps réel, plans B anticipés et réactivité en cas d'imprévu.
              </p>
            </div>

            {/* Benefit 5 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg width="91" height="109" viewBox="0 0 91 109" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M41.7703 26.637C61.8099 24.5618 79.7396 39.2326 81.819 59.4039C83.8984 79.5752 69.3427 97.6144 49.3031 99.6896C29.2635 101.765 11.3338 87.0941 9.25439 66.9228C7.17502 46.7515 21.7307 28.7123 41.7703 26.637Z" fill="#51AD32" transform="translate(0, 0)"/>
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-[#1E1E1E] mb-4">Connectivité embarquée</h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px]">
                WiFi, prises USB et espace de travail selon les classes de véhicules.
              </p>
            </div>

            {/* Benefit 6 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg width="71" height="86" viewBox="0 0 71 86" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M67.3092 86H3.69078C1.65523 86 0 84.3342 0 82.2855V3.71445C0 1.66585 1.65523 0 3.69078 0H52.9156C53.3024 0 53.6741 0.154406 53.9463 0.430598L70.5721 17.163C70.8466 17.4392 71 17.8111 71 18.2004V82.2855C71 84.3342 69.3448 86 67.3092 86Z" fill="#51AD32"/>
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-[#1E1E1E] mb-4">Facturation simplifiée</h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px]">
                Devis détaillé, facturation centralisée et suivi administratif clair.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Prestations professionnelles Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-8 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left - Image */}
          <div>
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/24ad684b5b223ba0b1789f56949200666cb17764?width=1452"
              alt="Prestations professionnelles"
              className="w-full h-[726px] object-cover rounded-[40px]"
            />
          </div>

          {/* Right - Content */}
          <div>
            <h2 className="text-[40px] font-bold text-[#1E1E1E] leading-[45px] lowercase mb-12">
              Prestations professionnelles
            </h2>

            <div className="space-y-10">
              <div className="flex items-start gap-4">
                <svg width="13" height="12" viewBox="0 0 13 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0 mt-1">
                  <path d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137" stroke="#51AD32" strokeWidth="2"/>
                </svg>
                <span className="text-[25px] text-[#1E1E1E]">Séminaires d'entreprise</span>
              </div>

              <div className="flex items-start gap-4">
                <svg width="13" height="12" viewBox="0 0 13 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0 mt-1">
                  <path d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137" stroke="#51AD32" strokeWidth="2"/>
                </svg>
                <span className="text-[25px] text-[#1E1E1E]">Congrès et conventions</span>
              </div>

              <div className="flex items-start gap-4">
                <svg width="13" height="12" viewBox="0 0 13 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0 mt-1">
                  <path d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137" stroke="#51AD32" strokeWidth="2"/>
                </svg>
                <span className="text-[25px] text-[#1E1E1E]">Incentives</span>
              </div>

              <div className="flex items-start gap-4">
                <svg width="13" height="12" viewBox="0 0 13 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0 mt-1">
                  <path d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137" stroke="#51AD32" strokeWidth="2"/>
                </svg>
                <span className="text-[25px] text-[#1E1E1E]">Transferts aéroport VIP</span>
              </div>

              <div className="flex items-start gap-4">
                <svg width="13" height="12" viewBox="0 0 13 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0 mt-1">
                  <path d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137" stroke="#51AD32" strokeWidth="2"/>
                </svg>
                <span className="text-[25px] text-[#1E1E1E]">Navettes événementielles</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-24 bg-[#FAFAFC]">
        <div className="max-w-4xl mx-auto px-8 text-center relative">
          {/* Decorative Quote SVG */}
          <div className="absolute left-0 top-0">
            <svg width="66" height="58" viewBox="0 0 66 58" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M91.6719 21.971C80.9191 22.8208 70.5399 25.4873 60.5254 29.027C59.6221 29.3467 56.2173 30.4226 57.3985 31.7091C63.105 37.9465 69.8363 43.2639 76.0552 49.0646C77.9139 50.7955 87.5723 47.3649 85.9481 45.8524C79.7205 40.0516 72.9979 34.742 67.2914 28.4968L64.1646 31.1789C71.5908 28.5514 79.1386 26.4073 87.1294 25.7758C88.9794 25.6277 93.0963 25.1287 94.156 23.5225C95.2156 21.9164 93.244 21.8462 91.6719 21.971Z" fill="#E71D74"/>
            </svg>
          </div>

          <p className="text-[25px] font-bold text-[#1E1E1E] text-center leading-[30px] mb-8 max-w-[640px] mx-auto">
            "Une discrétion et une ponctualité remarquables. Verbus comprend les exigences du monde professionnel et s'adapte à nos contraintes."
          </p>

          <div className="text-center">
            <p className="text-[25px] text-[#1E1E1E] font-normal">Jean-Pierre M.</p>
            <p className="text-base text-[#1E1E1E] italic">Directeur événementiel, PME</p>
          </div>
        </div>
      </section>

      {/* Classes recommandées Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-8">
          {/* Decorative SVG */}
          <div className="relative mb-16">
            <div className="absolute left-1/2 -translate-x-1/2 -top-12">
              <svg width="405" height="241" viewBox="0 0 405 241" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M178.75 168.141C176.633 162.938 174.298 157.805 171.746 152.762C169.01 147.345 166.022 142.03 162.804 136.832C159.395 131.327 155.715 125.952 151.791 120.725C147.69 115.261 143.304 109.969 138.655 104.872C133.729 99.4675 128.5 94.2879 123.007 89.345C117.513 84.4021 111.308 79.3586 105.043 74.7946C98.4092 69.9583 91.4916 65.4357 84.3102 61.2742C76.687 56.8463 68.7868 52.8032 60.6624 49.1568C52.0632 45.2972 43.2135 41.8756 34.1988 38.8922C24.5445 35.6956 14.6924 32.9962 4.70833 30.7527C2.14968 30.1785 -0.415568 29.6339 -2.99401 29.1189C-3.4754 29.0242 -4.22059 29.0538 -3.9766 29.6576C-3.7326 30.2614 -2.71705 30.6817 -2.10377 30.806C7.94621 32.8186 17.8907 35.2753 27.6373 38.2469C36.6849 40.9995 45.5809 44.1784 54.2394 47.813C62.344 51.2168 70.2574 55.0053 77.8872 59.1964C85.517 63.3875 92.1774 67.5253 98.9104 72.2018C105.261 76.606 111.341 81.3239 117.137 86.3023C122.67 91.0558 127.933 96.0578 132.911 101.285C137.692 106.305 142.203 111.526 146.437 116.919C150.446 122.027 154.205 127.296 157.7 132.706C161.195 138.117 164.123 143.125 166.972 148.494C169.649 153.537 172.109 158.67 174.345 163.885C174.865 165.098 175.373 166.312 175.868 167.537C176.112 168.141 177.101 168.555 177.741 168.686C178.222 168.786 178.974 168.762 178.723 168.147L178.75 168.141Z" fill="#E71D74" transform="translate(50, 20)"/>
              </svg>
            </div>
          </div>

          <h2 className="text-[40px] font-bold text-[#1E1E1E] text-center leading-[45px] lowercase mb-6">
            Classes recommandées pour le corporate
          </h2>

          <p className="text-base font-bold text-[#1E1E1E] text-center lowercase mb-20">
            Des véhicules à la hauteur de votre image d'entreprise.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto mb-12">
            {/* Classe Confort */}
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/4ba67a6a7e91808ee4e75a8b597d873dbae72a2a?width=1452"
                alt="Classe Confort"
                className="w-full h-[726px] object-cover rounded-[40px]"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-[#51AD32] rounded-b-[40px] p-8 text-center">
                <div className="mb-4">
                  <div className="text-white text-[40px] font-bold uppercase">CLASSE</div>
                  <div className="text-white text-[55px] font-bold uppercase leading-tight">confort</div>
                </div>
                <div className="flex justify-center gap-2 mb-6">
                  {[...Array(3)].map((_, i) => (
                    <svg key={i} width="40" height="43" viewBox="0 0 40 43" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M9.53057 43C8.87546 43 8.26402 42.7781 7.69625 42.3344C6.69174 41.5356 6.255 40.2043 6.51704 38.8731L8.61341 27.5573L1.01408 19.7472C0.0969229 18.8153 -0.208797 17.4396 0.140597 16.1527C0.533666 14.8215 1.4945 13.934 2.76105 13.8008L12.9372 12.5583L17.1736 2.04128C17.6977 0.798762 18.7458 0 20.0124 0C21.279 0 22.3271 0.798762 22.8512 2.04128L27.044 12.5583L37.2201 13.8008C38.443 13.934 39.4475 14.8658 39.8405 16.1527C40.2336 17.4396 39.8842 18.8153 38.967 19.7472L31.3677 27.5129L33.4641 38.8287C33.7261 40.16 33.2457 41.4912 32.2849 42.29C31.2804 43.0887 29.9701 43.1775 28.922 42.5119L20.0561 36.7874L11.1902 42.5119C10.7098 42.8225 10.1857 43 9.66159 43H9.53057Z" fill="#E71D74"/>
                    </svg>
                  ))}
                </div>
                <p className="text-white text-base mb-6">Espace généreux et équipements pour vos séminaires d'équipe.</p>
                <Link href="/classe-confort">
                  <button className="bg-white text-[#1E1E1E] px-8 py-3 rounded-full text-base border border-[#1E1E1E] hover:bg-gray-50 transition-colors">
                    découvrir
                  </button>
                </Link>
              </div>
            </div>

            {/* Classe Star */}
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/bbcedb7f9c88bf2f04cbd9f1345f00871fbd5ce6?width=1452"
                alt="Classe Star"
                className="w-full h-[726px] object-cover rounded-[40px]"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-[#51AD32] rounded-b-[40px] p-8 text-center">
                <div className="mb-4">
                  <div className="text-white text-[40px] font-bold uppercase">CLASSE</div>
                  <div className="text-white text-[55px] font-bold uppercase leading-tight">star</div>
                </div>
                <div className="flex justify-center gap-2 mb-6">
                  {[...Array(4)].map((_, i) => (
                    <svg key={i} width="40" height="43" viewBox="0 0 40 43" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M9.53057 43C8.87546 43 8.26402 42.7781 7.69625 42.3344C6.69174 41.5356 6.255 40.2043 6.51704 38.8731L8.61341 27.5573L1.01408 19.7472C0.0969229 18.8153 -0.208797 17.4396 0.140597 16.1527C0.533666 14.8215 1.4945 13.934 2.76105 13.8008L12.9372 12.5583L17.1736 2.04128C17.6977 0.798762 18.7458 0 20.0124 0C21.279 0 22.3271 0.798762 22.8512 2.04128L27.044 12.5583L37.2201 13.8008C38.443 13.934 39.4475 14.8658 39.8405 16.1527C40.2336 17.4396 39.8842 18.8153 38.967 19.7472L31.3677 27.5129L33.4641 38.8287C33.7261 40.16 33.2457 41.4912 32.2849 42.29C31.2804 43.0887 29.9701 43.1775 28.922 42.5119L20.0561 36.7874L11.1902 42.5119C10.7098 42.8225 10.1857 43 9.66159 43H9.53057Z" fill="#E71D74"/>
                    </svg>
                  ))}
                </div>
                <p className="text-white text-base mb-6">Prestations haut de gamme pour évènements corporate.</p>
                <Link href="/classe-star">
                  <button className="bg-white text-[#1E1E1E] px-8 py-3 rounded-full text-base border border-[#1E1E1E] hover:bg-gray-50 transition-colors">
                    découvrir
                  </button>
                </Link>
              </div>
            </div>
          </div>

          <div className="text-center">
            <Link href="/nos-vehicules">
              <button className="bg-[#51AD32] text-white px-8 py-3 rounded-full text-base hover:bg-[#459629] transition-colors">
                voir toutes nos classes
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* Découvrez nos autres services Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-[#1E1E1E] text-center leading-[45px] lowercase mb-20">
            Découvrez nos autres services
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Service 1 - Groupes Scolaires */}
            <div className="border border-[#51AD32] rounded-[40px] p-8 text-center hover:shadow-lg transition-shadow">
              <div className="flex justify-center mb-6">
                <svg width="91" height="109" viewBox="0 0 91 109" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M41.7703 26.637C61.8099 24.5618 79.7396 39.2326 81.819 59.4039C83.8984 79.5752 69.3427 97.6144 49.3031 99.6896C29.2635 101.765 11.3338 87.0941 9.25439 66.9228C7.17502 46.7515 21.7307 28.7123 41.7703 26.637Z" fill="#51AD32"/>
                </svg>
              </div>
              <h3 className="text-[25px] font-bold text-[#1E1E1E] lowercase mb-4">Groupes scolaires</h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px] lowercase mb-6">
                sorties pédagogiques, séjour scolaires et transferts
              </p>
              <Link href="/groupes-scolaires">
                <button className="inline-flex items-center justify-center">
                  <svg width="99" height="58" viewBox="0 0 99 58" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="29" cy="29" r="28.5" stroke="#51AD32"/>
                    <path d="M20 29H38M38 29L31 22M38 29L31 36" stroke="#51AD32" strokeWidth="2"/>
                  </svg>
                </button>
              </Link>
            </div>

            {/* Service 2 - Sport & Loisirs */}
            <div className="border border-[#51AD32] rounded-[40px] p-8 text-center hover:shadow-lg transition-shadow">
              <div className="flex justify-center mb-6">
                <svg width="127" height="98" viewBox="0 0 127 98" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M126.924 79.6082L123.353 42.0957C122.527 33.4285 115.353 26.8935 106.665 26.8935H95.2302C94.1377 20.2646 91.0576 14.2584 86.2487 9.43804C80.1699 3.35273 72.0935 0 63.4993 0C54.905 0 46.8287 3.35273 40.7523 9.44051C35.9434 14.2584 32.8608 20.2671 31.7708 26.896H20.3357C11.6477 26.896 4.47148 33.4309 3.64535 42.0981L0.0769502 79.6082C-0.369408 84.3074 1.19161 89.0092 4.36051 92.5027C7.53187 95.9963 12.0522 98 16.7648 98H110.234C114.946 98 119.467 95.9963 122.638 92.5027C125.809 89.0092 127.37 84.3099 126.922 79.6082H126.924Z" fill="#51AD32"/>
                </svg>
              </div>
              <h3 className="text-[25px] font-bold text-[#1E1E1E] lowercase mb-4">Sport & loisirs</h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px] lowercase mb-6">
                clubs sportifs, colonies et évènements
              </p>
              <Link href="/sport-loisirs">
                <button className="inline-flex items-center justify-center">
                  <svg width="99" height="58" viewBox="0 0 99 58" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="29" cy="29" r="28.5" stroke="#51AD32"/>
                    <path d="M20 29H38M38 29L31 22M38 29L31 36" stroke="#51AD32" strokeWidth="2"/>
                  </svg>
                </button>
              </Link>
            </div>

            {/* Service 3 - Tourisme */}
            <div className="border border-[#51AD32] rounded-[40px] p-8 text-center hover:shadow-lg transition-shadow">
              <div className="flex justify-center mb-6">
                <svg width="109" height="91" viewBox="0 0 109 91" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M88.9684 52.6178C88.9684 52.7122 88.9684 53.0085 88.9684 53.3048C88.9707 62.3514 88.9326 71.3986 88.9895 80.4446C89.0271 86.3993 84.5659 90.5435 79.1155 90.5354C55.8231 90.5015 32.5301 90.5211 9.23775 90.5159C4.96959 90.5147 1.12738 87.3274 0.270902 83.1193C-0.120893 81.1943 0.0283081 79.2473 0.0260302 77.3107C0.00894618 61.4026 0.0163493 45.4945 0.0135019 29.5865C0.0135019 27.4744 0.00609887 25.3819 1.0636 23.4367C2.73898 20.3546 5.32379 18.7264 8.74231 18.6591C13.8379 18.559 18.9369 18.5952 24.0337 18.6562C25.0564 18.6683 25.2449 18.3599 25.2165 17.4094C25.1458 15.0563 25.1937 12.6991 25.1925 10.3437C25.1903 5.38544 28.2449 1.41389 32.9982 0.275294C33.8086 0.0814055 34.6702 0.0434332 35.509 0.0399812C41.2476 0.0181184 46.9872 -0.0405661 52.7246 0.0451592C56.7986 0.106145 60.1027 1.74068 62.0992 5.51317C62.8686 6.96647 63.2507 8.5498 63.2535 10.2102C63.2581 12.7026 63.286 15.195 63.2364 17.6862C63.2211 18.4496 63.4187 18.6539 64.1829 18.6487C69.381 18.6119 74.5803 18.6228 79.7789 18.632C83.8717 18.6395 87.5095 21.4034 88.6575 25.3646C88.78 25.7863 88.9582 26.2334 88.9212 26.6517C88.8238 27.7655 89.3739 27.9318 90.3004 27.8673C91.9838 27.75 93.2583 28.6446 94.3835 29.7734C98.4581 33.8589 102.519 37.9582 106.584 42.0535C108.876 44.3634 108.856 46.3179 106.523 48.6267C104.087 51.0379 101.658 53.4555 99.2189 55.8639C96.8761 58.1773 94.7075 58.114 92.3927 55.762C91.2981 54.6499 90.0954 53.6465 88.969 52.6184L88.9684 52.6178Z" fill="#51AD32"/>
                </svg>
              </div>
              <h3 className="text-[25px] font-bold text-[#1E1E1E] lowercase mb-4">tourisme</h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px] lowercase mb-6">
                Circuits France & Europe, voyages organisés
              </p>
              <Link href="/tourisme">
                <button className="inline-flex items-center justify-center">
                  <svg width="99" height="58" viewBox="0 0 99 58" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="29" cy="29" r="28.5" stroke="#51AD32"/>
                    <path d="M20 29H38M38 29L31 22M38 29L31 36" stroke="#51AD32" strokeWidth="2"/>
                  </svg>
                </button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section - Voyage sur-mesure */}
      <section className="py-24 relative">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex items-stretch gap-0">
            {/* Left - Image */}
            <div className="w-[520px] flex-shrink-0">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/0620c4969db01c9384b4de96014fb4b9a5dbc66f?width=1040"
                alt="Voyage sur mesure"
                className="w-full h-full object-cover rounded-l-[40px]"
              />
            </div>

            {/* Right - Content */}
            <div className="flex-1 bg-[#51AD32] rounded-r-[40px] px-16 py-12 flex flex-col justify-center">
              <div className="text-center uppercase text-[#1E1E1E] text-base font-extrabold mb-4">
                voyage sur-mesure
              </div>
              <div className="w-[263px] h-[1px] bg-black mx-auto mb-12"></div>

              <h2 className="text-white text-[40px] font-bold text-center leading-tight mb-8">
                Confiez à VERBUS<br />
                la logistique transport de<br />
                votre prochain événement<br />
                professionnel.
              </h2>

              <p className="text-white text-xl text-center mb-12 max-w-[526px] mx-auto">
                En quelques questions, nous préparons<br />
                avec vous un devis<br />
                adapté à votre projet, au nombre<br />
                de voyageurs et à votre budget.
              </p>

              <div className="text-center mb-4">
                <Link href="/contact">
                  <button className="bg-white text-[#51AD32] px-12 py-5 rounded-full text-base hover:bg-gray-50 transition-colors">
                    personnaliser mon trajet
                  </button>
                </Link>
              </div>

              <p className="text-white text-[13px] italic text-center">
                Réponse garantie sous 24h à 48h ouvrées  • Sans engagement
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
