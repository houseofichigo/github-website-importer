import { Link } from "react-router-dom";
import Layout from "@/components/Layout";

export default function Index() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative min-h-[600px] lg:min-h-[928px] flex items-center overflow-hidden">
        <img
          src="https://cdn.builder.io/api/v1/image/assets%2Fe4a3fe4fe4c14c1f9e6352a6a0913489%2F60808d3f673349f48fdf3c9f22dc9859?format=webp&width=800"
          alt="Transport fiable et durable - Déplacez vos groupes en confiance"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/40 to-transparent"></div>

        {/* Decorative Green Curve SVG */}
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 1920 928"
          preserveAspectRatio="none"
          fill="none"
        >
          <path
            d="M400 200 Q600 300 700 500 T800 900"
            stroke="#51AD32"
            strokeWidth="80"
            fill="none"
            strokeLinecap="round"
          />
        </svg>

        {/* Pink/Magenta accent line */}
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 1920 928"
          preserveAspectRatio="none"
          fill="none"
        >
          <path
            d="M350 250 Q450 320 500 400"
            stroke="#E71D74"
            strokeWidth="20"
            fill="none"
            strokeLinecap="round"
          />
        </svg>

        <div className="relative z-10 max-w-[1920px] mx-auto px-8 lg:px-24 w-full h-full flex items-center justify-between">
          {/* Left Content */}
          <div className="max-w-xl">
            <h1 className="text-4xl lg:text-[48px] font-bold text-white leading-tight mb-6">
              Déplacez vos groupes
              <br />
              en confiance
            </h1>
            <p className="text-sm lg:text-base text-white mb-8 leading-relaxed max-w-md">
              Transport fiable, durable et personnalisé depuis trois
              générations. Près de 60 ans d'expérience au service de votre
              mobilité.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link
                to="/devis"
                className="px-6 py-3 rounded-full bg-verbus-green text-white font-semibold text-sm hover:bg-verbus-green/90 transition-colors"
              >
                Demander un devis
              </Link>
              <Link
                to="/voyage-sur-mesure"
                className="px-6 py-3 rounded-full bg-white text-verbus-dark font-semibold text-sm hover:bg-white/90 transition-colors"
              >
                Personnaliser votre voyage
              </Link>
            </div>
          </div>

          {/* Right Content - "conduire l'avenir" */}
          <div className="hidden lg:flex flex-col items-center justify-center gap-6 text-white">
            {/* White Leaf Icon */}
            <svg
              width="80"
              height="80"
              viewBox="0 0 80 80"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M40 10C25 25 20 40 20 55C20 65 28 73 40 73C52 73 60 65 60 55C60 40 55 25 40 10Z"
                stroke="white"
                strokeWidth="2"
                fill="none"
              />
              <path
                d="M40 15C45 22 48 30 48 40"
                stroke="white"
                strokeWidth="2"
                fill="none"
              />
            </svg>
            <div className="text-center">
              <h3 className="text-2xl lg:text-[28px] font-bold text-white">
                conduire
              </h3>
              <p className="text-2xl lg:text-[28px] font-bold text-white">
                l'avenir
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white">
        <div className="max-w-[1920px] mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-4 lowercase">
            Nos Services
          </h2>
          <p className="text-base font-bold text-center text-verbus-dark mb-16 max-w-2xl mx-auto">
            Des solutions de mobilité adaptées à tous vos besoins — groupes
            scolaires, événements professionnels, tourisme et sport.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Service Card 1 - Groupes Scolaires */}
            <div className="group relative h-[573px] rounded-[40px] overflow-hidden">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/94c9e48d5305f77d4a56850e4f047bf34eacf831?width=858"
                alt="Groupes scolaires"
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-verbus-dark via-verbus-dark/70 to-transparent"></div>
              <div className="relative h-full flex flex-col justify-end p-8 text-white">
                <h3 className="text-[35px] font-bold leading-tight mb-4">
                  groupes scolaires
                </h3>
                <p className="text-base mb-6">
                  Spécialistes du transport scolaire depuis 60 ans, nous
                  accompagnons écoles et établissements pour des voyages
                  pédagogiques en toute sécurité. Sorties culturelles, classes
                  vertes ou journées d'intégration.
                </p>
                <Link
                  to="/groupes-scolaires"
                  className="inline-flex items-center justify-center px-6 py-3 rounded-full border border-white text-base font-normal hover:bg-white hover:text-verbus-dark transition-colors w-fit"
                >
                  découvrir
                </Link>
              </div>
            </div>

            {/* Service Card 2 - Événements Pro */}
            <div className="group relative h-[573px] rounded-[40px] overflow-hidden">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/95904e9b6fcfd046b997f5f8030e059588be3064?width=860"
                alt="Événements professionnels"
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-verbus-dark via-verbus-dark/70 to-transparent"></div>
              <div className="relative h-full flex flex-col justify-end p-8 text-white">
                <h3 className="text-[35px] font-bold leading-tight mb-4">
                  événements Pro
                </h3>
                <p className="text-base mb-6">
                  Séminaires, congrès, incentives ou transferts VIP : des
                  déplacements fiables et précis, adaptés à l'image de votre
                  entreprise et aux exigences de vos collaborateurs.
                </p>
                <Link
                  to="/evenements-professionnels"
                  className="inline-flex items-center justify-center px-6 py-3 rounded-full border border-white text-base font-normal hover:bg-white hover:text-verbus-dark transition-colors w-fit"
                >
                  découvrir
                </Link>
              </div>
            </div>

            {/* Service Card 3 - Tourisme */}
            <div className="group relative h-[573px] rounded-[40px] overflow-hidden">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/ad439a9085449dd14f0df1c799f7d210cf7243d2?width=860"
                alt="Tourisme & voyage"
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-verbus-dark via-verbus-dark/70 to-transparent"></div>
              <div className="relative h-full flex flex-col justify-end p-8 text-white">
                <h3 className="text-[35px] font-bold leading-tight mb-4">
                  tourisme & voyage
                </h3>
                <p className="text-base mb-6">
                  Circuits découverte, séjours organisés, voyages clubs et
                  associations : des trajets confortables en classes Confort et
                  Star pour des expériences mémorables.
                </p>
                <Link
                  to="/tourisme"
                  className="inline-flex items-center justify-center px-6 py-3 rounded-full border border-white text-base font-normal hover:bg-white hover:text-verbus-dark transition-colors w-fit"
                >
                  découvrir
                </Link>
              </div>
            </div>

            {/* Service Card 4 - Sport & Loisirs */}
            <div className="group relative h-[573px] rounded-[40px] overflow-hidden">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/8d55f67cd987737e3316172735fc3f2d08097020?width=860"
                alt="Sport & loisirs"
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-verbus-dark via-verbus-dark/70 to-transparent"></div>
              <div className="relative h-full flex flex-col justify-end p-8 text-white">
                <h3 className="text-[35px] font-bold leading-tight mb-4">
                  sport & loisirs
                </h3>
                <p className="text-base mb-6">
                  Déplacements clubs sportifs, colonies de vacances, événements
                  : une organisation simple et fiable, pensée pour les groupes à
                  tarifs compétitifs.
                </p>
                <Link
                  to="/sport-loisirs"
                  className="inline-flex items-center justify-center px-6 py-3 rounded-full border border-white text-base font-normal hover:bg-white hover:text-verbus-dark transition-colors w-fit"
                >
                  découvrir
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section - "Ce qui nous définit" */}
      <section className="py-20 bg-white">
        <div className="max-w-[1920px] mx-auto">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-4 px-8">
            ce qui nous définit
          </h2>
          <p className="text-base font-bold text-center text-verbus-dark mb-16 max-w-2xl mx-auto px-8">
            Des valeurs concrètes, portées par nos équipes chaque jour
          </p>

          <div className="flex items-start gap-12 px-8">
            {/* Image */}
            <div className="w-[30%] flex-shrink-0 hidden lg:block -ml-8">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/a949d6de2b986302d6ba7fd079e5d7fad1cdfe29?width=1636"
                alt="Notre équipe"
                className="w-full h-auto"
              />
            </div>

            {/* Values Grid - 3 columns */}
            <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <h3 className="text-[16px] font-bold text-verbus-dark mb-3">
                  Sécurité
                  <br />
                  au quotidien
                </h3>
                <p className="text-xs text-verbus-dark leading-relaxed">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras
                  suscipit consequat dolor a scelerisque. Etiam vitae posuere
                  diam. Orci varius natoque penatibus et magnis dis parturient
                  montes, nascetur ridiculus mus.
                </p>
              </div>

              <div className="text-center">
                <h3 className="text-[16px] font-bold text-verbus-dark mb-3">
                  Proximité
                  <br />
                  territoriale
                </h3>
                <p className="text-xs text-verbus-dark leading-relaxed">
                  Une connaissance fine des routes et des besoins locaux depuis
                  60 ans. Nous sommes ancrés dans vos territoires.
                </p>
              </div>

              <div className="text-center">
                <h3 className="text-[16px] font-bold text-verbus-dark mb-3">
                  Flotte
                  <br />
                  moderne
                </h3>
                <p className="text-xs text-verbus-dark leading-relaxed">
                  1 500 véhicules renouvelés régulièrement pour votre confort et
                  votre sécurité. Du concret, pas du discours.
                </p>
              </div>

              <div className="text-center">
                <h3 className="text-[16px] font-bold text-verbus-dark mb-3">
                  Nos équipes
                  <br />
                  engagées
                </h3>
                <p className="text-xs text-verbus-dark leading-relaxed">
                  Conducteurs, exploitants, techniciens : des femmes et des
                  hommes passionnés qui font Verbus au quotidien.
                </p>
              </div>

              <div className="text-center">
                <h3 className="text-[16px] font-bold text-verbus-dark mb-3">
                  Transition
                  <br />
                  énergétique
                </h3>
                <p className="text-xs text-verbus-dark leading-relaxed">
                  Des bus hybrides et électriques déjà en service sur nos
                  lignes. C'est fait, pas promis.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-verbus-gray">
        <div className="max-w-[1920px] mx-auto px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {/* Column 1: 800+ Véhicules */}
            <div className="text-center lg:border-r-2 lg:border-verbus-green lg:pr-12">
              <div className="mb-6 flex justify-center">
                <svg
                  width="65"
                  height="60"
                  viewBox="0 0 65 60"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-16 h-auto"
                >
                  <g clipPath="url(#clip0_bus)">
                    <path
                      d="M51.4539 52.3186H46.5796C42.8486 52.3186 39.1189 52.3186 35.3878 52.3186C31.2679 52.3186 27.148 52.3186 23.0269 52.3186C20.2329 52.3186 17.439 52.3186 14.6451 52.3186C14.0673 52.3186 13.4253 52.3755 12.8598 52.2479C11.203 51.8725 10.2634 50.4351 10.2597 48.7932C10.256 46.7908 10.2597 44.7883 10.2597 42.7859C10.2597 39.0326 10.2597 35.2792 10.2597 31.5259C10.2597 27.3203 10.2597 23.1147 10.2597 18.9103C10.2597 15.5523 10.2597 12.1942 10.2597 8.83617C10.2597 7.88452 10.2597 6.93163 10.2597 5.97997C10.2597 5.24765 10.2264 4.53267 10.5313 3.83752C11.1412 2.44349 12.4771 1.8673 13.9055 1.8673C14.7599 1.8673 15.613 1.8673 16.4674 1.8673C19.8465 1.8673 23.2257 1.8673 26.6048 1.8673C30.7877 1.8673 34.9718 1.8673 39.1547 1.8673C42.4264 1.8673 45.6969 1.8673 48.9686 1.8673C49.7242 1.8673 50.4798 1.86606 51.2354 1.8673C52.9527 1.87101 54.5096 2.96888 54.7194 4.77058C54.775 5.24269 54.738 5.74082 54.738 6.21417C54.738 7.24885 54.738 8.28476 54.738 9.31944C54.738 12.7692 54.738 16.2189 54.738 19.6687C54.738 23.8842 54.738 28.0997 54.738 32.314C54.738 36.5283 54.738 39.6769 54.738 43.3596C54.738 45.2084 54.7478 47.0584 54.738 48.9072C54.7281 50.756 53.3453 52.2826 51.4539 52.321C50.2637 52.3458 50.26 54.2045 51.4539 54.1797C54.296 54.1215 56.5479 51.8576 56.5899 49.0026C56.5973 48.4921 56.5899 47.9816 56.5899 47.4723V38.9C56.5899 34.7179 56.5899 30.5346 56.5899 26.3525C56.5899 22.1705 56.5899 18.1458 56.5899 14.0418C56.5899 11.4198 56.5899 8.79776 56.5899 6.17576C56.5899 5.52397 56.6109 4.87839 56.5022 4.2328C56.0812 1.7471 53.8318 0.0247074 51.3786 0.00612042C49.3439 -0.00874916 47.3093 0.00612042 45.2746 0.00612042C41.3041 0.00612042 37.3336 0.00612042 33.3631 0.00612042C29.3926 0.00612042 25.1467 0.00612042 21.0392 0.00612042C18.6526 0.00612042 16.2661 0.00612042 13.8809 0.00612042C12.1055 0.00612042 10.4746 0.6641 9.39797 2.13123C8.62387 3.18573 8.41028 4.40628 8.41028 5.67639C8.41028 8.01711 8.41028 10.3578 8.41028 12.6985C8.41028 16.6923 8.41028 20.6848 8.41028 24.6785C8.41028 28.6722 8.41028 33.1417 8.41028 37.3734C8.41028 40.4935 8.41028 43.6124 8.41028 46.7325C8.41028 47.4314 8.40781 48.1303 8.41028 48.8304C8.41645 50.8167 9.40167 52.7089 11.2178 53.6147C12.2228 54.1153 13.2512 54.1772 14.334 54.1772C15.4167 54.1772 16.4266 54.1772 17.4736 54.1772C21.1552 54.1772 24.8368 54.1772 28.5197 54.1772C32.7668 54.1772 37.0138 54.1772 41.2609 54.1772C44.2215 54.1772 47.1821 54.1772 50.1427 54.1772H51.4564C52.6478 54.1772 52.6502 52.3186 51.4564 52.3186H51.4539Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M8.6795 27.7493C9.91782 28.9921 11.1561 30.235 12.3945 31.4778C12.9377 32.0231 13.4636 32.6178 14.1007 33.0565C14.8945 33.603 15.8427 33.8272 16.7946 33.8334C19.4984 33.8508 22.2035 33.8334 24.9073 33.8334H47.8353C48.0045 33.8334 48.1748 33.8372 48.3452 33.8334C49.7082 33.8049 50.8576 33.2312 51.8083 32.2783C53.1874 30.8942 54.5677 29.5089 55.9467 28.1248C56.0714 27.9996 56.1961 27.8745 56.3208 27.7493C57.1641 26.903 55.8554 25.5883 55.0109 26.4346C53.7973 27.6526 52.5836 28.8707 51.37 30.0888C50.9046 30.5559 50.4403 31.1383 49.886 31.5051C49.3317 31.8719 48.76 31.9723 48.1341 31.9735C45.4167 31.9822 42.7005 31.9735 39.9832 31.9735H17.2922C17.0848 31.9735 16.8761 31.9772 16.6687 31.9735C15.7489 31.9549 15.0674 31.5299 14.4427 30.9017C13.0834 29.5374 11.7241 28.1731 10.3647 26.8088C10.2401 26.6836 10.1154 26.5585 9.99066 26.4333C9.14742 25.587 7.83749 26.9005 8.68073 27.7481L8.6795 27.7493Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M4.46813 12.5611V6.7483L3.54217 7.67765H59.0727C59.8184 7.67765 60.611 7.75447 61.3543 7.67765C61.3864 7.67393 61.4209 7.67765 61.4543 7.67765L60.5283 6.7483V12.5611C60.5283 13.7568 62.3802 13.7593 62.3802 12.5611V6.7483C62.3802 6.24645 61.9555 5.81895 61.4543 5.81895H10.6857C8.34359 5.81895 5.98301 5.72973 3.64218 5.81895C3.60884 5.82019 3.57551 5.81895 3.54217 5.81895C3.04215 5.81895 2.61621 6.24521 2.61621 6.7483V12.5611C2.61621 13.7568 4.46813 13.7593 4.46813 12.5611Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M21.6648 43.9621C21.6303 45.3537 20.5401 46.5036 19.1302 46.506C17.7202 46.5085 16.5955 45.3487 16.5955 43.9621C16.5955 42.5755 17.7462 41.4182 19.1302 41.4182C20.5142 41.4182 21.6315 42.573 21.6648 43.9621C21.6945 45.1566 23.5464 45.1604 23.5168 43.9621C23.4711 42.1022 22.3587 40.4702 20.6092 39.8197C18.8598 39.1691 16.9042 39.7466 15.7609 41.1505C14.6177 42.5545 14.4139 44.5941 15.3424 46.1851C16.2844 47.7997 18.1536 48.6089 19.9709 48.2805C22.0402 47.9063 23.4674 46.024 23.518 43.9621C23.5476 42.7651 21.6957 42.7663 21.6661 43.9621H21.6648Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M48.3339 43.9621C48.2994 45.3537 47.2092 46.5036 45.7993 46.506C44.3893 46.5085 43.2646 45.3487 43.2646 43.9621C43.2646 42.5755 44.4153 41.4182 45.7993 41.4182C47.1833 41.4182 48.3006 42.573 48.3339 43.9621C48.3636 45.1566 50.2155 45.1604 50.1859 43.9621C50.1402 42.1022 49.0278 40.4702 47.2783 39.8197C45.5289 39.1691 43.5733 39.7466 42.43 41.1505C41.2769 42.5668 41.0831 44.5941 42.0115 46.1851C42.9399 47.7762 44.8227 48.6089 46.6401 48.2805C48.7093 47.9063 50.1365 46.024 50.1871 43.9621C50.2167 42.7651 48.3648 42.7663 48.3352 43.9621H48.3339Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M14.1993 53.2479V57.6034C14.1993 58.3928 14.1524 59.2093 14.9104 59.7137C15.4277 60.0582 16.0525 59.9888 16.6426 59.9888H21.8514C22.2774 59.9888 22.7107 60.0111 23.1367 59.9888C24.2676 59.9305 24.7392 59.047 24.7392 58.0359V53.2466C24.7392 52.0509 22.8873 52.0484 22.8873 53.2466V58.0359C22.8873 58.1003 22.8651 58.2292 22.8873 58.2912C22.891 58.3035 22.8786 58.3481 22.8873 58.3581C23.0144 58.5154 22.1601 57.0049 23.1391 58.1288C23.0503 58.0272 22.2527 58.1288 22.1268 58.1288H16.413C16.2907 58.1288 15.9722 58.0656 15.8648 58.1288C15.7253 58.2106 15.9722 58.4547 16.0512 58.3221C16.1302 58.1895 16.0512 57.798 16.0512 57.6468V53.2454C16.0512 52.0496 14.1993 52.0472 14.1993 53.2454V53.2479Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M40.2594 53.2479V57.6034C40.2594 58.3928 40.2124 59.2093 40.9705 59.7137C41.4878 60.0582 42.1125 59.9888 42.7027 59.9888H47.9115C48.3374 59.9888 48.7708 60.0111 49.1967 59.9888C50.3276 59.9305 50.7993 59.047 50.7993 58.0359V53.2466C50.7993 52.0509 48.9473 52.0484 48.9473 53.2466V58.0359C48.9473 58.1003 48.9251 58.2292 48.9473 58.2912C48.951 58.3035 48.9387 58.3481 48.9473 58.3581C49.0745 58.5154 48.2202 57.0049 49.1992 58.1288C49.1103 58.0272 48.3127 58.1288 48.1868 58.1288H42.473C42.3508 58.1288 42.0323 58.0656 41.9249 58.1288C41.7853 58.2106 42.0323 58.4547 42.1113 58.3221C42.1903 58.1895 42.1113 57.798 42.1113 57.6468V53.2454C42.1113 52.0496 40.2594 52.0472 40.2594 53.2454V53.2479Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M4.94574 23.0269C4.06423 23.0269 3.17407 23.0666 2.29379 23.0269C1.70735 23.0009 1.8518 22.4532 1.8518 21.9984V14.3431C1.8518 14.2093 1.81476 13.9825 1.89131 13.8623C2.04563 13.6182 2.5617 13.7198 2.79628 13.7198H4.48523C4.78895 13.7198 5.14699 13.6368 5.23341 14.0073C5.26674 14.1485 5.23341 14.3381 5.23341 14.4819V21.2326C5.23341 21.5375 5.45811 22.9922 4.94698 23.0269C3.76422 23.1062 3.75558 24.9662 4.94698 24.8856C6.13838 24.8051 7.00508 24.012 7.08039 22.8212C7.09521 22.5945 7.08533 22.364 7.08533 22.1372V14.8226C7.08533 13.6603 6.96311 12.4484 5.66552 11.99C5.14575 11.8066 4.55931 11.8611 4.01608 11.8611C3.4247 11.8611 2.83208 11.8487 2.24194 11.8611C0.803611 11.8908 -0.000123011 12.9528 -0.000123011 14.3183V21.5115C-0.000123011 22.789 -0.0618538 24.2276 1.41968 24.7567C1.98514 24.9587 2.65183 24.8856 3.24321 24.8856H4.94574C6.13715 24.8856 6.13962 23.0269 4.94574 23.0269Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M62.8593 23.0269C61.9778 23.0269 61.0876 23.0666 60.2073 23.0269C59.6209 23.0009 59.7653 22.4532 59.7653 21.9984V14.3431C59.7653 14.2093 59.7283 13.9825 59.8049 13.8623C59.9592 13.6182 60.4753 13.7198 60.7098 13.7198H62.3988C62.7025 13.7198 63.0605 13.6368 63.147 14.0073C63.1803 14.1485 63.147 14.3381 63.147 14.4819V21.2326C63.147 21.5375 63.3717 22.9922 62.8605 23.0269C61.6778 23.1062 61.6691 24.9662 62.8605 24.8856C64.0519 24.8051 64.9186 24.012 64.9939 22.8212C65.0088 22.5945 64.9989 22.364 64.9989 22.1372V14.8226C64.9989 13.6603 64.8766 12.4484 63.5791 11.99C63.0593 11.8066 62.4729 11.8611 61.9296 11.8611C61.3382 11.8611 60.7456 11.8487 60.1555 11.8611C58.7184 11.8908 57.9159 12.9528 57.9159 14.3183V21.5115C57.9159 22.789 57.8542 24.2276 59.3357 24.7567C59.9012 24.9587 60.5678 24.8856 61.1592 24.8856H62.8618C64.0532 24.8856 64.0556 23.0269 62.8618 23.0269H62.8593Z"
                      fill="#51AD32"
                    />
                  </g>
                  <defs>
                    <clipPath id="clip0_bus">
                      <rect width="65" height="60" fill="white" />
                    </clipPath>
                  </defs>
                </svg>
              </div>
              <div className="text-[50px] font-bold text-verbus-green">
                800+
              </div>
              <p className="text-base uppercase text-verbus-green">
                Véhicules modernes
              </p>
            </div>

            {/* Column 2: 60 ans */}
            <div className="text-center lg:border-r-2 lg:border-verbus-green lg:pr-12">
              <div className="mb-6 flex justify-center">
                <svg
                  width="79"
                  height="79"
                  viewBox="0 0 79 79"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-20 h-auto"
                >
                  <g clipPath="url(#clip0_flags)">
                    <path
                      d="M1.18393 33.2303C1.21472 33.2303 1.24552 33.2303 1.27824 33.2264C3.12794 33.044 4.97379 32.8173 6.81386 32.5523L9.66443 48.8697C9.72795 49.2346 10.0013 49.5304 10.3612 49.6226C10.4382 49.6418 10.5171 49.6514 10.596 49.6514C10.879 49.6514 11.1523 49.5246 11.3351 49.2961L17.3847 41.7366L24.5698 46.9433C24.8816 47.17 25.2993 47.1834 25.6265 46.9798C25.9537 46.7762 26.1231 46.396 26.0576 46.0176L23.0935 29.0472C25.794 28.2713 28.4732 27.4032 31.1294 26.4409L38.1394 42.38C38.2895 42.7199 38.6244 42.9408 38.9959 42.9446H39.0055C39.3732 42.9446 39.71 42.7315 39.864 42.3973L43.931 33.6163L52.1536 36.962C52.5097 37.1079 52.9196 37.0215 53.1891 36.7469C53.4586 36.4722 53.5317 36.0612 53.3777 35.7097L46.3677 19.7707C49.2029 18.3014 51.9707 16.7304 54.6673 15.0595L65.2708 28.8474C65.4537 29.0837 65.7328 29.2162 66.0215 29.2162C66.1062 29.2162 66.1909 29.2047 66.2737 29.1816C66.6451 29.0798 66.9165 28.7629 66.9608 28.3807L67.9848 19.5806L77.6548 20.2547C78.0243 20.2816 78.3785 20.0876 78.5536 19.7592C78.7288 19.4327 78.698 19.0332 78.4709 18.7374L68.1792 5.3566C69.6362 4.15238 71.0663 2.9136 72.4656 1.64216C72.8525 1.29069 72.8794 0.693384 72.5272 0.309264C72.175 -0.0767763 71.5783 -0.103665 71.1914 0.247805C61.4868 9.0672 50.352 16.2598 38.0951 21.6279C26.2116 26.8327 13.7623 30.1035 1.09154 31.35C0.571851 31.4018 0.192672 31.8628 0.242716 32.3814C0.290835 32.8692 0.702735 33.2322 1.182 33.2322L1.18393 33.2303ZM23.7903 44.0471L17.7619 39.6796C17.3539 39.3839 16.7822 39.4607 16.4665 39.8544L11.1638 46.4805L8.68088 32.2661C12.9096 31.5862 17.1056 30.6816 21.2573 29.5581L23.7883 44.0471H23.7903ZM75.6896 18.2246L67.2129 17.6331C66.7086 17.5985 66.266 17.9653 66.2082 18.4647L65.3498 25.8475L56.2707 14.0435C59.8873 11.7234 63.373 9.22469 66.7125 6.54929L75.6896 18.2227V18.2246ZM38.8554 23.3545C40.8244 22.4922 42.7646 21.5837 44.6759 20.6292L50.7042 34.3346L43.8059 31.5286C43.3382 31.3385 42.8031 31.5497 42.5894 32.0068L39.0248 39.7046L32.9021 25.7841C34.9 25.0274 36.8844 24.2169 38.8535 23.3545H38.8554Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M78.9267 50.1661C78.7265 49.6841 78.1741 49.4555 77.691 49.6553C65.565 54.6719 52.6479 57.6738 39.2939 58.5803C26.346 59.458 13.5232 58.3268 1.17781 55.2173C0.671601 55.0906 0.157689 55.3959 0.0287296 55.9011C-0.0983048 56.4062 0.207733 56.919 0.713945 57.0476C2.51552 57.5009 4.32865 57.9138 6.14948 58.2845L3.2912 74.6C3.22769 74.9649 3.38359 75.3356 3.69156 75.543C3.99952 75.7524 4.40179 75.76 4.71745 75.5661L12.9766 70.4995L17.9675 77.8266C18.1465 78.0878 18.441 78.2395 18.749 78.2395C18.8144 78.2395 18.8818 78.2319 18.9472 78.2184C19.3245 78.1377 19.6132 77.8362 19.6806 77.4579L22.6543 60.4874C25.3625 60.6641 28.0822 60.7563 30.8096 60.7563C30.9058 60.7563 31.002 60.7544 31.1002 60.7544L32.2839 78.1205C32.3089 78.4911 32.5495 78.8119 32.8979 78.9406C33.0057 78.9809 33.1173 79.0001 33.2271 79.0001C33.4753 79.0001 33.7198 78.9021 33.9007 78.7197L40.7086 71.8324L47.3086 77.7594C47.5954 78.0167 48.0092 78.0744 48.3557 77.9073C48.7022 77.7383 48.912 77.3791 48.885 76.995L47.7013 59.6289C50.8675 59.2045 54.0068 58.6629 57.1095 58.0022L62.4045 74.5597C62.522 74.9265 62.8492 75.1839 63.2341 75.2146C63.2591 75.2146 63.2822 75.2165 63.3073 75.2165C63.6633 75.2165 63.9925 75.0149 64.1542 74.6922L68.1057 66.7582L76.975 70.6628C77.3157 70.8126 77.7122 70.7492 77.9894 70.5014C78.2665 70.2537 78.3705 69.8657 78.2588 69.5123L73.1197 53.4427C74.9001 52.8012 76.6651 52.1213 78.4147 51.3972C78.8978 51.1975 79.1269 50.6463 78.9267 50.1642V50.1661ZM18.2216 74.8401L14.0333 68.6922C13.7484 68.2755 13.1864 68.1545 12.7553 68.4195L5.51623 72.8599L8.00688 58.6475C12.2163 59.4369 16.472 60.0035 20.7604 60.3492L18.2216 74.8401ZM46.8409 74.7997L41.3034 69.8273C40.928 69.4893 40.3525 69.5066 39.9984 69.8657L34.0297 75.9022L32.9961 60.7371C35.1326 60.7006 37.2748 60.6084 39.4209 60.4644C41.5671 60.3184 43.7016 60.1187 45.8227 59.8671L46.8409 74.7997ZM75.8182 68.0911L68.0441 64.6686C67.5802 64.465 67.0413 64.6609 66.8161 65.1122L63.4997 71.769L58.9669 57.5931C63.1571 56.6347 67.2857 55.4612 71.3354 54.0726L75.8182 68.0911Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M7.58567 23.4407C9.84342 23.4407 11.6796 21.6085 11.6796 19.3556C11.6796 17.1028 9.84342 15.2705 7.58567 15.2705C5.32792 15.2705 3.4917 17.1028 3.4917 19.3556C3.4917 21.6085 5.32792 23.4407 7.58567 23.4407ZM7.58567 17.1565C8.8002 17.1565 9.78953 18.1418 9.78953 19.3556C9.78953 20.5694 8.80212 21.5547 7.58567 21.5547C6.36922 21.5547 5.38182 20.5694 5.38182 19.3556C5.38182 18.1418 6.36922 17.1565 7.58567 17.1565Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M52.5075 8.17023C54.7653 8.17023 56.6015 6.33798 56.6015 4.08511C56.6015 1.83225 54.7653 0 52.5075 0C50.2498 0 48.4136 1.83225 48.4136 4.08511C48.4136 6.33798 50.2498 8.17023 52.5075 8.17023ZM52.5075 1.88795C53.7221 1.88795 54.7114 2.87322 54.7114 4.08704C54.7114 5.30085 53.724 6.28612 52.5075 6.28612C51.2911 6.28612 50.3056 5.30085 50.3056 4.08704C50.3056 2.87322 51.293 1.88795 52.5075 1.88795Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M36.3513 47.9419C34.0935 47.9419 32.2573 49.7742 32.2573 52.027C32.2573 54.2799 34.0935 56.1121 36.3513 56.1121C38.609 56.1121 40.4453 54.2799 40.4453 52.027C40.4453 49.7742 38.609 47.9419 36.3513 47.9419ZM36.3513 54.2261C35.1368 54.2261 34.1474 53.2408 34.1474 52.0289C34.1474 50.817 35.1348 49.8298 36.3513 49.8298C37.5677 49.8298 38.5552 50.8151 38.5552 52.0289C38.5552 53.2427 37.5677 54.2261 36.3513 54.2261Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M65.3668 33.3169C65.2013 33.0134 64.8837 32.8252 64.5372 32.8252C64.1907 32.8252 63.8732 33.0134 63.7076 33.3169C62.6894 35.176 61.165 36.6952 59.3038 37.7112C58.9997 37.8764 58.811 38.1933 58.811 38.539C58.811 38.8847 58.9997 39.2016 59.3038 39.3668C61.1669 40.3828 62.6894 41.9039 63.7076 43.7611C63.8732 44.0645 64.1927 44.2528 64.5372 44.2528C64.8817 44.2528 65.2013 44.0645 65.3668 43.7611C66.385 41.9019 67.9094 40.3828 69.7706 39.3668C70.0748 39.2016 70.2634 38.8847 70.2634 38.539C70.2634 38.1933 70.0748 37.8764 69.7706 37.7112C67.9075 36.6952 66.385 35.1741 65.3668 33.3169ZM64.5372 41.537C63.7076 40.3789 62.6933 39.3668 61.5327 38.539C62.6933 37.7112 63.7076 36.699 64.5372 35.5409C65.3668 36.699 66.3811 37.7112 67.5418 38.539C66.3811 39.3668 65.3668 40.3789 64.5372 41.537Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M23.8228 8.08746C25.686 9.10346 27.2085 10.6246 28.2267 12.4818C28.3922 12.7852 28.7098 12.9735 29.0563 12.9735C29.4027 12.9735 29.7203 12.7852 29.8858 12.4818C30.904 10.6227 32.4284 9.10346 34.2897 8.08746C34.5938 7.92229 34.7824 7.60539 34.7824 7.25968C34.7824 6.91397 34.5938 6.59707 34.2897 6.4319C32.4265 5.41591 30.904 3.89479 29.8858 2.03757C29.7203 1.73412 29.4027 1.5459 29.0563 1.5459C28.7098 1.5459 28.3922 1.73412 28.2267 2.03757C27.2085 3.89671 25.6841 5.41591 23.8228 6.4319C23.5187 6.59707 23.3301 6.91397 23.3301 7.25968C23.3301 7.60539 23.5187 7.92229 23.8228 8.08746ZM29.0582 4.26163C29.8877 5.41975 30.9021 6.4319 32.0627 7.25968C30.9021 8.08746 29.8877 9.09962 29.0582 10.2577C28.2286 9.09962 27.2143 8.08746 26.0536 7.25968C27.2143 6.4319 28.2286 5.41975 29.0582 4.26163Z"
                      fill="#51AD32"
                    />
                  </g>
                  <defs>
                    <clipPath id="clip0_flags">
                      <rect width="79" height="79" fill="white" />
                    </clipPath>
                  </defs>
                </svg>
              </div>
              <div className="text-[50px] font-bold text-verbus-green">
                60 ans
              </div>
              <p className="text-base uppercase text-verbus-green">
                d'expérience
              </p>
            </div>

            {/* Column 3: Objectif CO2 */}
            <div className="text-center lg:border-r-2 lg:border-verbus-green lg:pr-12">
              <div className="mb-6 flex justify-center h-20 items-center">
                <img
                  src="https://api.builder.io/api/v1/image/assets/TEMP/dc30f2e75184010a57c8e0a98899922486c82d17?width=378"
                  alt="Label Objectif CO2 - Transport éco-responsable"
                  className="w-32 h-auto"
                />
              </div>
            </div>

            {/* Column 4: ISO 9001 */}
            <div className="text-center">
              <div className="mb-6 flex justify-center">
                <svg
                  width="63"
                  height="72"
                  viewBox="0 0 63 72"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-16 h-auto"
                >
                  <g clipPath="url(#clip0_shield)">
                    <path
                      d="M61.3803 11.1844V31.0184C61.3803 33.9572 61.5098 36.9552 61.1373 39.8751C60.1843 47.3674 56.4508 54.3106 51.157 59.6499C46.0359 64.8143 39.511 68.6143 32.4057 70.2747C32.1763 70.3286 31.9279 70.3609 31.7065 70.4362C31.6633 70.4524 31.0748 70.5196 31.5014 70.5196C31.9279 70.5196 31.3421 70.4497 31.2962 70.4362C31.0748 70.3609 30.8238 70.3286 30.597 70.2747C28.9692 69.8953 27.3737 69.4189 25.8134 68.8242C22.15 67.4248 18.6892 65.4198 15.6063 63.0032C9.67258 58.3474 5.01851 52.0124 2.89395 44.7462C1.78172 40.9462 1.62515 37.1247 1.62515 33.2117V11.1844L0.815275 11.9917C2.65909 11.8868 4.50829 11.8114 6.34941 11.6742C9.37833 11.4508 12.3236 10.4093 15.1446 9.34628C20.946 7.16104 26.4693 4.38643 31.9144 1.44765H31.0964C36.5415 4.38643 42.0648 7.16104 47.8662 9.34628C50.6872 10.4093 53.6325 11.4508 56.6614 11.6742C58.5025 11.8114 60.3517 11.8841 62.1955 11.9917C63.2376 12.0509 63.2322 10.4362 62.1955 10.377C58.8616 10.1859 55.6329 10.1321 52.4069 9.18481C46.8538 7.55395 41.5006 5.07537 36.366 2.43262C34.9406 1.69793 33.4478 0.594545 31.9414 0.067072C30.8481 -0.315077 29.2364 1.06281 28.297 1.56606C23.2676 4.26801 18.017 6.70623 12.607 8.547C10.4609 9.279 8.25801 9.94642 5.98226 10.081C4.25993 10.1832 2.5403 10.2774 0.817974 10.377C0.380643 10.4012 0.00810151 10.7269 0.00810151 11.1844V31.7666C0.00810151 35.2786 -0.0539888 38.7529 0.618206 42.2245C2.05708 49.6333 6.07405 56.4044 11.5218 61.593C16.7428 66.5663 23.2353 70.2182 30.2757 71.8572C32.6163 72.4008 35.2322 71.2786 37.4188 70.4577C40.9391 69.1391 44.2649 67.3252 47.2885 65.0996C53.3247 60.6618 58.1759 54.6766 60.8403 47.658C62.506 43.2741 63.0027 38.7583 63.0027 34.1106V11.1844C63.0027 10.1456 61.383 10.1429 61.383 11.1844H61.3803Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M34.8056 62.8231C33.2534 63.3936 31.8928 63.9991 30.2596 63.5174C28.8477 63.1003 27.4682 62.5755 26.1346 61.9511C23.3756 60.6567 20.7867 58.9827 18.4786 56.9993C13.9946 53.1456 10.5014 48.1184 8.9572 42.3862C8.16622 39.4474 8.10143 36.5194 8.10143 33.516V17.2747C8.10143 16.2359 6.48169 16.2332 6.48169 17.2747V33.7017C6.48169 36.8585 6.59777 39.9507 7.45354 43.0267C9.07328 48.8477 12.6124 54.039 17.1585 57.9924C19.7312 60.2288 22.6144 62.126 25.7243 63.5335C27.1226 64.166 28.5615 64.7123 30.0382 65.1375C30.8589 65.3743 31.388 65.5412 32.2194 65.3393C33.2453 65.0917 34.2468 64.7446 35.2349 64.3813C36.2229 64.018 35.7856 62.4624 34.8029 62.8231H34.8056Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M20.5465 14.1528C24.4096 12.5327 28.2079 10.7511 31.909 8.78922H31.0911C34.4304 10.56 37.8508 12.1936 41.3278 13.6764C45.9009 15.6302 50.7197 17.5679 55.7085 18.0765L54.8986 17.2691V28.1012C54.8986 32.3048 55.2523 36.7695 54.3938 40.9085C53.3491 45.941 50.7899 50.4972 47.3398 54.281C46.6406 55.048 47.7825 56.1945 48.4844 55.4221C53.5326 49.8863 56.5076 42.9915 56.5157 35.4723C56.5211 30.9431 56.5157 26.4165 56.5157 21.8872V17.2665C56.5157 16.7982 56.1431 16.5049 55.7058 16.4591C52.253 16.1066 48.8651 14.9224 45.6418 13.6926C42.4185 12.4627 39.3113 11.0687 36.2311 9.57505C35.1782 9.06372 34.1308 8.54432 33.0914 8.00878C32.3707 7.63739 31.7767 7.12069 30.9696 7.4517C29.6873 7.97917 28.4644 8.74347 27.2172 9.35437C24.8793 10.4981 22.5118 11.5827 20.1119 12.5892C19.1643 12.9848 19.5801 14.5484 20.5438 14.1474L20.5465 14.1528Z"
                      fill="#51AD32"
                    />
                    <path
                      d="M19.9229 40.1499C22.4632 41.9718 25.0008 43.7937 27.5411 45.6157C27.8191 45.8148 28.297 45.7341 28.5237 45.4892C33.2831 40.3113 38.0424 35.1362 42.8018 29.9583C43.4902 29.2102 44.1759 28.462 44.8643 27.7139C45.5526 26.9657 44.4242 25.8031 43.7196 26.5728C38.9603 31.7507 34.2009 36.9258 29.4416 42.1037C28.7532 42.8518 28.0675 43.6 27.3791 44.3481L28.3617 44.2216C25.8214 42.3997 23.2838 40.5777 20.7435 38.7558C19.8959 38.1476 19.086 39.547 19.9256 40.1499H19.9229Z"
                      fill="#51AD32"
                    />
                  </g>
                  <defs>
                    <clipPath id="clip0_shield">
                      <rect width="63" height="72" fill="white" />
                    </clipPath>
                  </defs>
                </svg>
              </div>
              <div className="text-[50px] font-bold text-verbus-green">
                iso 9001
              </div>
              <p className="text-base uppercase text-verbus-green">
                Certification environnementale
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="relative py-20 bg-white overflow-hidden">
        <div className="max-w-[1920px] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
            {/* Left - Background Image */}
            <div className="relative h-full min-h-[600px]">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/d8e4247862a6905c5326856940538fbee7a53b1a?width=4034"
                alt="Client satisfait"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Right - Testimonial Content */}
            <div className="relative bg-[#FAFAFC] flex items-center justify-center px-12 py-20">
              {/* Decorative green curve - positioned absolutely */}
              <svg
                className="absolute left-0 bottom-0 w-24 h-auto opacity-80"
                width="183"
                height="359"
                viewBox="0 0 183 359"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M-53.5526 352.697C-3.99892 365.649 49.784 357.716 94.26 335.044C116.544 323.685 136.289 307.571 150.825 288.575C168.4 265.607 178.509 238.59 181.574 210.928C184.363 185.764 178.378 160.357 164.085 138.561C150.516 117.866 130.133 101.605 108.362 88.1079C89.2415 76.2569 68.4439 66.4777 47.3307 57.8409C27.0725 49.5594 6.43274 42.373 -14.8976 36.6428C-37.1553 30.664 -59.8143 25.9816 -82.539 21.6721C-114.025 15.6993 -145.649 10.3302 -177.253 4.87821C-186.204 3.33319 -195.156 1.78817 -204.108 0.237232C-213.527 -1.39658 -225.596 5.61816 -225.044 14.8291C-224.774 19.2747 -222.702 23.6374 -218.973 26.6505C-214.54 30.226 -209.653 31.7414 -203.852 32.7536C-170.169 38.6022 -136.44 44.2377 -102.824 50.3822C-102.225 50.4947 -101.62 50.6013 -101.021 50.7137C-97.2459 51.4063 -106.809 49.6423 -103.054 50.3408C-101.298 50.6664 -99.548 50.992 -97.7919 51.3175C-94.3848 51.9569 -90.9777 52.6021 -87.5772 53.2592C-81.3945 54.4549 -75.2118 55.6862 -69.0489 56.9648C-57.5385 59.3564 -46.0742 61.9196 -34.702 64.7965C-14.1938 69.9761 5.96575 76.2391 25.4939 83.9109C26.7567 84.4082 28.013 84.9113 29.2759 85.4145C30.7755 86.0124 32.9263 86.9299 25.9609 84.0648C26.5923 84.3253 27.2237 84.5798 27.8551 84.8462C30.4072 85.8999 32.946 86.9773 35.4783 88.0724C40.8125 90.381 46.1007 92.7844 51.3363 95.2588C62.3928 100.48 73.252 106.062 83.6442 112.295C86.5514 114.036 89.4191 115.835 92.2473 117.682C92.8985 118.108 93.5431 118.535 94.1877 118.967C98.042 121.554 90.4188 116.327 93.0695 118.191C94.3258 119.073 95.5821 119.961 96.8186 120.867C102.12 124.738 107.198 128.864 111.953 133.275C114.301 135.453 116.544 137.714 118.741 140.017C120.938 142.32 115.367 136.222 117.452 138.59C118.09 139.318 118.734 140.047 119.366 140.781C120.306 141.888 121.227 143.006 122.122 144.137C126.167 149.263 129.692 154.698 132.665 160.386L130.593 156.379C134.895 164.761 137.855 173.587 139.473 182.703L138.729 178.471C140.768 190.505 140.446 202.676 138.453 214.699L139.183 210.443C136.355 226.846 130.856 242.894 122.457 257.687L124.641 253.851C117.392 266.436 108.112 277.938 97.062 288.037L100.423 285C89.623 294.773 77.3365 303.073 63.9845 309.815L68.2729 307.66C60.584 311.502 52.5925 314.835 44.3511 317.605C40.2205 318.996 36.0374 320.245 31.8016 321.352C30.8084 321.613 29.8152 321.856 28.822 322.11C26.6515 322.661 33.7419 320.973 31.5582 321.465C31.0583 321.577 30.565 321.696 30.0651 321.808C27.9538 322.282 25.8293 322.72 23.6983 323.128C15.4305 324.697 7.03785 325.739 -1.40088 326.218C-2.39406 326.277 -3.38723 326.325 -4.37384 326.366C-5.30124 326.402 -9.45154 326.508 -5.00526 326.414C-0.558972 326.319 -4.69612 326.396 -5.62353 326.402C-6.72852 326.402 -7.82694 326.402 -8.93193 326.39C-13.0493 326.337 -17.1733 326.141 -21.271 325.804C-25.7634 325.431 -30.2359 324.88 -34.6691 324.14C-35.1295 324.064 -35.5899 323.981 -36.0503 323.904C-39.0496 323.395 -30.4662 324.975 -32.8472 324.49C-33.8666 324.283 -34.8861 324.087 -35.9056 323.868C-38.1419 323.389 -40.3651 322.856 -42.575 322.276C-47.7054 320.932 -53.5132 320.695 -58.558 322.548C-62.7083 324.069 -67.1875 327.503 -68.3845 331.575C-71.1536 340.976 -63.5042 350.116 -53.5263 352.726L-53.5526 352.697Z"
                  fill="#55AD32"
                />
              </svg>

              {/* Decorative pink smiley - positioned absolutely */}
              <svg
                className="absolute top-8 right-8 w-20 h-auto opacity-90"
                width="95"
                height="81"
                viewBox="0 0 95 81"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M91.4343 21.971C80.7095 22.8208 70.3571 25.4873 60.3687 29.027C59.4677 29.3467 56.0718 30.4226 57.2499 31.7091C62.9416 37.9465 69.6554 43.2639 75.8582 49.0646C77.7121 50.7955 87.3453 47.3649 85.7253 45.8524C79.5139 40.0516 72.8088 34.742 67.1171 28.4968L63.9985 31.1789C71.4054 28.5514 78.9335 26.4073 86.9035 25.7758C88.7488 25.6277 92.855 25.1287 93.9119 23.5225C94.9688 21.9164 93.0023 21.8462 91.4343 21.971Z"
                  fill="#E71D74"
                />
                <path
                  d="M1.88422 39.9191C1.53769 46.2813 9.29977 53.6102 13.9605 57.9452C27.7001 70.0379 44.5756 78.474 62.9066 69.4999C66.5884 67.8782 70.1836 65.7029 74.1079 63.4497L74.827 63.9253C72.2454 67.1375 69.3693 70.1938 65.9993 72.8057C46.3689 88.1497 22.1211 78.6143 8.27754 61.8046C3.69479 56.1519 -2.55129 46.5698 1.09585 39.5371L1.88422 39.9113V39.9191Z"
                  fill="#E71D74"
                />
                <path
                  d="M13.4769 5.24679C18.7874 -6.79136 36.0355 3.95254 28.5333 16.7002C21.8194 28.1068 -2.74027 18.8209 14.3432 2.78302L13.4769 5.24679Z"
                  fill="#E71D74"
                />
              </svg>

              {/* Main content container */}
              <div className="relative z-10 max-w-lg text-center">
                {/* Speech bubble icon */}
                <div className="flex justify-center mb-6">
                  <svg
                    width="66"
                    height="58"
                    viewBox="0 0 66 58"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="w-16 h-auto"
                  >
                    <path
                      d="M9.22519 57.7511C9.03195 57.7511 8.84058 57.6823 8.68888 57.5499C8.44522 57.3374 8.34954 57.0013 8.44429 56.6919L11.9544 45.216C8.40181 42.9381 5.45745 40.0624 3.41487 36.869C2.3119 35.1447 1.46238 33.3208 0.889659 31.4481C0.299198 29.5175 0 27.5232 0 25.5199C0 22.0457 0.881257 18.6781 2.6195 15.5104C4.28819 12.4695 6.67244 9.74227 9.70503 7.40441C12.7222 5.07871 16.2318 3.25429 20.1368 1.98122C24.1697 0.66649 28.4513 0 32.8637 0C37.2761 0 41.5577 0.66649 45.5901 1.98122C49.4951 3.25429 53.0047 5.07871 56.0219 7.40441C59.055 9.74227 61.4387 12.4695 63.1074 15.5104C64.8457 18.6781 65.7269 22.0457 65.7269 25.5199C65.7269 28.9942 64.8457 32.3618 63.1074 35.5295C61.4387 38.5703 59.0545 41.2976 56.0219 43.6355C53.0047 45.9612 49.4951 47.7856 45.5901 49.0587C41.5577 50.3734 37.2756 51.0399 32.8637 51.0399C30.2871 51.0399 27.7223 50.8077 25.2353 50.3495L9.57013 57.6739C9.45998 57.7254 9.34188 57.7506 9.22519 57.7506V57.7511ZM32.8637 1.63814C28.6231 1.63814 24.5114 2.27796 20.6423 3.53933C16.9152 4.75436 13.5703 6.49173 10.7011 8.70322C7.84776 10.9025 5.61055 13.4585 4.05108 16.3C2.44726 19.2229 1.63369 22.3251 1.63369 25.5199C1.63369 29.1889 2.69558 32.71 4.78997 35.9844C6.8022 39.1306 9.76058 41.9561 13.3454 44.1559C13.6632 44.3511 13.8093 44.7372 13.7001 45.0948L10.5447 55.4109L24.783 48.7535C24.9385 48.6809 25.1126 48.6589 25.2811 48.6912C27.7484 49.1626 30.2997 49.4017 32.8642 49.4017C37.1048 49.4017 41.2165 48.7619 45.0855 47.5005C48.8127 46.2855 52.1575 44.5481 55.0268 42.3366C57.8801 40.1373 60.1173 37.5814 61.6768 34.7399C63.2806 31.817 64.0942 28.7148 64.0942 25.5199C64.0942 22.3251 63.2811 19.2229 61.6768 16.3C60.1173 13.4581 57.8801 10.9021 55.0268 8.70322C52.1575 6.49173 48.8131 4.75436 45.0855 3.53933C41.2165 2.27796 37.1043 1.63814 32.8642 1.63814H32.8637Z"
                      fill="#231F20"
                    />
                    <path
                      d="M17.6891 29.8726C15.2955 29.8726 13.3481 27.9199 13.3481 25.5198C13.3481 23.1197 15.2955 21.167 17.6891 21.167C20.0827 21.167 22.03 23.1197 22.03 25.5198C22.03 27.9199 20.0827 29.8726 17.6891 29.8726ZM17.6891 22.8056C16.1964 22.8056 14.9818 24.0234 14.9818 25.5202C14.9818 27.017 16.1964 28.2349 17.6891 28.2349C19.1818 28.2349 20.3963 27.017 20.3963 25.5202C20.3963 24.0234 19.1818 22.8056 17.6891 22.8056Z"
                      fill="#231F20"
                    />
                    <path
                      d="M32.8634 29.8726C30.4698 29.8726 28.5225 27.9199 28.5225 25.5198C28.5225 23.1197 30.4698 21.167 32.8634 21.167C35.257 21.167 37.2043 23.1197 37.2043 25.5198C37.2043 27.9199 35.257 29.8726 32.8634 29.8726ZM32.8634 22.8056C31.3707 22.8056 30.1561 24.0234 30.1561 25.5202C30.1561 27.017 31.3707 28.2349 32.8634 28.2349C34.3561 28.2349 35.5707 27.017 35.5707 25.5202C35.5707 24.0234 34.3561 22.8056 32.8634 22.8056Z"
                      fill="#231F20"
                    />
                    <path
                      d="M48.0382 29.8726C45.6446 29.8726 43.6973 27.9199 43.6973 25.5198C43.6973 23.1197 45.6446 21.167 48.0382 21.167C50.4318 21.167 52.3791 23.1197 52.3791 25.5198C52.3791 27.9199 50.4318 29.8726 48.0382 29.8726ZM48.0382 22.8056C46.5455 22.8056 45.331 24.0234 45.331 25.5202C45.331 27.017 46.5455 28.2349 48.0382 28.2349C49.5309 28.2349 50.7455 27.017 50.7455 25.5202C50.7455 24.0234 49.5309 22.8056 48.0382 22.8056Z"
                      fill="#231F20"
                    />
                  </svg>
                </div>

                {/* Heading with styled text */}
                <div className="mb-8">
                  <h2 className="text-[40px] font-bold leading-[45px]">
                    <span className="text-verbus-dark">ils nous </span>
                    <span className="inline-block bg-verbus-green text-white px-6 py-1 rounded-full">
                      font confiance
                    </span>
                  </h2>
                </div>

                {/* Testimonial quote */}
                <p className="text-[25px] font-bold text-verbus-dark leading-[30px] mb-6">
                  "Une équipe réactive, ponctuelle et attentionnée. Verbus a
                  géré notre séminaire à Toulouse à la perfection."
                </p>

                {/* Author */}
                <p className="text-[25px] italic text-verbus-dark mb-8">
                  Sophie Martin
                </p>

                {/* Navigation arrows */}
                <div className="flex justify-center">
                  <svg
                    width="87"
                    height="51"
                    viewBox="0 0 87 51"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="w-20 h-auto"
                  >
                    <rect
                      x="0.5"
                      y="0.5"
                      width="85.4378"
                      height="49.9986"
                      rx="24.9993"
                      fill="white"
                      stroke="#1E1E1E"
                    />
                    <path
                      d="M71.7655 26.0972C72.156 25.7067 72.156 25.0736 71.7655 24.683L65.4015 18.3191C65.011 17.9285 64.3778 17.9285 63.9873 18.3191C63.5968 18.7096 63.5968 19.3428 63.9873 19.7333L69.6442 25.3901L63.9873 31.047C63.5968 31.4375 63.5968 32.0707 63.9873 32.4612C64.3778 32.8517 65.011 32.8517 65.4015 32.4612L71.7655 26.0972ZM48.7432 25.3901V26.3901H71.0584V25.3901V24.3901H48.7432V25.3901Z"
                      fill="#1E1E1E"
                    />
                    <path
                      d="M17.7653 26.0972C17.3748 25.7067 17.3748 25.0736 17.7653 24.683L24.1292 18.3191C24.5198 17.9285 25.1529 17.9285 25.5435 18.3191C25.934 18.7096 25.934 19.3428 25.5435 19.7333L19.8866 25.3901L25.5435 31.047C25.934 31.4375 25.934 32.0707 25.5435 32.4612C25.1529 32.8517 24.5198 32.8517 24.1292 32.4612L17.7653 26.0972ZM40.7876 25.3901V26.3901H18.4724V25.3901V24.3901H40.7876V25.3901Z"
                      fill="#2A2559"
                      fillOpacity="0.25"
                    />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mode Vert Section */}
      <section className="py-20 bg-white">
        <div className="max-w-[1920px] mx-auto px-8">
          <div className="grid grid-cols-1 lg:grid-cols-[60%_40%] gap-12 items-center">
            <div>
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/65ddf13a66c320db849bd3678909df6f6bd977e5?width=2188"
                alt="Mode Vert"
                className="w-full h-auto rounded-[40px]"
              />
            </div>
            <div className="bg-verbus-gray rounded-[40px] p-12 text-left">
              <h2 className="text-[28px] font-bold text-verbus-dark mb-6">
                notre engagement
                <br />
                durable
              </h2>
              <p className="text-base text-verbus-dark leading-relaxed mb-6">
                Le Mode Vert de Verbus permet de réduire significativement
                l'impact environnemental de vos déplacements grâce à une flotte
                modernisée et des pratiques éco-responsables.
              </p>
              <ul className="text-base text-verbus-green space-y-3 mb-8">
                <li className="flex items-start gap-3">
                  <svg
                    width="25"
                    height="21"
                    viewBox="0 0 25 21"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="w-6 h-6 flex-shrink-0 mt-0.5"
                  >
                    <g clipPath="url(#clip0_leaf)">
                      <path
                        d="M11.9082 20.9917C6.86474 20.9917 3.54515 19.4264 1.75955 16.2058C0.245043 13.4749 0.133037 10.0196 0.0437572 7.24367C0.030771 6.82071 0.0177848 6.42272 -7.11642e-05 6.03639C-0.00656425 5.90651 0.0632364 5.78495 0.175242 5.725C0.287248 5.66505 0.423603 5.67837 0.524245 5.7583C2.0907 7.01221 3.5971 7.79985 4.92818 8.49591C6.77059 9.45841 8.35978 10.291 9.62917 12.0078C10.9976 13.8629 11.8255 16.5988 12.2329 20.6237C12.2426 20.7169 12.2134 20.8102 12.1517 20.8818C12.0901 20.9517 12.0024 20.9917 11.9099 20.9917H11.9082ZM0.67521 6.70914C0.681703 6.87733 0.686573 7.04718 0.691442 7.22203C0.779099 9.92467 0.887858 13.2884 2.32283 15.8761C3.94123 18.7953 6.96052 20.2507 11.5463 20.3239C10.6567 12.241 8.12115 10.9155 4.63275 9.09039C3.43152 8.46261 2.08908 7.75989 0.67521 6.70914Z"
                        fill="#51AD32"
                      />
                      <path
                        d="M11.9084 20.9916C11.8516 20.9916 11.7948 20.9766 11.7412 20.945C8.57097 18.9967 6.22534 16.5372 3.89757 12.7205C3.80179 12.564 3.84887 12.3592 4.00146 12.2609C4.15404 12.1627 4.35371 12.211 4.44948 12.3675C6.71881 16.0892 8.99951 18.4838 12.0756 20.3738C12.2298 20.4687 12.2801 20.6736 12.1876 20.8301C12.1276 20.935 12.0188 20.9916 11.9084 20.9916Z"
                        fill="#51AD32"
                      />
                      <path
                        d="M12.3451 21.0001C12.1957 21.0001 12.0464 20.9967 11.8971 20.9917C11.7185 20.9851 11.5773 20.8302 11.5854 20.647C11.5919 20.4639 11.7396 20.3207 11.9214 20.3273C16.7636 20.5088 19.7391 17.5997 21.3834 15.1269C24.1657 10.9455 25.1235 4.98905 23.7145 0.987542C22.3542 2.60613 20.5848 3.53199 18.869 4.43287C15.4407 6.22963 11.8954 8.08801 11.3078 15.6398C11.2932 15.8229 11.139 15.9595 10.9588 15.9445C10.7802 15.9295 10.6471 15.7696 10.6617 15.5865C11.2786 7.66505 14.9878 5.72008 18.5736 3.84005C20.4598 2.85092 22.2438 1.91673 23.5505 0.134953C23.6203 0.0400363 23.7339 -0.00992008 23.8476 0.00506684C23.9628 0.0183885 24.0618 0.0949884 24.1073 0.203227C25.8799 4.38458 24.9384 10.9622 21.9191 15.5032C20.7585 17.2483 19.3609 18.6088 17.7652 19.5463C16.1176 20.5138 14.2962 21.0034 12.3451 21.0034V21.0001Z"
                        fill="#51AD32"
                      />
                      <path
                        d="M11.6957 19.2665C11.5642 19.2665 11.4409 19.1832 11.3922 19.05C11.3289 18.8785 11.4149 18.6853 11.5821 18.622C12.3921 18.3106 14.0284 17.0184 15.8594 14.8337C17.3155 13.0952 19.3348 10.261 20.6838 6.62417C20.7471 6.45265 20.9354 6.36606 21.1026 6.43101C21.2698 6.49595 21.3542 6.68911 21.2909 6.86063C18.843 13.4565 13.7443 18.5021 11.811 19.2448C11.7736 19.2598 11.7347 19.2665 11.6973 19.2665H11.6957Z"
                        fill="#51AD32"
                      />
                    </g>
                    <defs>
                      <clipPath id="clip0_leaf">
                        <rect width="25" height="21" fill="white" />
                      </clipPath>
                    </defs>
                  </svg>
                  <span>Réduction des émissions de CO₂ jusqu'à 30%</span>
                </li>
                <li className="flex items-start gap-3">
                  <svg
                    width="27"
                    height="27"
                    viewBox="0 0 27 27"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="w-6 h-6 flex-shrink-0 mt-0.5"
                  >
                    <g clipPath="url(#clip0_route)">
                      <path
                        d="M26.9451 16.2176C26.6173 13.6376 24.4506 11.6974 21.7581 11.5676C19.2705 11.4469 16.9012 13.2618 16.3458 15.7189C16.0295 17.1238 16.2571 18.4924 16.7031 19.8314C17.3586 21.8056 18.4648 23.5272 19.7575 25.1371C20.0397 25.4878 20.3379 25.8293 20.6702 26.2278H11.9099C11.1111 26.2278 10.3099 26.2415 9.51104 26.2165C8.08399 26.1709 6.95283 24.9845 6.9369 23.5454C6.92324 22.1404 8.01799 20.9449 9.42227 20.847C9.9503 20.8128 10.4806 20.8379 11.0109 20.8105C12.8931 20.7081 14.2496 18.8636 13.7967 17.0328C13.4394 15.5982 12.265 14.6737 10.7492 14.66C9.38358 14.6486 8.01571 14.66 6.65012 14.66H6.311C6.51356 14.4254 6.67516 14.2456 6.82993 14.0611C8.29794 12.3168 9.55883 10.445 10.294 8.26124C10.6923 7.0794 10.9335 5.86341 10.7332 4.61554C10.2507 1.58695 7.647 -0.334952 4.60857 0.0476066C2.11636 0.364128 0.0748047 2.62305 0.00197324 5.13245C-0.0321665 6.35983 0.209088 7.53711 0.643801 8.6734C1.6202 11.2056 3.1929 13.3392 5.08425 15.2543C5.19577 15.3659 5.41426 15.4228 5.58041 15.4228C7.36478 15.4388 9.14915 15.4114 10.9335 15.4456C12.117 15.4684 13.073 16.4726 13.1071 17.6453C13.139 18.875 12.2718 19.9133 11.0724 20.0272C10.5284 20.0796 9.97534 20.0454 9.4291 20.0705C7.59693 20.1524 6.13803 21.7305 6.17217 23.5773C6.20176 25.4491 7.71301 26.9884 9.55656 26.993C13.5441 27.0043 17.5293 26.9998 21.5169 26.993C21.6557 26.993 21.8332 26.9201 21.9311 26.8199C23.7155 25.0027 25.2222 22.9875 26.2031 20.6193C26.788 19.212 27.1385 17.7569 26.9428 16.2176H26.9451ZM5.48027 14.3958C5.45523 14.4209 5.42109 14.4368 5.3824 14.4664C4.32634 13.3552 3.39091 12.1574 2.59432 10.8549C1.83869 9.62069 1.22873 8.325 0.932851 6.89723C0.632421 5.44442 0.705252 4.05537 1.5724 2.78245C2.6717 1.16796 4.67912 0.414225 6.56364 0.908364C8.43449 1.39339 9.81147 3.00105 9.99582 4.92296C10.1233 6.24142 9.80464 7.48929 9.3062 8.69162C8.41401 10.8481 7.05752 12.6971 5.48254 14.3958H5.48027ZM25.625 19.9748C24.7328 22.2702 23.3126 24.2194 21.6511 26.007C21.6375 26.0206 21.6215 26.0252 21.5442 26.0684C20.9296 25.3056 20.2787 24.5564 19.6892 23.7571C18.5831 22.2542 17.6659 20.6443 17.2107 18.8135C16.9262 17.6613 16.8283 16.5045 17.2562 15.3591C18.0232 13.3096 20.0466 12.1096 22.2634 12.3851C24.2867 12.6379 25.9641 14.3457 26.194 16.4339C26.3283 17.659 26.0643 18.8385 25.6227 19.9771L25.625 19.9748Z"
                        fill="#51AD32"
                      />
                      <path
                        d="M21.6082 14.6602C20.3132 14.6602 19.289 15.6849 19.2913 16.9783C19.2913 18.2489 20.3314 19.2896 21.5946 19.2896C22.8737 19.2896 23.9183 18.2421 23.9183 16.9623C23.9183 15.6985 22.8782 14.6602 21.6082 14.6602ZM21.5786 18.5131C20.7251 18.4949 20.056 17.8072 20.0628 16.9487C20.0719 16.1061 20.7524 15.4321 21.5946 15.4321C22.4367 15.4321 23.1536 16.1244 23.1445 16.9919C23.1354 17.8345 22.4185 18.5313 21.5809 18.5153L21.5786 18.5131Z"
                        fill="#51AD32"
                      />
                      <path
                        d="M5.41006 3.07184C4.14916 3.06273 3.09538 4.1011 3.08173 5.36491C3.06579 6.631 4.09681 7.68987 5.35771 7.69898C6.65957 7.71036 7.69287 6.70159 7.70652 5.41501C7.72018 4.12843 6.69144 3.08095 5.41006 3.07184ZM5.39185 6.92703C4.52242 6.9202 3.8419 6.22795 3.85556 5.35808C3.86694 4.5292 4.56794 3.84606 5.40323 3.85062C6.26583 3.85517 6.94862 4.55425 6.93497 5.42412C6.92131 6.26666 6.23851 6.93386 5.39185 6.92931V6.92703Z"
                        fill="#51AD32"
                      />
                    </g>
                    <defs>
                      <clipPath id="clip0_route">
                        <rect width="27" height="27" fill="white" />
                      </clipPath>
                    </defs>
                  </svg>
                  <span>Suivi environnemental en temps réel</span>
                </li>
                <li className="flex items-start gap-3">
                  <svg
                    width="15"
                    height="22"
                    viewBox="0 0 15 22"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="w-6 h-6 flex-shrink-0 mt-0.5"
                  >
                    <g clipPath="url(#clip0_bolt)">
                      <path
                        d="M5.56746 22C5.52582 22 5.48419 21.9953 5.44255 21.9835C5.24363 21.9269 5.10485 21.7405 5.10485 21.5306V11.2772H0.4626C0.321506 11.2772 0.18735 11.2111 0.0994547 11.0979C0.0115596 10.9847 -0.0208229 10.8361 0.0115596 10.6969L2.41017 0.363247C2.45875 0.15096 2.6461 0 2.86121 0H11.4842C11.6484 0 11.7988 0.0872735 11.882 0.231157C11.9653 0.37504 11.9676 0.551946 11.889 0.698188L8.97686 6.1115H14.5374C14.7039 6.1115 14.8589 6.2035 14.9399 6.3521C15.0208 6.5007 15.0185 6.68232 14.9306 6.82856L5.95836 21.7736C5.87278 21.9151 5.72243 22 5.56283 22H5.56746ZM1.0478 10.3313H5.56746C5.82189 10.3313 6.03006 10.5436 6.03006 10.803V19.8559L13.7116 7.055H8.19506C8.03084 7.055 7.88049 6.96773 7.79722 6.82385C7.71395 6.67996 7.71164 6.50306 7.79028 6.35681L10.7024 0.943497H3.22667L1.0478 10.3313Z"
                        fill="#51AD32"
                      />
                    </g>
                    <defs>
                      <clipPath id="clip0_bolt">
                        <rect width="15" height="22" fill="white" />
                      </clipPath>
                    </defs>
                  </svg>
                  <span>Flotte hybride et électrique en expansion</span>
                </li>
              </ul>
              <Link
                to="/mode-vert"
                className="inline-block px-6 py-3 rounded-full bg-verbus-green border border-white text-white font-normal text-base hover:bg-verbus-green/90 transition-colors"
              >
                découvrir le mode vert
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Nos Établissements Section */}
      <section className="py-20 bg-white">
        <div className="max-w-[1920px] mx-auto px-8">
          {/* Title and Subtitle */}
          <div className="text-center mb-12">
            <h2 className="text-[40px] font-bold text-verbus-dark mb-4">
              nos établissements
            </h2>
            <p className="text-base text-verbus-dark max-w-[343px] mx-auto">
              Plus de 20 implantations en Occitanie et Nouvelle-Aquitaine pour
              une proximité maximale
            </p>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left - Map */}
            <div className="flex justify-center lg:justify-start">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/6fa36e7d9066223202bd5eb02e53999da92b0725?width=1044"
                alt="Carte des établissements Verbus"
                className="w-full max-w-[522px] h-auto rounded-br-[40px]"
              />
            </div>

            {/* Right - Location Cards */}
            <div className="flex flex-col gap-8">
              {/* First Row */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Aveyron Card */}
                <div className="bg-[#FAFAFC] rounded-[25px] p-6 flex flex-col items-center justify-center min-h-[258px]">
                  <div className="mb-4">
                    <img
                      src="https://api.builder.io/api/v1/image/assets/TEMP/53a5725bca36d154b34c3ca94d16cca143675bc8?width=238"
                      alt="Verbus Aveyron"
                      className="w-[119px] h-[119px]"
                    />
                  </div>
                  <p className="text-base font-bold text-black uppercase text-center">
                    Aveyron (12)
                  </p>
                </div>

                {/* Gers Card */}
                <div className="bg-[#FAFAFC] rounded-[25px] p-6 flex flex-col items-center justify-center min-h-[258px]">
                  <div className="mb-4">
                    <img
                      src="https://api.builder.io/api/v1/image/assets/TEMP/a419818abf874d2d7e1bd43593abdf154bfa2c40?width=238"
                      alt="Verbus Gers"
                      className="w-[119px] h-[119px]"
                    />
                  </div>
                  <p className="text-base font-bold text-black uppercase text-center">
                    Gers (32)
                  </p>
                </div>

                {/* Pullmans Landais Card */}
                <div className="bg-[#FAFAFC] rounded-[25px] p-6 flex flex-col items-center justify-center min-h-[258px]">
                  <div className="mb-4">
                    <img
                      src="https://api.builder.io/api/v1/image/assets/TEMP/4ceb734befa1e37a8fd6e8dbebb2d127ecb211bf?width=238"
                      alt="Verbus Pullmans Landais"
                      className="w-[119px] h-[119px]"
                    />
                  </div>
                  <p className="text-base font-bold text-black uppercase text-center">
                    Landes (40)
                  </p>
                </div>
              </div>

              {/* Second Row */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Aveyron Card */}
                <div className="bg-[#FAFAFC] rounded-[25px] p-6 flex flex-col items-center justify-center min-h-[258px]">
                  <div className="mb-4">
                    <img
                      src="https://api.builder.io/api/v1/image/assets/TEMP/53a5725bca36d154b34c3ca94d16cca143675bc8?width=238"
                      alt="Verbus Aveyron"
                      className="w-[119px] h-[119px]"
                    />
                  </div>
                  <p className="text-base font-bold text-black uppercase text-center">
                    Aveyron (12)
                  </p>
                </div>

                {/* Gers Card */}
                <div className="bg-[#FAFAFC] rounded-[25px] p-6 flex flex-col items-center justify-center min-h-[258px]">
                  <div className="mb-4">
                    <img
                      src="https://api.builder.io/api/v1/image/assets/TEMP/a419818abf874d2d7e1bd43593abdf154bfa2c40?width=238"
                      alt="Verbus Gers"
                      className="w-[119px] h-[119px]"
                    />
                  </div>
                  <p className="text-base font-bold text-black uppercase text-center">
                    Gers (32)
                  </p>
                </div>

                {/* Pullmans Landais Card */}
                <div className="bg-[#FAFAFC] rounded-[25px] p-6 flex flex-col items-center justify-center min-h-[258px]">
                  <div className="mb-4">
                    <img
                      src="https://api.builder.io/api/v1/image/assets/TEMP/4ceb734befa1e37a8fd6e8dbebb2d127ecb211bf?width=238"
                      alt="Verbus Pullmans Landais"
                      className="w-[119px] h-[119px]"
                    />
                  </div>
                  <p className="text-base font-bold text-black uppercase text-center">
                    Landes (40)
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Button */}
          <div className="flex justify-center mt-12">
            <button className="px-12 py-3 rounded-full bg-verbus-green text-white text-base font-normal hover:bg-verbus-green/90 transition-colors">
              Voir toutes nos agences
            </button>
          </div>
        </div>
      </section>

      {/* History Section - 60 ans */}
      <section className="py-20 bg-white">
        <div className="max-w-[1920px] mx-auto px-8">
          <div className="grid grid-cols-1 lg:grid-cols-[60%_40%] gap-0">
            {/* Left - Team Photo */}
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/0e55daebf4216789c9e5a94f300c1830db812217?width=2138"
                alt="Équipe commerciale Verbus"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Right - Content with Dark Background */}
            <div className="relative bg-verbus-dark text-white flex items-center justify-center p-12">
              {/* Entreprise Familiale Badge - Positioned at top */}
              <div className="absolute top-0 right-12 bg-[#FAFAFC] rounded-b-[40px] px-8 py-6 flex flex-col items-center">
                <img
                  src="https://api.builder.io/api/v1/image/assets/TEMP/a2e10640d48381bea3a349cd95be57c0e518bf46?width=166"
                  alt="Entreprise familiale"
                  className="w-[83px] h-[83px] mb-2"
                />
                <p className="text-base font-extrabold text-verbus-green text-center uppercase">
                  entreprise familiale
                </p>
              </div>

              {/* Main Content */}
              <div className="max-w-md text-center">
                <h2 className="text-[32px] font-bold mb-6 leading-[38px] mt-16">
                  60 ans
                  <br />
                  de transport
                  <br />
                  en confiance
                </h2>

                <p className="text-sm mb-10 leading-relaxed">
                  Depuis près de 60 ans, Verbus accompagne les territoires avec
                  une mobilité sûre, humaine et durable. Grâce à notre ancrage
                  local et nos équipes engagées, nous construisons des solutions
                  de transport adaptées à vos besoins.
                </p>

                {/* Stats with Icons */}
                <div className="space-y-5 mb-10">
                  {/* 60 ans d'expérience */}
                  <div className="flex items-center justify-center gap-4">
                    <svg
                      width="79"
                      height="79"
                      viewBox="0 0 79 79"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                      className="w-12 h-12 flex-shrink-0"
                    >
                      <g clipPath="url(#clip0_celebration)">
                        <path
                          d="M1.18368 33.2303C1.21448 33.2303 1.24527 33.2303 1.27799 33.2264C3.12769 33.044 4.97354 32.8173 6.81361 32.5523L9.66419 48.8697C9.72771 49.2346 10.001 49.5304 10.361 49.6226C10.4379 49.6418 10.5169 49.6514 10.5958 49.6514C10.8787 49.6514 11.152 49.5246 11.3349 49.2961L17.3844 41.7366L24.5696 46.9433C24.8814 47.17 25.299 47.1834 25.6263 46.9798C25.9535 46.7762 26.1228 46.396 26.0574 46.0176L23.0933 29.0472C25.7937 28.2713 28.473 27.4032 31.1292 26.4409L38.1391 42.38C38.2893 42.7199 38.6242 42.9408 38.9957 42.9446H39.0053C39.3729 42.9446 39.7097 42.7315 39.8637 42.3973L43.9308 33.6163L52.1533 36.962C52.5094 37.1079 52.9194 37.0215 53.1889 36.7469C53.4583 36.4722 53.5315 36.0612 53.3775 35.7097L46.3675 19.7707C49.2027 18.3014 51.9705 16.7304 54.6671 15.0595L65.2706 28.8474C65.4535 29.0837 65.7326 29.2162 66.0213 29.2162C66.1059 29.2162 66.1906 29.2047 66.2734 29.1816C66.6449 29.0798 66.9163 28.7629 66.9605 28.3807L67.9845 19.5806L77.6545 20.2547C78.0241 20.2816 78.3782 20.0876 78.5534 19.7592C78.7285 19.4327 78.6978 19.0332 78.4706 18.7374L68.1789 5.3566C69.636 4.15238 71.0661 2.9136 72.4654 1.64216C72.8522 1.29069 72.8792 0.693384 72.527 0.309264C72.1747 -0.0767763 71.5781 -0.103665 71.1912 0.247805C61.4865 9.0672 50.3518 16.2598 38.0949 21.6279C26.2114 26.8327 13.762 30.1035 1.09129 31.35C0.571607 31.4018 0.192428 31.8628 0.242472 32.3814C0.290591 32.8692 0.702491 33.2322 1.18176 33.2322L1.18368 33.2303Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M78.927 50.1661C78.7268 49.6841 78.1744 49.4555 77.6913 49.6553C65.5653 54.6719 52.6482 57.6738 39.2942 58.5803C26.3463 59.458 13.5235 58.3268 1.17806 55.2173C0.671845 55.0906 0.157933 55.3959 0.0289737 55.9011C-0.0980607 56.4062 0.207977 56.919 0.71419 57.0476C2.51577 57.5009 4.3289 57.9138 6.14972 58.2845L3.29145 74.6C3.22793 74.9649 3.38384 75.3356 3.6918 75.543C3.99976 75.7524 4.40204 75.76 4.7177 75.5661L12.9769 70.4995L17.9678 77.8266C18.1468 78.0878 18.4413 78.2395 18.7492 78.2395C18.8147 78.2395 18.882 78.2319 18.9475 78.2184C19.3247 78.1377 19.6134 77.8362 19.6808 77.4579L22.6546 60.4874C25.3627 60.6641 28.0824 60.7563 30.8098 60.7563C30.906 60.7563 31.0023 60.7544 31.1004 60.7544L32.2842 78.1205C32.3092 78.4911 32.5498 78.8119 32.8982 78.9406C33.006 78.9809 33.1176 79.0001 33.2273 79.0001C33.4756 79.0001 33.72 78.9021 33.901 78.7197L40.7089 71.8324L47.3089 77.7594C47.5957 78.0167 48.0095 78.0744 48.3559 77.9073C48.7024 77.7383 48.9122 77.3791 48.8853 76.995L47.7015 59.6289C50.8678 59.2045 54.007 58.6629 57.1098 58.0022L62.4048 74.5597C62.5222 74.9265 62.8494 75.1839 63.2344 75.2146C63.2594 75.2146 63.2825 75.2165 63.3075 75.2165C63.6636 75.2165 63.9927 75.0149 64.1544 74.6922L68.1059 66.7582L76.9753 70.6628C77.3159 70.8126 77.7124 70.7492 77.9896 70.5014C78.2668 70.2537 78.3707 69.8657 78.2591 69.5123L73.1199 53.4427C74.9004 52.8012 76.6654 52.1213 78.415 51.3972C78.8981 51.1975 79.1271 50.6463 78.927 50.1642V50.1661Z"
                          fill="#51AD32"
                        />
                      </g>
                      <defs>
                        <clipPath id="clip0_celebration">
                          <rect width="79" height="79" fill="white" />
                        </clipPath>
                      </defs>
                    </svg>
                    <div className="text-left">
                      <p className="text-[32px] font-bold leading-none">
                        60 ans
                      </p>
                      <p className="text-sm uppercase leading-tight">
                        d'expérience
                      </p>
                    </div>
                  </div>

                  {/* 3 générations d'engagement */}
                  <div className="flex items-center justify-center gap-4">
                    <svg
                      width="74"
                      height="74"
                      viewBox="0 0 74 74"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                      className="w-12 h-12 flex-shrink-0"
                    >
                      <g clipPath="url(#clip0_network)">
                        <path
                          d="M36.9977 52.2907C28.5677 52.2907 21.7046 45.4323 21.7046 36.9976C21.7046 28.5628 28.5629 21.7045 36.9977 21.7045C45.4325 21.7045 52.2908 28.5628 52.2908 36.9976C52.2908 45.4323 45.4325 52.2907 36.9977 52.2907ZM36.9977 23.6269C29.6251 23.6269 23.627 29.625 23.627 36.9976C23.627 44.3702 29.6251 50.3682 36.9977 50.3682C44.3703 50.3682 50.3684 44.3702 50.3684 36.9976C50.3684 29.625 44.3703 23.6269 36.9977 23.6269Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M36.9975 10.4437C34.1187 10.4437 31.7781 8.10314 31.7781 5.22426C31.7781 2.34539 34.1187 0 36.9975 0C39.8764 0 42.217 2.34059 42.217 5.21946C42.217 8.09833 39.8764 10.4389 36.9975 10.4389V10.4437ZM36.9975 1.92245C35.176 1.92245 33.6957 3.40274 33.6957 5.22426C33.6957 7.04579 35.176 8.52608 36.9975 8.52608C38.8191 8.52608 40.2993 7.04579 40.2993 5.22426C40.2993 3.40274 38.8191 1.92245 36.9975 1.92245Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M36.9976 23.6269C36.4689 23.6269 36.0364 23.1944 36.0364 22.6657V9.48247C36.0364 8.95379 36.4689 8.52124 36.9976 8.52124C37.5263 8.52124 37.9588 8.95379 37.9588 9.48247V22.6657C37.9588 23.1944 37.5263 23.6269 36.9976 23.6269Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M14.529 19.7484C13.1929 19.7484 11.8568 19.2389 10.8379 18.22C9.85266 17.2348 9.30957 15.9227 9.30957 14.5289C9.30957 13.1351 9.85266 11.8231 10.8379 10.8378C12.8757 8.8 16.1871 8.8 18.2201 10.8378C19.2054 11.8231 19.7485 13.1351 19.7485 14.5289C19.7485 15.9227 19.2054 17.2348 18.2201 18.22C17.2012 19.2389 15.8651 19.7484 14.529 19.7484ZM14.529 11.2319C13.6831 11.2319 12.8373 11.5539 12.1981 12.1979C10.91 13.486 10.91 15.5766 12.1981 16.8647C13.4861 18.1527 15.5768 18.1527 16.8648 16.8647C18.1529 15.5766 18.1529 13.486 16.8648 12.1979C16.2208 11.5539 15.3749 11.2319 14.5338 11.2319H14.529Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M26.8662 27.8275C26.6211 27.8275 26.376 27.7314 26.1885 27.5439L16.8647 18.22C16.4898 17.8451 16.4898 17.2348 16.8647 16.8599C17.2395 16.485 17.8499 16.485 18.2248 16.8599L27.5487 26.1838C27.9236 26.5587 27.9236 27.169 27.5487 27.5439C27.3612 27.7314 27.1161 27.8275 26.871 27.8275H26.8662Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M5.21946 42.2219C2.34059 42.2219 0 39.8813 0 37.0024C0 34.1235 2.34059 31.783 5.21946 31.783C8.09833 31.783 10.4389 34.1235 10.4389 37.0024C10.4389 39.8813 8.09833 42.2219 5.21946 42.2219ZM5.21946 33.7006C3.39793 33.7006 1.91765 35.1809 1.91765 37.0024C1.91765 38.8239 3.39793 40.3042 5.21946 40.3042C7.04098 40.3042 8.52127 38.8239 8.52127 37.0024C8.52127 35.1809 7.04098 33.7006 5.21946 33.7006Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M22.6657 37.9588H9.48247C8.95379 37.9588 8.52124 37.5263 8.52124 36.9976C8.52124 36.4689 8.95379 36.0364 9.48247 36.0364H22.6657C23.1944 36.0364 23.6269 36.4689 23.6269 36.9976C23.6269 37.5263 23.1944 37.9588 22.6657 37.9588Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M14.529 64.6905C13.1353 64.6905 11.8232 64.1474 10.8379 63.1622C9.85266 62.1769 9.30957 60.8648 9.30957 59.471C9.30957 58.0773 9.85266 56.7652 10.8379 55.7799C11.8232 54.7947 13.1353 54.2516 14.529 54.2516C15.9228 54.2516 17.2349 54.7947 18.2201 55.7799C19.2054 56.7652 19.7485 58.0773 19.7485 59.471C19.7485 60.8648 19.2054 62.1769 18.2201 63.1622C17.2349 64.1474 15.9228 64.6905 14.529 64.6905ZM14.529 56.1692C13.6495 56.1692 12.818 56.5105 12.1981 57.1353C11.5733 57.7601 11.232 58.5867 11.232 59.4662C11.232 60.3458 11.5733 61.1772 12.1981 61.7972C12.8229 62.422 13.6495 62.7632 14.529 62.7632C15.4086 62.7632 16.24 62.422 16.86 61.7972C17.4848 61.1724 17.826 60.3458 17.826 59.4662C17.826 58.5867 17.4848 57.7553 16.86 57.1353C16.2352 56.5105 15.4086 56.1692 14.529 56.1692Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M17.5423 57.4188C17.2972 57.4188 17.0521 57.3227 16.8647 57.1352C16.4898 56.7604 16.4898 56.15 16.8647 55.7751L26.1885 46.4512C26.5634 46.0763 27.1738 46.0763 27.5487 46.4512C27.9236 46.8261 27.9236 47.4365 27.5487 47.8113L18.2248 57.1352C18.0373 57.3227 17.7922 57.4188 17.5471 57.4188H17.5423Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M36.9975 74C34.1187 74 31.7781 71.6594 31.7781 68.7805C31.7781 65.9016 34.1187 63.561 36.9975 63.561C39.8764 63.561 42.217 65.9016 42.217 68.7805C42.217 71.6594 39.8764 74 36.9975 74ZM36.9975 65.4787C35.176 65.4787 33.6957 66.959 33.6957 68.7805C33.6957 70.602 35.176 72.0823 36.9975 72.0823C38.8191 72.0823 40.2993 70.602 40.2993 68.7805C40.2993 66.959 38.8191 65.4787 36.9975 65.4787Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M36.9976 65.4787C36.4689 65.4787 36.0364 65.0462 36.0364 64.5175V51.3343C36.0364 50.8056 36.4689 50.373 36.9976 50.373C37.5263 50.373 37.9588 50.8056 37.9588 51.3343V64.5175C37.9588 65.0462 37.5263 65.4787 36.9976 65.4787Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M59.4712 64.6905C58.0774 64.6905 56.7653 64.1474 55.7801 63.1622C54.7948 62.1769 54.2517 60.8648 54.2517 59.471C54.2517 58.0773 54.7948 56.7652 55.7801 55.7799C56.7653 54.7947 58.0774 54.2516 59.4712 54.2516C60.8649 54.2516 62.177 54.7947 63.1623 55.7799C64.1475 56.7652 64.6906 58.0773 64.6906 59.471C64.6906 60.8648 64.1475 62.1769 63.1623 63.1622C62.177 64.1474 60.8649 64.6905 59.4712 64.6905ZM59.4712 56.1692C58.5916 56.1692 57.7602 56.5105 57.1402 57.1353C56.5154 57.7601 56.1742 58.5867 56.1742 59.4662C56.1742 60.3458 56.5154 61.1772 57.1402 61.7972C57.765 62.422 58.5916 62.7632 59.4712 62.7632C60.3507 62.7632 61.1821 62.422 61.8021 61.7972C62.4269 61.1724 62.7682 60.3458 62.7682 59.4662C62.7682 58.5867 62.4269 57.7553 61.8021 57.1353C61.1773 56.5105 60.3507 56.1692 59.4712 56.1692Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M56.4575 57.4188C56.2124 57.4188 55.9673 57.3227 55.7799 57.1352L46.456 47.8113C46.0811 47.4365 46.0811 46.8261 46.456 46.4512C46.8308 46.0763 47.4412 46.0763 47.8161 46.4512L57.14 55.7751C57.5149 56.15 57.5149 56.7604 57.14 57.1352C56.9526 57.3227 56.7074 57.4188 56.4623 57.4188H56.4575Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M68.7759 42.2219C65.897 42.2219 63.5564 39.8813 63.5564 37.0024C63.5564 34.1235 65.897 31.783 68.7759 31.783C71.6547 31.783 73.9953 34.1235 73.9953 37.0024C73.9953 39.8813 71.6547 42.2219 68.7759 42.2219ZM68.7759 33.7006C66.9543 33.7006 65.474 35.1809 65.474 37.0024C65.474 38.8239 66.9543 40.3042 68.7759 40.3042C70.5974 40.3042 72.0777 38.8239 72.0777 37.0024C72.0777 35.1809 70.5974 33.7006 68.7759 33.7006Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M64.5175 37.9588H51.3343C50.8056 37.9588 50.373 37.5263 50.373 36.9976C50.373 36.4689 50.8056 36.0364 51.3343 36.0364H64.5175C65.0462 36.0364 65.4787 36.4689 65.4787 36.9976C65.4787 37.5263 65.0462 37.9588 64.5175 37.9588Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M59.4712 19.7484C58.1351 19.7484 56.799 19.2389 55.7801 18.22C54.7948 17.2348 54.2517 15.9227 54.2517 14.5289C54.2517 13.1351 54.7948 11.8231 55.7801 10.8378C57.8179 8.8 61.1293 8.8 63.1623 10.8378C64.1475 11.8231 64.6906 13.1351 64.6906 14.5289C64.6906 15.9227 64.1475 17.2348 63.1623 18.22C62.1434 19.2389 60.8073 19.7484 59.4712 19.7484ZM59.4712 11.2319C58.6253 11.2319 57.7794 11.5539 57.1402 12.1979C55.8522 13.486 55.8522 15.5766 57.1402 16.8647C58.4282 18.1527 60.5189 18.1527 61.807 16.8647C63.095 15.5766 63.095 13.486 61.807 12.1979C61.1629 11.5539 60.317 11.2319 59.476 11.2319H59.4712Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M47.1336 27.8275C46.8885 27.8275 46.6434 27.7314 46.456 27.5439C46.0811 27.169 46.0811 26.5587 46.456 26.1838L55.7799 16.8599C56.1547 16.485 56.7651 16.485 57.14 16.8599C57.5149 17.2348 57.5149 17.8451 57.14 18.22L47.8161 27.5439C47.6287 27.7314 47.3835 27.8275 47.1384 27.8275H47.1336Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M36.9977 39.1651C33.8208 39.1651 31.2351 36.5794 31.2351 33.4026C31.2351 30.2257 33.8208 27.64 36.9977 27.64C40.1745 27.64 42.7602 30.2257 42.7602 33.4026C42.7602 36.5794 40.1745 39.1651 36.9977 39.1651ZM36.9977 29.5625C34.8782 29.5625 33.1576 31.2879 33.1576 33.4026C33.1576 35.5173 34.883 37.2427 36.9977 37.2427C39.1124 37.2427 40.8378 35.5173 40.8378 33.4026C40.8378 31.2879 39.1124 29.5625 36.9977 29.5625Z"
                          fill="#51AD32"
                        />
                        <path
                          d="M48.5851 46.3936C48.3544 46.3936 48.1237 46.3119 47.9363 46.1436C44.942 43.4089 41.0587 41.9046 36.9927 41.9046C32.9267 41.9046 29.0482 43.4089 26.0539 46.1436C25.6598 46.5041 25.0543 46.4753 24.6986 46.0812C24.343 45.6871 24.367 45.0815 24.7611 44.7258C28.111 41.6643 32.4557 39.9822 36.9975 39.9822C41.5393 39.9822 45.8888 41.6691 49.2339 44.7258C49.628 45.0815 49.652 45.6919 49.2964 46.0812C49.1089 46.2878 48.8494 46.3936 48.5851 46.3936Z"
                          fill="#51AD32"
                        />
                      </g>
                      <defs>
                        <clipPath id="clip0_network">
                          <rect width="74" height="74" fill="white" />
                        </clipPath>
                      </defs>
                    </svg>
                    <div className="text-left">
                      <p className="text-[32px] font-bold leading-none">
                        3 générations
                      </p>
                      <p className="text-sm uppercase leading-tight">
                        d'engagement
                      </p>
                    </div>
                  </div>

                  {/* ancrage local */}
                  <div className="flex items-center justify-center gap-4">
                    <svg
                      width="57"
                      height="57"
                      viewBox="0 0 57 57"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                      className="w-12 h-12 flex-shrink-0"
                    >
                      <path
                        d="M49.875 23.75C49.875 40.375 28.5 54.625 28.5 54.625C28.5 54.625 7.125 40.375 7.125 23.75C7.125 18.081 9.377 12.6442 13.3856 8.63559C17.3942 4.627 22.831 2.375 28.5 2.375C34.169 2.375 39.6058 4.627 43.6144 8.63559C47.623 12.6442 49.875 18.081 49.875 23.75Z"
                        stroke="#51AD32"
                        strokeWidth="4"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M28.5 30.875C32.435 30.875 35.625 27.685 35.625 23.75C35.625 19.815 32.435 16.625 28.5 16.625C24.565 16.625 21.375 19.815 21.375 23.75C21.375 27.685 24.565 30.875 28.5 30.875Z"
                        stroke="#51AD32"
                        strokeWidth="4"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    <div className="text-left">
                      <p className="text-[32px] font-bold leading-none">
                        ancrage local
                      </p>
                      <p className="text-sm uppercase leading-tight">
                        sur vos territoires
                      </p>
                    </div>
                  </div>
                </div>

                <Link
                  to="/notre-histoire"
                  className="inline-block px-12 py-3 rounded-full bg-verbus-green text-white text-base font-normal hover:bg-verbus-green/90 transition-colors"
                >
                  découvrir notre histoire
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Careers Section - Rejoignez nos équipes */}
      <section className="py-20 bg-white">
        <div className="max-w-[1920px] mx-auto px-8">
          {/* Top - Title and Description */}
          <div className="text-center mb-16">
            <h2 className="text-[45px] font-bold text-verbus-dark mb-6">
              Rejoignez nos équipes
            </h2>
            <div className="max-w-[795px] mx-auto text-center">
              <p className="text-[20px] text-verbus-dark leading-tight mb-6">
                Chez Verbus, chaque collaborateur contribue à une mobilité plus
                durable et humaine. Nous recherchons des talents passionnés pour
                conduire l'avenir avec nous.
              </p>
              <div className="text-[20px] font-bold text-verbus-dark leading-tight space-y-2">
                <p>Équipe bienveillante et solidaire</p>
                <p>Formation continue et certifications</p>
                <p>Évolution de carrière</p>
              </div>
            </div>
          </div>

          {/* Bottom - Layout with Overlapping Sections */}
          <div className="relative">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
              {/* Left Column - Green Box and Photo Stacked */}
              <div className="relative">
                {/* Green Icon Box */}
                <div className="bg-verbus-green text-white p-12 flex flex-col items-center justify-center min-h-[300px]">
                  {/* Star Icon */}
                  <svg
                    className="w-32 h-32 mb-6"
                    viewBox="0 0 100 100"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M50 0L55 45H50L45 0L50 0Z" fill="white" />
                    <path d="M50 0L65 15L50 20L35 15L50 0Z" fill="white" />
                    <path d="M0 50L45 45V50L0 55V50Z" fill="white" />
                    <path d="M100 50L55 45V50L100 55V50Z" fill="white" />
                    <path d="M50 100L45 55H50L55 100H50Z" fill="white" />
                    <path d="M15 85L45 55L50 60L20 90L15 85Z" fill="white" />
                    <path d="M85 85L55 55L50 60L80 90L85 85Z" fill="white" />
                    <path d="M15 15L45 45L40 50L10 20L15 15Z" fill="white" />
                    <path d="M85 15L55 45L60 50L90 20L85 15Z" fill="white" />
                  </svg>

                  <div className="text-center text-white uppercase font-bold">
                    <p className="text-2xl">RELIER</p>
                    <p className="text-2xl">LES GENS</p>
                    <p className="text-2xl">LES LIEUX</p>
                    <p className="text-2xl">& LES VIES</p>
                  </div>
                </div>

                {/* Photo - No gap with green box */}
                <div className="h-[350px] lg:h-[350px]">
                  <img
                    src="https://api.builder.io/api/v1/image/assets/TEMP/0db20a9da62eca9677c9e9219075d9b2d4cd2be4?width=1804"
                    alt="Conducteur Verbus"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>

              {/* Right Column - Placeholder for spacing */}
              <div className="hidden lg:block"></div>
            </div>

            {/* Dark Background with Job Cards - Overlapping */}
            <div className="relative lg:absolute lg:right-0 lg:top-[80px] lg:w-[68%] bg-[#1E1E1E] rounded-tr-[40px] rounded-br-[40px] p-8 lg:p-12 flex items-center mt-8 lg:mt-0 min-h-[464px]">
              <div className="w-full">
                {/* Job Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Job Card 1 */}
                  <div className="text-center text-white">
                    <p className="text-xs uppercase mb-2 opacity-75">
                      AVEYRON (12)
                    </p>
                    <div className="w-full h-px bg-white opacity-20 mb-3"></div>
                    <p className="text-xs uppercase mb-4 opacity-75">
                      NOUS RECRUTONS
                    </p>
                    <h3 className="text-lg font-bold mb-6">un chauffeur</h3>
                    <p className="text-sm mb-6 opacity-90 leading-relaxed">
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Cras suscipit consequat dolor a scelerisque.
                    </p>
                    <button className="px-6 py-2 rounded-full border border-white text-white text-sm hover:bg-white hover:text-verbus-dark transition-colors">
                      Consulter l'offre
                    </button>
                  </div>

                  {/* Job Card 2 */}
                  <div className="text-center text-white">
                    <p className="text-xs uppercase mb-2 opacity-75">
                      AVEYRON (12)
                    </p>
                    <div className="w-full h-px bg-white opacity-20 mb-3"></div>
                    <p className="text-xs uppercase mb-4 opacity-75">
                      NOUS RECRUTONS
                    </p>
                    <h3 className="text-lg font-bold mb-6">un chauffeur</h3>
                    <p className="text-sm mb-6 opacity-90 leading-relaxed">
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Cras suscipit consequat dolor a scelerisque.
                    </p>
                    <button className="px-6 py-2 rounded-full border border-white text-white text-sm hover:bg-white hover:text-verbus-dark transition-colors">
                      Consulter l'offre
                    </button>
                  </div>

                  {/* Job Card 3 */}
                  <div className="text-center text-white">
                    <p className="text-xs uppercase mb-2 opacity-75">
                      AVEYRON (12)
                    </p>
                    <div className="w-full h-px bg-white opacity-20 mb-3"></div>
                    <p className="text-xs uppercase mb-4 opacity-75">
                      NOUS RECRUTONS
                    </p>
                    <h3 className="text-lg font-bold mb-6">un chauffeur</h3>
                    <p className="text-sm mb-6 opacity-90 leading-relaxed">
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Cras suscipit consequat dolor a scelerisque.
                    </p>
                    <button className="px-6 py-2 rounded-full border border-white text-white text-sm hover:bg-white hover:text-verbus-dark transition-colors">
                      Consulter l'offre
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Button */}
          <div className="flex justify-center mt-12 lg:mt-32">
            <button className="px-12 py-3 rounded-full bg-verbus-green text-white text-base font-normal hover:bg-verbus-green/90 transition-colors">
              voir nos opportunités
            </button>
          </div>
        </div>
      </section>

      {/* Actualités Section - News */}
      <section className="py-20 bg-white">
        <div className="max-w-[1920px] mx-auto px-8">
          {/* Title Section */}
          <div className="text-center mb-16">
            <p className="text-[20px] text-verbus-dark mb-6">
              Restez informé de nos dernières nouveautés
            </p>

            <div className="flex items-center justify-center gap-6 mb-12">
              {/* Bird Icon */}
              <svg
                className="w-[158px] h-[138px]"
                viewBox="0 0 158 138"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M39.8396 0.00688081C41.1819 -0.160086 42.4909 2.78522 42.9432 3.75029C44.204 6.43846 45.6019 10.0516 46.5438 12.8533C46.9146 13.9653 48.4794 17.268 45.8986 16.1292C43.8072 15.2042 40.7147 7.82429 39.9694 5.67041C39.5875 4.55841 37.8336 0.257332 39.8396 0.00688081Z"
                  fill="#E72475"
                />
                <path
                  d="M39.9402 20.5506C38.6535 21.0916 36.6067 18.0528 36.0245 17.2681C33.7848 14.246 31.9086 10.96 29.947 7.78766L29.8877 7.3068C30.7739 5.82747 32.183 7.37359 32.9654 8.13496C34.8973 10.0117 38.9946 16.0425 39.8512 18.4502C39.9921 18.8509 40.4334 20.3436 39.9402 20.5506Z"
                  fill="#E72475"
                />
                <path
                  d="M62.5846 0.728106C63.3002 0.634604 63.3855 1.42603 63.3818 1.87684C63.3633 4.0374 62.351 11.0433 61.335 12.8332C61.0903 13.264 60.7751 13.6447 60.3153 13.9118C58.4242 11.2905 58.4909 6.40833 59.7368 3.55319C60.0817 2.75843 61.6613 0.848322 62.5846 0.728106Z"
                  fill="#E72475"
                />
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M78.4264 41.4852C86.7065 47.7698 93.1955 55.7675 97.5043 65.8423L97.5191 65.8791C100.63 72.7281 100.715 77.5167 98.9244 81.1532C67.4691 78.5619 55.926 52.318 51.6173 28.2614C61.8589 31.4504 70.8917 35.7682 78.4264 41.4852ZM98.5351 53.3098C98.5685 50.3277 99.9479 45.095 101.357 43.078C102.595 41.3048 104.29 39.9858 106.274 39.2645C108.246 38.5465 110.505 38.5065 112.948 39.0408C117.954 40.1361 123.624 44.7377 123.624 44.7377C108.243 50.9956 121.384 64.737 111.224 76.9624C109.437 79.1129 106.997 80.5087 103.801 81.0197C105.113 76.9423 104.598 71.6895 101.349 64.5133C96.7775 53.824 89.8842 45.3321 81.0814 38.6501C72.3193 32.0014 61.6883 27.166 49.589 23.7566L46.248 22.8149L46.96 25.9004C53.0634 52.3881 60.1458 79.1663 96.3844 84.6095C93.2623 87.695 88.5197 89.8622 83.473 92.1731C75.7677 95.6961 67.4358 99.5063 62.2186 106.729C62.2186 106.729 55.9854 114.463 58.6032 124.892C64.1727 108.683 63.8612 108.165 85.3345 95.4891C92.0572 92.4169 98.3163 89.5517 101.746 84.9701C107.36 84.8098 111.762 82.9131 114.517 79.183C129.178 59.3239 105.035 46.3873 140.733 46.1636L157.778 45.8597L128.325 43.3719C128.325 43.3719 121.069 37.164 114.632 35.5745C111.083 34.6963 107.523 34.8065 104.731 35.8216C101.95 36.8335 99.4473 39.0007 98.1717 41.6555C95.8245 46.5409 98.5351 53.3131 98.5351 53.3131V53.3098Z"
                  fill="#E71D73"
                />
                <path
                  d="M65.5136 137.718C59.2767 137.718 52.6319 136.733 45.6497 134.759C34.6145 131.644 24.6436 125.493 15.0027 119.542C10.1192 116.527 5.06889 113.411 0 110.773L0.752732 109.601C5.87353 112.266 10.9461 115.398 15.8556 118.427C25.4038 124.321 35.2783 130.415 46.102 133.47C57.6118 136.72 68.1463 137.237 77.4016 135.013L77.7909 136.322C73.9049 137.257 69.8038 137.725 65.5136 137.725V137.718Z"
                  fill="#E72475"
                />
              </svg>

              <h2 className="text-[40px] font-bold text-verbus-dark">
                l'actualités récentes
              </h2>
            </div>
          </div>

          {/* News Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {/* News Card 1 */}
            <div className="flex gap-4 items-start bg-[#FAFAFC] p-6 rounded-lg">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/f668479482b6038e48c78fae397bf664dc157a2a?width=530"
                alt="Événement Verbus"
                className="w-[120px] h-[120px] object-cover rounded-br-[16px] flex-shrink-0"
              />
              <div className="flex flex-col justify-start flex-1">
                <p className="text-[11px] text-black mb-2">15 janvier 2025</p>
                <p className="text-[14px] font-bold text-verbus-green mb-3">
                  Innovation
                </p>
                <p className="text-[12px] text-verbus-dark leading-tight mb-3">
                  Verbus investit dans 50 nouveaux autocars 100% électriques
                  pour réduire son empreinte carbone.
                </p>
                <a
                  href="#"
                  className="text-[12px] text-verbus-dark hover:text-verbus-green transition-colors"
                >
                  lire la suite
                </a>
              </div>
            </div>

            {/* News Card 2 */}
            <div className="flex gap-4 items-start bg-[#FAFAFC] p-6 rounded-lg">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/f668479482b6038e48c78fae397bf664dc157a2a?width=530"
                alt="Événement Verbus"
                className="w-[120px] h-[120px] object-cover rounded-br-[16px] flex-shrink-0"
              />
              <div className="flex flex-col justify-start flex-1">
                <p className="text-[11px] text-black mb-2">10 janvier 2025</p>
                <p className="text-[14px] font-bold text-verbus-green mb-3">
                  Services
                </p>
                <p className="text-[12px] text-verbus-dark leading-tight mb-3">
                  Extension de notre service de transport scolaire dans 12
                  nouvelles communes.
                </p>
                <a
                  href="#"
                  className="text-[12px] text-verbus-dark hover:text-verbus-green transition-colors"
                >
                  lire la suite
                </a>
              </div>
            </div>

            {/* News Card 3 */}
            <div className="flex gap-4 items-start bg-[#FAFAFC] p-6 rounded-lg">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/f668479482b6038e48c78fae397bf664dc157a2a?width=530"
                alt="Événement Verbus"
                className="w-[120px] h-[120px] object-cover rounded-br-[16px] flex-shrink-0"
              />
              <div className="flex flex-col justify-start flex-1">
                <p className="text-[11px] text-black mb-2">05 janvier 2025</p>
                <p className="text-[14px] font-bold text-verbus-green mb-3">
                  Qualité
                </p>
                <p className="text-[12px] text-verbus-dark leading-tight mb-3">
                  Reconnaissance de notre engagement pour la santé et la
                  sécurité au travail.
                </p>
                <a
                  href="#"
                  className="text-[12px] text-verbus-dark hover:text-verbus-green transition-colors"
                >
                  lire la suite
                </a>
              </div>
            </div>
          </div>

          {/* CTA Button */}
          <div className="flex justify-center">
            <button className="px-12 py-3 rounded-full bg-verbus-green text-white text-[16px] font-normal hover:bg-verbus-green/90 transition-colors">
              voir toutes les actualités
            </button>
          </div>
        </div>
      </section>

      {/* CTA Section - Voyage sur mesure */}
      <section className="py-20 bg-white">
        <div className="max-w-[1200px] mx-auto px-8 flex justify-center">
          <div className="relative bg-verbus-green rounded-[40px] overflow-hidden w-full">
            <div className="flex flex-col lg:flex-row items-stretch gap-0">
              {/* Left - Photo */}
              <div className="w-full lg:w-[35%] lg:flex-shrink-0">
                <img
                  src="https://api.builder.io/api/v1/image/assets/TEMP/30ee441482cf307ad6eec7b10ad5562e0dcc175e?width=700"
                  alt="Personnalisez votre voyage"
                  className="w-full h-[350px] lg:h-full object-cover"
                />
              </div>
              {/* Right - Content */}
              <div className="w-full lg:w-[65%] flex flex-col items-center justify-center p-8 lg:p-12 text-center text-white">
                <p className="text-[14px] font-bold uppercase mb-4 tracking-wide">
                  voyage sur-mesure
                </p>
                <h2 className="text-[32px] lg:text-[40px] font-bold mb-6 leading-tight">
                  Prêt à créer votre
                  <br />
                  voyage idéal ?
                </h2>
                <p className="text-[15px] mb-8 max-w-md leading-relaxed">
                  Configurez votre transport en quelques clics et recevez un
                  devis personnalisé adapté à vos besoins.
                </p>
                <Link
                  to="/voyage-sur-mesure"
                  className="px-8 py-3 rounded-full bg-white text-verbus-green font-normal text-[15px] hover:bg-white/90 transition-colors mb-4"
                >
                  personnaliser son voyage
                </Link>
                <p className="text-[12px] italic opacity-90">
                  Réponse garantie sous 24h • Sans engagement
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
