import PlaceholderPage from "@/components/PlaceholderPage";

export default function Devis() {
  return (
    <PlaceholderPage
      title="Demander un Devis"
      description="Obtenez votre devis personnalisé en quelques clics"
    />
  );
}
