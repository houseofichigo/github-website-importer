import PlaceholderPage from "@/components/PlaceholderPage";

export default function PourquoiVerbus() {
  return (
    <PlaceholderPage
      title="Pourquoi VERBUS"
      description="60 ans d'expérience au service de votre mobilité"
    />
  );
}
