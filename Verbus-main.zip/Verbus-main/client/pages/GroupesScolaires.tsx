import { Link } from "react-router-dom";
import Layout from "@/components/Layout";

export default function GroupesScolaires() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative min-h-[600px] lg:min-h-[928px] flex items-center overflow-hidden">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/e5f34003d0fba33d0fa50b386cf98336c4dc0402?width=4456"
          alt="Groupes scolaires"
          className="absolute inset-0 w-full h-full object-cover rounded-[40px] ml-[-264px]"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1E1E1E] via-[#1E1E1E]/70 to-transparent"></div>
        
        {/* Decorative SVG Elements */}
        <div className="absolute top-[188px] left-[186px]">
          <svg width="36" height="33" viewBox="0 0 36 33" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M28.3742 28.7757H25.6863C23.6289 28.7757 21.5722 28.7757 19.5147 28.7757C17.2429 28.7757 14.971 28.7757 12.6984 28.7757C11.1578 28.7757 9.61708 28.7757 8.07641 28.7757C7.75778 28.7757 7.40376 28.8071 7.09195 28.7369C6.1783 28.5304 5.6602 27.7398 5.65816 26.8368C5.65612 25.7354 5.65816 24.6341 5.65816 23.5327C5.65816 21.4684 5.65816 19.404 5.65816 17.3397C5.65816 15.0266 5.65816 12.7135 5.65816 10.401C5.65816 8.5541 5.65816 6.70715 5.65816 4.86021C5.65816 4.3368 5.65816 3.8127 5.65816 3.28929C5.65816 2.8865 5.63978 2.49326 5.80794 2.11092C6.14426 1.3442 6.8809 1.02729 7.6686 1.02729C8.13972 1.02729 8.61016 1.02729 9.08128 1.02729C10.9447 1.02729 12.8081 1.02729 14.6714 1.02729C16.978 1.02729 19.2853 1.02729 21.5919 1.02729C23.3961 1.02729 25.1995 1.02729 27.0037 1.02729C27.4203 1.02729 27.837 1.02661 28.2537 1.02729C29.2007 1.02934 30.0592 1.63317 30.1749 2.62411C30.2055 2.88378 30.1851 3.15775 30.1851 3.41809C30.1851 3.98717 30.1851 4.55693 30.1851 5.12601C30.1851 7.02338 30.1851 8.92076 30.1851 10.8181C30.1851 13.1367 30.1851 15.4553 30.1851 17.7731C30.1851 20.091 30.1851 21.8228 30.1851 23.8483C30.1851 24.8651 30.1906 25.8827 30.1851 26.8995C30.1797 27.9163 29.4172 28.756 28.3742 28.7771C27.7179 28.7907 27.7158 29.813 28.3742 29.7994C29.9414 29.7674 31.1832 28.5222 31.2063 26.952C31.2104 26.6712 31.2063 26.3904 31.2063 26.1103V21.3955C31.2063 19.0953 31.2063 16.7945 31.2063 14.4943C31.2063 12.1941 31.2063 9.98054 31.2063 7.72331C31.2063 6.2812 31.2063 4.83908 31.2063 3.39697C31.2063 3.03848 31.2179 2.68341 31.158 2.32833C30.9258 0.961183 29.6854 0.0138578 28.3326 0.00363482C27.2106 -0.00454353 26.0887 0.00363482 24.9667 0.00363482C22.7772 0.00363482 20.5877 0.00363482 18.3982 0.00363482C16.2087 0.00363482 13.8674 0.00363482 11.6023 0.00363482C10.2863 0.00363482 8.97031 0.00363482 7.65498 0.00363482C6.67597 0.00363482 5.77662 0.365527 5.18295 1.17246C4.75608 1.75244 4.6383 2.42374 4.6383 3.12231C4.6383 4.40972 4.6383 5.69713 4.6383 6.98454C4.6383 9.1811 4.6383 11.377 4.6383 13.5736C4.6383 15.7701 4.6383 18.2284 4.6383 20.5558C4.6383 22.2719 4.6383 23.9873 4.6383 25.7034C4.6383 26.0878 4.63694 26.4722 4.6383 26.8572C4.6417 27.9497 5.18499 28.9904 6.18647 29.4886C6.74065 29.764 7.30777 29.798 7.90484 29.798C8.50191 29.798 9.05882 29.798 9.63615 29.798C11.6663 29.798 13.6965 29.798 15.7274 29.798C18.0694 29.798 20.4114 29.798 22.7534 29.798C24.386 29.798 26.0185 29.798 27.6511 29.798H28.3755C29.0325 29.798 29.0339 28.7757 28.3755 28.7757H28.3742Z" fill="#51AD32"/>
          </svg>
        </div>

        <div className="relative z-10 max-w-[1920px] mx-auto px-8 lg:px-24 w-full">
          <div className="max-w-xl">
            <p className="text-base italic text-white mb-4">
              Services l Groupes scolaires
            </p>
            <div className="w-[189px] h-[1px] bg-verbus-green mb-8"></div>
            <h1 className="text-4xl lg:text-[40px] font-bold text-white leading-tight mb-8 uppercase">
              Groupes scolaires
            </h1>
            <p className="text-base text-white mb-8 leading-relaxed">
              Un transport scolaire simple, sûr et pensé pour les élèves.
              Depuis des décennies, VERBUS accompagne écoles, établissements et collectivités dans l'organisation de sorties pédagogiques, séjours scolaires et déplacements éducatifs, avec une exigence forte en matière de sécurité et de fiabilité.
            </p>
            <Link
              to="/devis"
              className="inline-flex items-center justify-center px-6 py-3 rounded-full bg-verbus-green text-white text-base font-normal hover:bg-verbus-green/90 transition-colors"
            >
              demander un devis
            </Link>
          </div>
        </div>
      </section>

      {/* Pourquoi choisir VERBUS Section */}
      <section className="py-20 bg-[#FAFAFC]">
        <div className="max-w-[1920px] mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-16 uppercase leading-tight">
            Pourquoi choisir VERBUS ?
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 max-w-6xl mx-auto">
            {/* Benefit 1 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg width="107" height="107" viewBox="0 0 107 107" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M93.625 44.5835C93.625 75.7918 53.5 102.542 53.5 102.542C53.5 102.542 13.375 75.7918 13.375 44.5835C13.375 33.9417 17.6024 23.7357 25.1273 16.2108C32.6522 8.68594 42.8582 4.4585 53.5 4.4585C64.1418 4.4585 74.3478 8.68594 81.8727 16.2108C89.3976 23.7357 93.625 33.9417 93.625 44.5835Z" stroke="#51AD32" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M53.5 57.9585C60.8868 57.9585 66.875 51.9703 66.875 44.5835C66.875 37.1967 60.8868 31.2085 53.5 31.2085C46.1132 31.2085 40.125 37.1967 40.125 44.5835C40.125 51.9703 46.1132 57.9585 53.5 57.9585Z" stroke="#51AD32" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-verbus-dark mb-4">
                Connaissance territain
              </h3>
              <p className="text-base font-bold text-verbus-dark leading-tight">
                Des équipes qui connaissent les établissements, 
                les routes et lescontraintes locales.
              </p>
            </div>

            {/* Benefit 2 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg width="97" height="107" viewBox="0 0 97 107" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M65.5623 42.9093C68.4971 45.4119 70.8031 48.5923 72.3229 52.5547C73.4235 55.2659 73.4235 57.1429 72.7946 58.6027C61.5793 57.5078 57.5439 47.1324 56.0765 37.6434C59.745 38.9468 62.9419 40.6674 65.6147 42.9093M72.7422 47.6017C72.7422 46.4025 73.2663 44.3691 73.7903 43.5871C74.262 42.9093 74.8385 42.3879 75.5722 42.0751C76.2535 41.8144 77.092 41.7623 77.9306 42.0229C79.7124 42.4922 81.7039 44.317 81.7039 44.317C76.2011 46.7675 80.8654 52.1898 77.1969 56.9864C76.568 57.8206 75.677 58.3942 74.5241 58.5506C74.9957 56.9343 74.8385 54.9009 73.6855 52.0334C72.0609 47.8102 69.6501 44.4734 66.5056 41.8144C63.4136 39.1554 59.6402 37.2263 55.2903 35.8707L54.085 35.5057L54.347 36.7049C56.4433 47.1324 58.9065 57.7164 71.7988 59.9583C70.6983 61.1575 68.9688 61.9917 67.1869 62.9301C64.4093 64.2857 61.4221 65.7977 59.5878 68.6131C59.5878 68.6131 57.3343 71.6371 58.2252 75.756C60.2691 69.3952 60.1643 69.1866 67.8158 64.2336C70.2266 63.0344 72.4802 61.9395 73.6855 60.1147C75.677 60.1147 77.2493 59.3326 78.245 57.8728C83.5382 50.1043 74.9433 44.9426 87.6785 44.9426H93.7578C93.7578 44.8905 83.2762 43.7956 83.2762 43.7956C83.2762 43.7956 80.7082 41.3452 78.4022 40.6674C77.1445 40.3024 75.8867 40.3545 74.8909 40.7195C73.8952 41.1366 73.0042 41.9708 72.5326 43.0136C71.694 44.9427 72.6374 47.6017 72.6374 47.6017H72.7422Z" fill="#51AD32"/>
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-verbus-dark mb-4">
                Sécurité quotidienne
              </h3>
              <p className="text-base font-bold text-verbus-dark leading-tight">
                Contrôles systématiques, itinéraires validés et conducteurs formés au transport d'enfants.
              </p>
            </div>

            {/* Benefit 3 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg width="127" height="127" viewBox="0 0 127 127" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M52.4929 91.8959C52.4929 92.7518 51.8003 93.4493 50.9395 93.4493H25.2001C21.4206 93.4493 18.3436 90.3722 18.3436 86.5927V72.3552C18.3436 68.5806 21.4206 65.5085 25.2001 65.5085H62.3869C66.1664 65.5085 69.2435 68.5806 69.2435 72.3552V79.8202C69.2435 80.6761 68.5509 81.3736 67.6901 81.3736C66.8293 81.3736 66.1368 80.681 66.1368 79.8202V72.3552C66.1368 70.2873 64.4548 68.6103 62.382 68.6103H25.2001C23.1323 68.6103 21.4453 70.2923 21.4453 72.3552V86.5927C21.4453 88.6606 23.1273 90.3475 25.2001 90.3475H50.9395C51.7953 90.3475 52.4929 91.0401 52.4929 91.9009V91.8959Z" fill="#51AD32"/>
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-verbus-dark mb-4">
                Accompagnement humain
              </h3>
              <p className="text-base font-bold text-verbus-dark leading-tight">
                Un interlocuteur dédié de la réservation
                jusqu'au retour de vos élèves.
              </p>
            </div>

            {/* Benefit 4 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg width="91" height="109" viewBox="0 0 91 109" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M15.2968 28.9482C15.4494 28.7997 15.4537 28.5594 15.3099 28.4108C15.3099 28.4108 15.3099 28.4108 15.3099 28.4065L12.1843 25.2739C12.0012 25.0904 11.7091 25.0817 11.526 25.2608L8.87558 27.7205C8.25656 28.2929 7.2888 28.2579 6.71337 27.6375L6.4213 27.3317C5.90691 26.7768 5.92434 25.9118 6.46053 25.3744L14.1765 17.6415C14.7911 17.0254 15.7894 17.0254 16.4041 17.6415L16.9446 18.1832C17.4546 18.6856 17.459 19.507 16.9577 20.0181C16.9446 20.0312 16.9315 20.0444 16.9185 20.0575L14.9045 21.923C14.5688 22.2332 14.547 22.7618 14.8609 23.0982C14.8696 23.107 14.8739 23.1157 14.8827 23.1201L17.5375 25.7807C17.9865 26.2351 18.7014 26.2832 19.2071 25.8943C23.623 22.4953 28.6841 20.1012 34.3948 18.7118C35.9118 18.3405 37.1063 18.039 37.9869 17.7987C38.2135 17.7376 38.3661 17.5279 38.3705 17.2876V13.3905C38.3705 13.0191 38.0871 12.709 37.7209 12.6871L35.2274 12.4992C35.0225 12.4861 34.8177 12.425 34.6346 12.3201C31.6354 10.6337 32.0364 6.67985 32.5683 3.68715C33.1175 0.537164 35.4672 -0.0613774 38.5361 0.00415631C42.0628 0.0784278 47.1501 0.10901 53.7936 0.0959035C56.2043 0.0959035 57.9175 1.00901 58.2967 3.48618C58.9114 7.49684 59.2253 12.9361 53.4928 12.7264C53.1179 12.7133 52.8041 13.0104 52.791 13.3861C52.791 13.3949 52.791 13.3992 52.791 13.408V17.3225C52.791 17.6021 52.9871 17.8381 53.2531 17.8905C60.5025 19.3104 66.9368 22.124 72.556 26.3356C72.7957 26.5103 73.1314 26.4885 73.3406 26.2744L76.4096 23.1987C76.6493 22.9541 76.658 22.5652 76.4226 22.3118L74.0425 19.7385C73.8245 19.4982 73.8071 19.14 73.9989 18.8822C74.631 18.0172 75.0843 17.5366 75.359 17.4361C76.0041 17.2133 76.7147 17.375 77.2073 17.8468L84.8709 25.2259C85.5074 25.8375 85.5292 26.8555 84.9189 27.4934C84.9102 27.5021 84.9014 27.5108 84.8927 27.5196L84.5353 27.8778C83.9511 28.4589 83.0139 28.4589 82.4341 27.8778L80.2283 25.6715C79.8708 25.3133 79.291 25.3002 78.9205 25.6497L76.1524 28.2142C75.8603 28.4895 75.8429 28.9482 76.1175 29.2409C76.1306 29.254 76.1436 29.2671 76.1524 29.2759C84.3042 37.0132 89.0994 46.0743 90.5424 56.4505C92.6915 71.9121 87.3862 86.797 75.8472 97.326C70.2586 102.416 63.044 106.518 55.6071 107.96C46.6226 109.708 38.3051 109.231 30.6545 106.527C13.8582 100.598 1.70892 84.429 0.183169 66.9971C-0.85434 55.1136 2.56334 44.0734 10.4318 33.8676C10.8896 33.2734 12.5112 31.6351 15.2968 28.9482Z" fill="#51AD32"/>
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-verbus-dark mb-4">
                Ponctualité stricte
              </h3>
              <p className="text-base font-bold text-verbus-dark leading-tight">
                Respect des horaires scolaires et communication 
                continue avec les accompagnateurs.
              </p>
            </div>

            {/* Benefit 5 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg width="107" height="99" viewBox="0 0 107 99" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M84.9191 86.1221H76.8747C70.7171 86.1221 64.5616 86.1221 58.404 86.1221C51.6046 86.1221 44.8051 86.1221 38.0037 86.1221C33.3926 86.1221 28.7816 86.1221 24.1705 86.1221C23.2169 86.1221 22.1574 86.2159 21.2242 86.0058C18.4897 85.3878 16.9391 83.0217 16.933 80.3191C16.9269 77.0229 16.933 73.7267 16.933 70.4305C16.933 64.2521 16.933 58.0738 16.933 51.8954C16.933 44.9726 16.933 38.0498 16.933 31.129C16.933 25.6013 16.933 20.0736 16.933 14.546C16.933 12.9795 16.933 11.4109 16.933 9.84441C16.933 8.63893 16.878 7.46201 17.3813 6.31772C18.3879 4.02302 20.5925 3.07455 22.95 3.07455C24.36 3.07455 25.768 3.07455 27.178 3.07455C32.7549 3.07455 38.3317 3.07455 43.9086 3.07455C50.8119 3.07455 57.7173 3.07455 64.6207 3.07455C70.0203 3.07455 75.4178 3.07455 80.8174 3.07455C82.0644 3.07455 83.3114 3.07251 84.5584 3.07455C87.3927 3.08067 89.9621 4.88787 90.3085 7.85363C90.4002 8.63077 90.3391 9.45074 90.3391 10.2299C90.3391 11.9331 90.3391 13.6383 90.3391 15.3415C90.3391 21.0201 90.3391 26.6987 90.3391 32.3773C90.3391 39.3164 90.3391 46.2556 90.3391 53.1927C90.3391 60.1298 90.3391 65.3128 90.3391 71.3748C90.3391 74.4181 90.3554 77.4634 90.3391 80.5067C90.3228 83.55 88.0407 86.0629 84.9191 86.1262C82.9548 86.167 82.9487 89.2265 84.9191 89.1858C89.6096 89.0899 93.3262 85.3633 93.3954 80.6638C93.4077 79.8234 93.3954 78.983 93.3954 78.1447V64.0339C93.3954 57.1498 93.3954 50.2637 93.3954 43.3796C93.3954 36.4955 93.3954 29.8705 93.3954 23.1149C93.3954 18.7988 93.3954 14.4827 93.3954 10.1667C93.3954 9.09379 93.4301 8.03109 93.2508 6.96839C92.556 2.8767 88.8435 0.0414745 84.7948 0.0108785C81.4369 -0.0135982 78.0789 0.0108785 74.721 0.0108785C68.1681 0.0108785 61.6152 0.0108785 55.0624 0.0108785C48.5095 0.0108785 41.5022 0.0108785 34.7232 0.0108785C30.7845 0.0108785 26.8459 0.0108785 22.9093 0.0108785C19.9792 0.0108785 17.2876 1.09397 15.5108 3.50901C14.2332 5.24482 13.8807 7.25395 13.8807 9.34468C13.8807 13.1977 13.8807 17.0508 13.8807 20.9038C13.8807 27.4779 13.8807 34.0499 13.8807 40.6239C13.8807 47.1979 13.8807 54.5552 13.8807 61.5209C13.8807 66.657 13.8807 71.791 13.8807 76.927C13.8807 78.0774 13.8766 79.2278 13.8807 80.3802C13.8909 83.6499 15.5169 86.7646 18.5142 88.2556C20.1728 89.0797 21.8701 89.1817 23.657 89.1817C25.444 89.1817 27.1108 89.1817 28.8386 89.1817C34.9147 89.1817 40.9908 89.1817 47.0689 89.1817C54.0782 89.1817 61.0875 89.1817 68.0968 89.1817C72.9829 89.1817 77.869 89.1817 82.7552 89.1817H84.9232C86.8894 89.1817 86.8935 86.1221 84.9232 86.1221H84.9191Z" fill="#51AD32"/>
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-verbus-dark mb-4">
                Organisation fluide
              </h3>
              <p className="text-base font-bold text-verbus-dark leading-tight">
                Planning adapté aux contraintes scolaires,
                devis rapide et facturation claire.
              </p>
            </div>

            {/* Benefit 6 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg width="108" height="91" viewBox="0 0 108 91" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M88.9684 52.6178C88.9684 52.7122 88.9684 53.0085 88.9684 53.3048C88.9707 62.3514 88.9326 71.3986 88.9895 80.4446C89.0271 86.3993 84.5659 90.5435 79.1155 90.5354C55.8231 90.5015 32.5301 90.5211 9.23775 90.5159C4.96959 90.5147 1.12738 87.3274 0.270902 83.1193C-0.120893 81.1943 0.0283081 79.2473 0.0260302 77.3107C0.00894618 61.4026 0.0163493 45.4945 0.0135019 29.5865C0.0135019 27.4744 0.00609887 25.3819 1.0636 23.4367C2.73898 20.3546 5.32379 18.7264 8.74231 18.6591C13.8379 18.559 18.9369 18.5952 24.0337 18.6562C25.0564 18.6683 25.2449 18.3599 25.2165 17.4094C25.1458 15.0563 25.1937 12.6991 25.1925 10.3437C25.1903 5.38544 28.2449 1.41389 32.9982 0.275294C33.8086 0.0814055 34.6702 0.0434332 35.509 0.0399812C41.2476 0.0181184 46.9872 -0.0405661 52.7246 0.0451592C56.7986 0.106145 60.1027 1.74068 62.0992 5.51317C62.8686 6.96647 63.2507 8.5498 63.2535 10.2102C63.2581 12.7026 63.286 15.195 63.2364 17.6862C63.2211 18.4496 63.4187 18.6539 64.1829 18.6487C69.381 18.6119 74.5803 18.6228 79.7789 18.632C83.8717 18.6395 87.5095 21.4034 88.6575 25.3646C88.78 25.7863 88.9582 26.2334 88.9212 26.6517C88.8238 27.7655 89.3739 27.9318 90.3004 27.8673C91.9838 27.75 93.2583 28.6446 94.3835 29.7734C98.4581 33.8589 102.519 37.9582 106.584 42.0535C108.876 44.3634 108.856 46.3179 106.523 48.6267C104.087 51.0379 101.658 53.4555 99.2189 55.8639C96.8761 58.1773 94.7075 58.114 92.3927 55.762C91.2981 54.6499 90.0954 53.6465 88.969 52.6184L88.9684 52.6178Z" fill="#51AD32"/>
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-verbus-dark mb-4">
                Véhicules adaptés
              </h3>
              <p className="text-base font-bold text-verbus-dark leading-tight">
                Choix du véhicule selon la taille du groupe,
                de 8 à 80 places.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Déplacements Scolaires Section */}
      <section className="py-20 bg-white">
        <div className="max-w-[1920px] mx-auto px-8">
          <div className="flex flex-col lg:flex-row gap-12 items-center">
            {/* Left Image */}
            <div className="lg:w-1/2">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/bf56be4fbe073006a5fd1d3d804880ccf7bdd39f?width=1452"
                alt="Transport scolaire"
                className="rounded-[40px] w-full"
              />
            </div>

            {/* Right Content */}
            <div className="lg:w-1/2">
              <h2 className="text-[40px] font-bold text-verbus-dark mb-8 lowercase leading-tight">
                Déplacements scolaires<br />pris en charge
              </h2>
              
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <svg width="13" height="12" viewBox="0 0 13 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0 mt-1">
                    <path d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137" stroke="#51AD32" strokeWidth="2"/>
                  </svg>
                  <p className="text-[25px] text-verbus-dark">Sorties pédagogiques</p>
                </div>
                <div className="flex items-start gap-4">
                  <svg width="13" height="12" viewBox="0 0 13 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0 mt-1">
                    <path d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137" stroke="#51AD32" strokeWidth="2"/>
                  </svg>
                  <p className="text-[25px] text-verbus-dark">Sorties de classe</p>
                </div>
                <div className="flex items-start gap-4">
                  <svg width="13" height="12" viewBox="0 0 13 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0 mt-1">
                    <path d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137" stroke="#51AD32" strokeWidth="2"/>
                  </svg>
                  <p className="text-[25px] text-verbus-dark">Journées d'intégration</p>
                </div>
                <div className="flex items-start gap-4">
                  <svg width="13" height="12" viewBox="0 0 13 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0 mt-1">
                    <path d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137" stroke="#51AD32" strokeWidth="2"/>
                  </svg>
                  <p className="text-[25px] text-verbus-dark">Séjours France & étranger</p>
                </div>
                <div className="flex items-start gap-4">
                  <svg width="13" height="12" viewBox="0 0 13 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0 mt-1">
                    <path d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137" stroke="#51AD32" strokeWidth="2"/>
                  </svg>
                  <p className="text-[25px] text-verbus-dark">Journées d'intégration</p>
                </div>
                <div className="flex items-start gap-4">
                  <svg width="13" height="12" viewBox="0 0 13 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0 mt-1">
                    <path d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137" stroke="#51AD32" strokeWidth="2"/>
                  </svg>
                  <p className="text-[25px] text-verbus-dark">Activités sportives et culturelles</p>
                </div>
                <div className="flex items-start gap-4">
                  <svg width="13" height="12" viewBox="0 0 13 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0 mt-1">
                    <path d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137" stroke="#51AD32" strokeWidth="2"/>
                  </svg>
                  <p className="text-[25px] text-verbus-dark">Transferts gare et aéroport</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-20 bg-white relative overflow-hidden">
        <div className="max-w-[1920px] mx-auto px-8">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            {/* Left Image */}
            <div className="lg:w-1/2 relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/e902887f96f22271c583e15130eab43d59a2d7ab?width=4034"
                alt="Testimonial"
                className="w-full"
              />
            </div>

            {/* Right Content */}
            <div className="lg:w-1/2 bg-[#FAFAFC] py-20 px-8 lg:px-16">
              <div className="flex justify-center mb-6">
                <svg width="66" height="58" viewBox="0 0 66 58" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M91.6719 21.971C80.9191 22.8208 70.5399 25.4873 60.5254 29.027C59.6221 29.3467 56.2173 30.4226 57.3985 31.7091C63.105 37.9465 69.8363 43.2639 76.0552 49.0646C77.9139 50.7955 87.5723 47.3649 85.9481 45.8524C79.7205 40.0516 72.9979 34.742 67.2914 28.4968L64.1646 31.1789C71.5908 28.5514 79.1386 26.4073 87.1294 25.7758C88.9794 25.6277 93.0963 25.1287 94.156 23.5225C95.2156 21.9164 93.244 21.8462 91.6719 21.971Z" fill="#E71D74"/>
                </svg>
              </div>
              <blockquote className="text-center">
                <p className="text-[25px] font-bold text-verbus-dark mb-8 leading-tight">
                  "Les conducteurs Verbus connaissent nos élèves par leur prénom. Cetteproximité fait toute la différence pour la sérénité des voyages scolaires."
                </p>
                <footer className="text-center">
                  <div className="text-[25px] text-verbus-dark">Marie D.</div>
                  <div className="text-base italic text-verbus-dark">Directrice d'école primaire</div>
                </footer>
              </blockquote>
            </div>
          </div>
        </div>
      </section>

      {/* Classes Recommandées Section */}
      <section className="py-20 bg-white">
        <div className="max-w-[1920px] mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-4 lowercase leading-tight">
            Classes recommandées pour le scolaire
          </h2>
          <p className="text-base font-bold text-center text-verbus-dark mb-16">
            Nos véhicules adaptés aux besoins des établissements
          </p>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 max-w-5xl mx-auto mb-8">
            {/* Classe ACCESS */}
            <div className="rounded-b-[40px] overflow-hidden">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/91ddb873b0bb79f4cad517053f75cc5e67b4e83d?width=1452"
                alt="Classe ACCESS"
                className="w-full h-[726px] object-cover"
              />
              <div className="bg-verbus-green text-white p-8 text-center">
                <h3 className="text-[40px] lg:text-[55px] font-bold uppercase mb-4">
                  CLASSE<br />ACCESS
                </h3>
                <div className="flex justify-center gap-2 mb-4">
                  <svg width="40" height="43" viewBox="0 0 40 43" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9.53057 43C8.87546 43 8.26402 42.7781 7.69625 42.3344C6.69174 41.5356 6.255 40.2043 6.51704 38.8731L8.61341 27.5573L1.01408 19.7472C0.0969229 18.8153 -0.208797 17.4396 0.140597 16.1527C0.533666 14.8215 1.4945 13.934 2.76105 13.8008L12.9372 12.5583L17.1736 2.04128C17.6977 0.798762 18.7458 0 20.0124 0C21.279 0 22.3271 0.798762 22.8512 2.04128L27.044 12.5583L37.2201 13.8008C38.443 13.934 39.4475 14.8658 39.8405 16.1527C40.2336 17.4396 39.8842 18.8153 38.967 19.7472L31.3677 27.5129L33.4641 38.8287C33.7261 40.16 33.2457 41.4912 32.2849 42.29C31.2804 43.0887 29.9701 43.1775 28.922 42.5119L20.0561 36.7874L11.1902 42.5119C10.7098 42.8225 10.1857 43 9.66159 43H9.53057Z" fill="#E71D74"/>
                  </svg>
                </div>
                <p className="text-base mb-6">
                  Solution économique pour sorties régulières et trajets courts.
                </p>
                <Link
                  to="/classe-access"
                  className="inline-flex items-center justify-center px-6 py-3 rounded-full border border-verbus-dark bg-white text-verbus-dark text-base font-normal hover:bg-white/90 transition-colors"
                >
                  découvrir
                </Link>
              </div>
            </div>

            {/* Classe ECO */}
            <div className="rounded-b-[40px] overflow-hidden">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/f0fe700dc47802be88723a34fbc162537bff72b7?width=1452"
                alt="Classe ECO"
                className="w-full h-[726px] object-cover"
              />
              <div className="bg-verbus-green text-white p-8 text-center">
                <h3 className="text-[40px] lg:text-[55px] font-bold uppercase mb-4">
                  CLASSE<br />ECO
                </h3>
                <div className="flex justify-center gap-2 mb-4">
                  <svg width="40" height="43" viewBox="0 0 40 43" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9.53057 43C8.87546 43 8.26402 42.7781 7.69625 42.3344C6.69174 41.5356 6.255 40.2043 6.51704 38.8731L8.61341 27.5573L1.01408 19.7472C0.0969229 18.8153 -0.208797 17.4396 0.140597 16.1527C0.533666 14.8215 1.4945 13.934 2.76105 13.8008L12.9372 12.5583L17.1736 2.04128C17.6977 0.798762 18.7458 0 20.0124 0C21.279 0 22.3271 0.798762 22.8512 2.04128L27.044 12.5583L37.2201 13.8008C38.443 13.934 39.4475 14.8658 39.8405 16.1527C40.2336 17.4396 39.8842 18.8153 38.967 19.7472L31.3677 27.5129L33.4641 38.8287C33.7261 40.16 33.2457 41.4912 32.2849 42.29C31.2804 43.0887 29.9701 43.1775 28.922 42.5119L20.0561 36.7874L11.1902 42.5119C10.7098 42.8225 10.1857 43 9.66159 43H9.53057Z" fill="#E71D74"/>
                  </svg>
                  <svg width="40" height="43" viewBox="0 0 40 43" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9.53057 43C8.87546 43 8.26402 42.7781 7.69625 42.3344C6.69174 41.5356 6.255 40.2043 6.51704 38.8731L8.61341 27.5573L1.01408 19.7472C0.0969229 18.8153 -0.208797 17.4396 0.140597 16.1527C0.533666 14.8215 1.4945 13.934 2.76105 13.8008L12.9372 12.5583L17.1736 2.04128C17.6977 0.798762 18.7458 0 20.0124 0C21.279 0 22.3271 0.798762 22.8512 2.04128L27.044 12.5583L37.2201 13.8008C38.443 13.934 39.4475 14.8658 39.8405 16.1527C40.2336 17.4396 39.8842 18.8153 38.967 19.7472L31.3677 27.5129L33.4641 38.8287C33.7261 40.16 33.2457 41.4912 32.2849 42.29C31.2804 43.0887 29.9701 43.1775 28.922 42.5119L20.0561 36.7874L11.1902 42.5119C10.7098 42.8225 10.1857 43 9.66159 43H9.53057Z" fill="#E71D74"/>
                  </svg>
                </div>
                <p className="text-base mb-6">
                  Confort standard pour les journées pédagogiques  et séjours.
                </p>
                <Link
                  to="/classe-eco"
                  className="inline-flex items-center justify-center px-6 py-3 rounded-full border border-verbus-dark bg-white text-verbus-dark text-base font-normal hover:bg-white/90 transition-colors"
                >
                  découvrir
                </Link>
              </div>
            </div>
          </div>

          <div className="text-center">
            <Link
              to="/vehicules"
              className="inline-flex items-center justify-center px-6 py-3 rounded-full bg-verbus-green text-white text-base font-normal hover:bg-verbus-green/90 transition-colors"
            >
              voir toutes nos classes
            </Link>
          </div>
        </div>
      </section>

      {/* Découvrez nos autres services */}
      <section className="py-20 bg-white">
        <div className="max-w-[1920px] mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-16 lowercase leading-tight">
            Découvrez nos autres services
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {/* Service 1 - Événements professionnels */}
            <div className="border border-verbus-green rounded-[40px] p-8 text-center hover:shadow-lg transition-shadow">
              <div className="flex justify-center mb-6">
                <svg width="50" height="116" viewBox="0 0 50 116" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M43.9331 41.0727H39.1562V7.47746C39.1562 3.35418 35.7581 0 31.5809 0H18.3416C14.1644 0 10.7663 3.35418 10.7663 7.47746V41.0727H5.98943C2.68724 41.0727 0 43.7252 0 46.9848V105.119C0 108.379 2.68724 111.031 5.98943 111.031H7.26218C7.4539 113.623 9.65061 115.675 12.3246 115.675C14.9986 115.675 17.1943 113.623 17.387 111.031H32.5355C32.7272 113.623 34.9239 115.675 37.5979 115.675C40.2719 115.675 42.4676 113.623 42.6603 111.031H43.9331C47.2352 111.031 49.9225 108.379 49.9225 105.119V46.9848C49.9225 43.7252 47.2352 41.0727 43.9331 41.0727Z" fill="#51AD32"/>
                </svg>
              </div>
              <h3 className="text-[25px] font-bold text-verbus-dark mb-4 lowercase">
                Événements <br />Professionnels
              </h3>
              <p className="text-base font-bold text-verbus-dark mb-6 lowercase">
                Séminaires, congrés <br />et transferts VIP
              </p>
              <Link
                to="/evenements-professionnels"
                className="inline-flex items-center justify-center p-2"
              >
                <svg width="99" height="58" viewBox="0 0 99 58" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="29" cy="29" r="28.5" stroke="#51AD32"/>
                  <path d="M23 29L35 41L47 29" stroke="#51AD32" strokeWidth="2"/>
                </svg>
              </Link>
            </div>

            {/* Service 2 - Tourisme */}
            <div className="border border-verbus-green rounded-[40px] p-8 text-center hover:shadow-lg transition-shadow">
              <div className="flex justify-center mb-6">
                <svg width="109" height="91" viewBox="0 0 109 91" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M88.9684 52.6178C88.9684 52.7122 88.9684 53.0085 88.9684 53.3048C88.9707 62.3514 88.9326 71.3986 88.9895 80.4446C89.0271 86.3993 84.5659 90.5435 79.1155 90.5354C55.8231 90.5015 32.5301 90.5211 9.23775 90.5159C4.96959 90.5147 1.12738 87.3274 0.270902 83.1193C-0.120893 81.1943 0.0283081 79.2473 0.0260302 77.3107C0.00894618 61.4026 0.0163493 45.4945 0.0135019 29.5865C0.0135019 27.4744 0.00609887 25.3819 1.0636 23.4367C2.73898 20.3546 5.32379 18.7264 8.74231 18.6591C13.8379 18.559 18.9369 18.5952 24.0337 18.6562C25.0564 18.6683 25.2449 18.3599 25.2165 17.4094C25.1458 15.0563 25.1937 12.6991 25.1925 10.3437C25.1903 5.38544 28.2449 1.41389 32.9982 0.275294C33.8086 0.0814055 34.6702 0.0434332 35.509 0.0399812C41.2476 0.0181184 46.9872 -0.0405661 52.7246 0.0451592C56.7986 0.106145 60.1027 1.74068 62.0992 5.51317C62.8686 6.96647 63.2507 8.5498 63.2535 10.2102C63.2581 12.7026 63.286 15.195 63.2364 17.6862C63.2211 18.4496 63.4187 18.6539 64.1829 18.6487C69.381 18.6119 74.5803 18.6228 79.7789 18.632C83.8717 18.6395 87.5095 21.4034 88.6575 25.3646C88.78 25.7863 88.9582 26.2334 88.9212 26.6517C88.8238 27.7655 89.3739 27.9318 90.3004 27.8673C91.9838 27.75 93.2583 28.6446 94.3835 29.7734C98.4581 33.8589 102.519 37.9582 106.584 42.0535C108.876 44.3634 108.856 46.3179 106.523 48.6267C104.087 51.0379 101.658 53.4555 99.2189 55.8639C96.8761 58.1773 94.7075 58.114 92.3927 55.762C91.2981 54.6499 90.0954 53.6465 88.969 52.6184L88.9684 52.6178Z" fill="#51AD32"/>
                </svg>
              </div>
              <h3 className="text-[25px] font-bold text-verbus-dark mb-4 lowercase">
                tourisme
              </h3>
              <p className="text-base font-bold text-verbus-dark mb-6 lowercase">
                Circuits France & Europe, voyages organisés
              </p>
              <Link
                to="/tourisme"
                className="inline-flex items-center justify-center p-2"
              >
                <svg width="99" height="58" viewBox="0 0 99 58" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="29" cy="29" r="28.5" stroke="#51AD32"/>
                  <path d="M23 29L35 41L47 29" stroke="#51AD32" strokeWidth="2"/>
                </svg>
              </Link>
            </div>

            {/* Service 3 - Sport & Loisirs */}
            <div className="border border-verbus-green rounded-[40px] p-8 text-center hover:shadow-lg transition-shadow">
              <div className="flex justify-center mb-6">
                <svg width="127" height="98" viewBox="0 0 127 98" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M126.924 79.6082L123.353 42.0957C122.527 33.4285 115.353 26.8935 106.665 26.8935H95.2302C94.1377 20.2646 91.0576 14.2584 86.2487 9.43804C80.1699 3.35273 72.0935 0 63.4993 0C54.905 0 46.8287 3.35273 40.7523 9.44051C35.9434 14.2584 32.8608 20.2671 31.7708 26.896H20.3357C11.6477 26.896 4.47148 33.4309 3.64535 42.0981L0.0769502 79.6082C-0.369408 84.3074 1.19161 89.0092 4.36051 92.5027C7.53187 95.9963 12.0522 98 16.7648 98H110.234C114.946 98 119.467 95.9963 122.638 92.5027C125.809 89.0092 127.37 84.3099 126.922 79.6082H126.924Z" fill="#51AD32"/>
                </svg>
              </div>
              <h3 className="text-[25px] font-bold text-verbus-dark mb-4 lowercase">
                Sport <br />& loisirs
              </h3>
              <p className="text-base font-bold text-verbus-dark mb-6 lowercase">
                clubs sportifs, colonies et évènements
              </p>
              <Link
                to="/sport-loisirs"
                className="inline-flex items-center justify-center p-2"
              >
                <svg width="99" height="58" viewBox="0 0 99 58" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="29" cy="29" r="28.5" stroke="#51AD32"/>
                  <path d="M23 29L35 41L47 29" stroke="#51AD32" strokeWidth="2"/>
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Voyage sur mesure Section */}
      <section className="py-20 bg-white">
        <div className="max-w-[1920px] mx-auto px-8">
          <div className="flex flex-col lg:flex-row gap-0 items-stretch rounded-[40px] overflow-hidden">
            {/* Left Image */}
            <div className="lg:w-[520px] flex-shrink-0">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/aaee0e5b015a9f389264ee30cae37d2b371df770?width=1040"
                alt="Voyage sur mesure"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Right Content */}
            <div className="flex-1 bg-verbus-green text-white p-12 lg:p-20 flex flex-col justify-center rounded-r-[40px]">
              <div className="text-center max-w-2xl mx-auto">
                <p className="text-base font-extrabold uppercase mb-2">
                  voyage sur-mesure
                </p>
                <div className="w-[263px] h-[1px] bg-black mx-auto mb-8"></div>
                <h2 className="text-[40px] font-bold leading-tight mb-8">
                  Un projet de sortie <br />ou voyage scolaire ?
                </h2>
                <p className="text-[20px] mb-8">
                  En quelques questions, nous préparons <br />
                  avec vous un devis <br />
                  adapté à votre projet, au nombre <br />
                  de voyageurset à votre budget.
                </p>
                <Link
                  to="/devis"
                  className="inline-flex items-center justify-center px-8 py-4 rounded-full bg-white text-verbus-green text-base font-normal hover:bg-white/90 transition-colors mb-4"
                >
                  personnaliser mon trajet
                </Link>
                <p className="text-[13px] italic">
                  Réponse garantie sous 24h à 48h ouvrées  • Sans engagement
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
