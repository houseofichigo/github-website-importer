import { Link } from "react-router-dom";
import Layout from "@/components/Layout";

export default function Vehicules() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative min-h-[600px] lg:min-h-[928px] flex items-center overflow-hidden">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/248756bf8f2a0ef1dd02e6b67e93721ae94d5427?width=4456"
          alt="Nos véhicules"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#63595A] via-[#63595A]/70 to-transparent"></div>
        <div className="relative z-10 max-w-[1920px] mx-auto px-8 lg:px-24 w-full">
          <div className="max-w-2xl">
            <h1 className="text-4xl lg:text-[40px] font-bold text-white leading-tight mb-8">
              Choisissez la classe de transport adaptée à votre projet
            </h1>
            <p className="text-base text-white mb-8 leading-relaxed">
              Chez VERBUS, le trajet fait partie intégrante de l'expérience que
              vous proposez à votre groupe. Un déplacement n'est jamais un
              simple enchaînement de kilomètres : c'est un moment partagé, un
              temps de transition, parfois un temps fort de la journée.
              <br />
              <br />
              C'est pourquoi nous avons conçu quatre classes de transport, pour
              répondre à différentes façons de voyager, de se retrouver et de
              vivre ensemble, selon la durée du trajet, le contexte et vos
              attentes.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link
                to="/voyage-sur-mesure"
                className="px-6 py-3 rounded-full bg-verbus-green text-white font-normal text-base hover:bg-verbus-green/90 transition-colors"
              >
                Personnaliser mon trajet
              </Link>
              <Link
                to="/devis"
                className="px-6 py-3 rounded-full bg-white text-verbus-dark font-normal text-base hover:bg-white/90 transition-colors"
              >
                Demander un devis
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="bg-verbus-green py-12">
        <div className="max-w-[1920px] mx-auto px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center text-white">
            <div>
              <div className="text-5xl font-bold mb-2">800+</div>
              <p className="text-base uppercase">Véhicules modernes</p>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">8-79</div>
              <p className="text-base uppercase">places</p>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">96,8%</div>
              <p className="text-base uppercase">de taux de satisfaction</p>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">60 ans</div>
              <p className="text-base uppercase">d'expérience</p>
            </div>
          </div>
        </div>
      </section>

      {/* Introduction Section */}
      <section className="py-20 bg-verbus-gray">
        <div className="max-w-[1920px] mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-4 lowercase">
            4 classes, 4 expériences de transport
          </h2>
          <p className="text-base font-medium text-center text-verbus-dark max-w-4xl mx-auto leading-relaxed">
            Du trajet du quotidien à l'événement d'exception, VERBUS propose une
            gamme d'autocars structurée en quatre classes distinctes. Chaque
            classe correspond à un niveau d'expérience à bord, pensé pour un
            usage précis, sans superflu ni promesse inutile. L'objectif : vous
            permettre de choisir la solution la plus juste, en fonction de votre
            projet, de votre budget et de l'expérience que vous souhaitez offrir
            à votre groupe.
          </p>
        </div>
      </section>

      {/* Vehicle Classes Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-[1920px] mx-auto px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            {/* Classe ACCESS */}
            <div className="flex flex-col">
              <div className="relative h-[336px] rounded-t-[40px] overflow-hidden">
                <img
                  src="https://api.builder.io/api/v1/image/assets/TEMP/616289c8a70abc28b890bc214ddc791b66aa8fbf?width=1458"
                  alt="Classe ACCESS"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 right-4 bg-verbus-pink text-white px-4 py-2 rounded-l-lg text-sm font-bold">
                  8 à 63 places
                  <br />
                  70 cm
                </div>
              </div>
              <div className="bg-white rounded-b-[40px] shadow-lg p-8 text-center">
                <h3 className="text-[40px] leading-tight mb-2">
                  <span className="text-verbus-green font-bold uppercase">
                    CLASSE
                  </span>
                  <br />
                  <span className="text-verbus-green font-bold text-[55px] uppercase">
                    ACCESS
                  </span>
                </h3>
                <div className="flex justify-center gap-1 mb-6">
                  <svg
                    width="40"
                    height="43"
                    viewBox="0 0 40 43"
                    fill="none"
                    className="w-8 h-8"
                  >
                    <path
                      d="M9.53057 43C8.87546 43 8.26402 42.7781 7.69625 42.3344C6.69174 41.5356 6.255 40.2043 6.51704 38.8731L8.61341 27.5573L1.01408 19.7472C0.0969229 18.8153 -0.208797 17.4396 0.140597 16.1527C0.533666 14.8215 1.4945 13.934 2.76105 13.8008L12.9372 12.5583L17.1736 2.04128C17.6977 0.798762 18.7458 0 20.0124 0C21.279 0 22.3271 0.798762 22.8512 2.04128L27.044 12.5583L37.2201 13.8008C38.443 13.934 39.4475 14.8658 39.8405 16.1527C40.2336 17.4396 39.8842 18.8153 38.967 19.7472L31.3677 27.5129L33.4641 38.8287C33.7261 40.16 33.2457 41.4912 32.2849 42.29C31.2804 43.0887 29.9701 43.1775 28.922 42.5119L20.0561 36.7874L11.1902 42.5119C10.7098 42.8225 10.1857 43 9.66159 43H9.53057Z"
                      fill="#E61B73"
                    />
                  </svg>
                </div>
                <div className="border-t-2 border-verbus-green w-3/4 mx-auto mb-6"></div>
                <p className="text-base font-bold uppercase mb-4">
                  L'efficacité au service du collectif
                </p>
                <p className="text-base mb-6 leading-relaxed">
                  Pensée pour les trajets courts et les déplacements de
                  proximité, la Classe ACCESS privilégie la simplicité, la
                  fiabilité et la maîtrise du budget.
                </p>
                <ul className="text-sm uppercase space-y-2 mb-6">
                  <li>8 à 63 places</li>
                  <li>• solution accessible et fonctionnelle</li>
                  <li>• idéale pour navettes locales et sorties à proximité</li>
                </ul>
                <div className="flex gap-4 justify-center">
                  <Link
                    to="/classe-access"
                    className="px-6 py-3 rounded-full border border-verbus-dark text-verbus-dark font-normal text-base hover:bg-verbus-dark hover:text-white transition-colors"
                  >
                    personnaliser mon trajet
                  </Link>
                  <Link
                    to="/classe-access"
                    className="px-6 py-3 rounded-full border border-verbus-dark text-verbus-dark font-normal text-base hover:bg-verbus-dark hover:text-white transition-colors"
                  >
                    découvrir
                  </Link>
                </div>
              </div>
            </div>

            {/* Classe ECO */}
            <div className="flex flex-col">
              <div className="relative h-[336px] rounded-t-[40px] overflow-hidden">
                <img
                  src="https://api.builder.io/api/v1/image/assets/TEMP/fc5ec415b287fe481f4532aa04b27094446b2d72?width=1452"
                  alt="Classe ECO"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4 bg-verbus-pink text-white px-4 py-2 rounded-r-lg text-sm font-bold">
                  26 à 63 places
                  <br />
                  73 cm
                </div>
              </div>
              <div className="bg-white rounded-b-[40px] shadow-lg p-8 text-center">
                <h3 className="text-[40px] leading-tight mb-2">
                  <span className="text-verbus-green font-bold uppercase">
                    CLASSE
                  </span>
                  <br />
                  <span className="text-verbus-green font-bold text-[55px] uppercase">
                    ECO
                  </span>
                </h3>
                <div className="flex justify-center gap-1 mb-6">
                  <svg
                    width="40"
                    height="43"
                    viewBox="0 0 40 43"
                    fill="none"
                    className="w-8 h-8"
                  >
                    <path
                      d="M9.53057 43C8.87546 43 8.26402 42.7781 7.69625 42.3344C6.69174 41.5356 6.255 40.2043 6.51704 38.8731L8.61341 27.5573L1.01408 19.7472C0.0969229 18.8153 -0.208797 17.4396 0.140597 16.1527C0.533666 14.8215 1.4945 13.934 2.76105 13.8008L12.9372 12.5583L17.1736 2.04128C17.6977 0.798762 18.7458 0 20.0124 0C21.279 0 22.3271 0.798762 22.8512 2.04128L27.044 12.5583L37.2201 13.8008C38.443 13.934 39.4475 14.8658 39.8405 16.1527C40.2336 17.4396 39.8842 18.8153 38.967 19.7472L31.3677 27.5129L33.4641 38.8287C33.7261 40.16 33.2457 41.4912 32.2849 42.29C31.2804 43.0887 29.9701 43.1775 28.922 42.5119L20.0561 36.7874L11.1902 42.5119C10.7098 42.8225 10.1857 43 9.66159 43H9.53057Z"
                      fill="#E61B73"
                    />
                  </svg>
                  <svg
                    width="40"
                    height="43"
                    viewBox="0 0 40 43"
                    fill="none"
                    className="w-8 h-8"
                  >
                    <path
                      d="M9.53057 43C8.87546 43 8.26402 42.7781 7.69625 42.3344C6.69174 41.5356 6.255 40.2043 6.51704 38.8731L8.61341 27.5573L1.01408 19.7472C0.0969229 18.8153 -0.208797 17.4396 0.140597 16.1527C0.533666 14.8215 1.4945 13.934 2.76105 13.8008L12.9372 12.5583L17.1736 2.04128C17.6977 0.798762 18.7458 0 20.0124 0C21.279 0 22.3271 0.798762 22.8512 2.04128L27.044 12.5583L37.2201 13.8008C38.443 13.934 39.4475 14.8658 39.8405 16.1527C40.2336 17.4396 39.8842 18.8153 38.967 19.7472L31.3677 27.5129L33.4641 38.8287C33.7261 40.16 33.2457 41.4912 32.2849 42.29C31.2804 43.0887 29.9701 43.1775 28.922 42.5119L20.0561 36.7874L11.1902 42.5119C10.7098 42.8225 10.1857 43 9.66159 43H9.53057Z"
                      fill="#E61B73"
                    />
                  </svg>
                </div>
                <div className="border-t-2 border-verbus-green w-3/4 mx-auto mb-6"></div>
                <p className="text-base font-bold uppercase mb-4">
                  Responsable et bien pensée
                </p>
                <p className="text-base mb-6 leading-relaxed">
                  Pensée pour les trajets courts et les déplacements de
                  proximité, la Classe ECO privilégie la simplicité, la
                  fiabilité et la maîtrise du budget.
                </p>
                <ul className="text-sm uppercase space-y-2 mb-6">
                  <li>26 à 63 places</li>
                  <li>équipements essentiels pour les trajets longs</li>
                  <li>idéale pour groupes scolaires, clubs et séjours</li>
                </ul>
                <div className="flex gap-4 justify-center">
                  <Link
                    to="/classe-eco"
                    className="px-6 py-3 rounded-full border border-verbus-dark text-verbus-dark font-normal text-base hover:bg-verbus-dark hover:text-white transition-colors"
                  >
                    personnaliser mon trajet
                  </Link>
                  <Link
                    to="/classe-eco"
                    className="px-6 py-3 rounded-full border border-verbus-dark text-verbus-dark font-normal text-base hover:bg-verbus-dark hover:text-white transition-colors"
                  >
                    découvrir
                  </Link>
                </div>
              </div>
            </div>

            {/* Classe CONFORT */}
            <div className="flex flex-col">
              <div className="relative h-[336px] rounded-t-[40px] overflow-hidden">
                <img
                  src="https://api.builder.io/api/v1/image/assets/TEMP/aafcaf2aab1da1608f8d22b89e3da097785196d7?width=1452"
                  alt="Classe CONFORT"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 right-4 bg-verbus-pink text-white px-4 py-2 rounded-l-lg text-sm font-bold">
                  41 à 79 places
                  <br />
                  77 cm
                </div>
              </div>
              <div className="bg-white rounded-b-[40px] shadow-lg p-8 text-center">
                <h3 className="text-[40px] leading-tight mb-2">
                  <span className="text-verbus-green font-bold uppercase">
                    CLASSE
                  </span>
                  <br />
                  <span className="text-verbus-green font-bold text-[55px] uppercase">
                    CONFORT
                  </span>
                </h3>
                <div className="flex justify-center gap-1 mb-6">
                  {[...Array(3)].map((_, i) => (
                    <svg
                      key={i}
                      width="40"
                      height="43"
                      viewBox="0 0 40 43"
                      fill="none"
                      className="w-8 h-8"
                    >
                      <path
                        d="M9.53057 43C8.87546 43 8.26402 42.7781 7.69625 42.3344C6.69174 41.5356 6.255 40.2043 6.51704 38.8731L8.61341 27.5573L1.01408 19.7472C0.0969229 18.8153 -0.208797 17.4396 0.140597 16.1527C0.533666 14.8215 1.4945 13.934 2.76105 13.8008L12.9372 12.5583L17.1736 2.04128C17.6977 0.798762 18.7458 0 20.0124 0C21.279 0 22.3271 0.798762 22.8512 2.04128L27.044 12.5583L37.2201 13.8008C38.443 13.934 39.4475 14.8658 39.8405 16.1527C40.2336 17.4396 39.8842 18.8153 38.967 19.7472L31.3677 27.5129L33.4641 38.8287C33.7261 40.16 33.2457 41.4912 32.2849 42.29C31.2804 43.0887 29.9701 43.1775 28.922 42.5119L20.0561 36.7874L11.1902 42.5119C10.7098 42.8225 10.1857 43 9.66159 43H9.53057Z"
                        fill="#E61B73"
                      />
                    </svg>
                  ))}
                </div>
                <div className="border-t-2 border-verbus-green w-3/4 mx-auto mb-6"></div>
                <p className="text-base font-bold uppercase mb-4">
                  Une ambiance spacieuse, soignée et apaisante
                </p>
                <p className="text-base mb-6 leading-relaxed">
                  La Classe CONFORT est conçue pour les longs trajets et les
                  voyages organisés, avec un niveau de confort supérieur et une
                  expérience à bord pensée pour durer.
                </p>
                <ul className="text-sm uppercase space-y-2 mb-6">
                  <li>41 à 79 places</li>
                  <li>confort long trajet</li>
                  <li>idéale pour tourisme, séminaires et excursions</li>
                </ul>
                <div className="flex gap-4 justify-center">
                  <Link
                    to="/classe-confort"
                    className="px-6 py-3 rounded-full border border-verbus-dark text-verbus-dark font-normal text-base hover:bg-verbus-dark hover:text-white transition-colors"
                  >
                    personnaliser votre voyage
                  </Link>
                  <Link
                    to="/classe-confort"
                    className="px-6 py-3 rounded-full border border-verbus-dark text-verbus-dark font-normal text-base hover:bg-verbus-dark hover:text-white transition-colors"
                  >
                    découvrir
                  </Link>
                </div>
              </div>
            </div>

            {/* Classe STAR */}
            <div className="flex flex-col">
              <div className="relative h-[336px] rounded-t-[40px] overflow-hidden">
                <img
                  src="https://api.builder.io/api/v1/image/assets/TEMP/42968936cbf5442c1c0aef88a982bd6a17e75778?width=1452"
                  alt="Classe STAR"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4 bg-verbus-pink text-white px-4 py-2 rounded-r-lg text-sm font-bold">
                  48 places
                  <br />
                  78 cm
                </div>
              </div>
              <div className="bg-white rounded-b-[40px] shadow-lg p-8 text-center">
                <h3 className="text-[40px] leading-tight mb-2">
                  <span className="text-verbus-green font-bold uppercase">
                    CLASSE
                  </span>
                  <br />
                  <span className="text-verbus-green font-bold text-[55px] uppercase">
                    STAR
                  </span>
                </h3>
                <div className="flex justify-center gap-1 mb-6">
                  {[...Array(4)].map((_, i) => (
                    <svg
                      key={i}
                      width="40"
                      height="43"
                      viewBox="0 0 40 43"
                      fill="none"
                      className="w-8 h-8"
                    >
                      <path
                        d="M9.53057 43C8.87546 43 8.26402 42.7781 7.69625 42.3344C6.69174 41.5356 6.255 40.2043 6.51704 38.8731L8.61341 27.5573L1.01408 19.7472C0.0969229 18.8153 -0.208797 17.4396 0.140597 16.1527C0.533666 14.8215 1.4945 13.934 2.76105 13.8008L12.9372 12.5583L17.1736 2.04128C17.6977 0.798762 18.7458 0 20.0124 0C21.279 0 22.3271 0.798762 22.8512 2.04128L27.044 12.5583L37.2201 13.8008C38.443 13.934 39.4475 14.8658 39.8405 16.1527C40.2336 17.4396 39.8842 18.8153 38.967 19.7472L31.3677 27.5129L33.4641 38.8287C33.7261 40.16 33.2457 41.4912 32.2849 42.29C31.2804 43.0887 29.9701 43.1775 28.922 42.5119L20.0561 36.7874L11.1902 42.5119C10.7098 42.8225 10.1857 43 9.66159 43H9.53057Z"
                        fill="#E61B73"
                      />
                    </svg>
                  ))}
                </div>
                <div className="border-t-2 border-verbus-green w-3/4 mx-auto mb-6"></div>
                <p className="text-base font-bold uppercase mb-4">
                  Plus qu'un trajet... une expérience !
                </p>
                <p className="text-base mb-6 leading-relaxed">
                  Véhicule signature de VERBUS, la Classe STAR propose une
                  expérience premium, où l'espace, les équipements et l'ambiance
                  créent un véritable moment à part.
                </p>
                <ul className="text-sm uppercase space-y-2 mb-6">
                  <li>48 places</li>
                  <li>autocar 3 essieux</li>
                  <li>
                    idéale pour événements d'exception et voyages haut de gamme
                  </li>
                </ul>
                <div className="flex gap-4 justify-center">
                  <Link
                    to="/classe-star"
                    className="px-6 py-3 rounded-full border border-verbus-dark text-verbus-dark font-normal text-base hover:bg-verbus-dark hover:text-white transition-colors"
                  >
                    personnaliser votre voyage
                  </Link>
                  <Link
                    to="/classe-star"
                    className="px-6 py-3 rounded-full border border-verbus-dark text-verbus-dark font-normal text-base hover:bg-verbus-dark hover:text-white transition-colors"
                  >
                    découvrir
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* L'ADN Verbus Section */}
      <section className="py-20 bg-verbus-gray">
        <div className="max-w-[1920px] mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-4">
            l'ADN Verbus
          </h2>
          <p className="text-base font-bold text-center text-verbus-dark mb-16 max-w-2xl mx-auto">
            Ce qui fait la différence dans chacune de nos classes
          </p>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 text-center">
            <div>
              <div className="flex justify-center mb-4">
                <svg
                  width="65"
                  height="60"
                  viewBox="0 0 65 60"
                  fill="none"
                  className="w-16 h-16"
                >
                  <path
                    d="M32.5 0C14.55 0 0 13.43 0 30s14.55 30 32.5 30S65 46.57 65 30 50.45 0 32.5 0zm0 54c-14.34 0-26-11.19-26-25S18.16 4 32.5 4 58.5 15.19 58.5 29 46.84 54 32.5 54z"
                    fill="#51AD32"
                  />
                </svg>
              </div>
              <p className="text-base">
                Une flotte récente, entretenue, aux motorisations performantes
                et économes
              </p>
            </div>
            <div>
              <div className="flex justify-center mb-4">
                <svg
                  width="75"
                  height="95"
                  viewBox="0 0 75 95"
                  fill="none"
                  className="w-16 h-20"
                >
                  <path
                    d="M37.5 10C20.5 10 6.5 24 6.5 41s14 31 31 31 31-14 31-31-14-31-31-31z"
                    fill="#51AD32"
                  />
                </svg>
              </div>
              <p className="text-base">
                Des véhicules compatibles avec les biocarburants et le Mode Vert
              </p>
            </div>
            <div>
              <div className="flex justify-center mb-4">
                <svg
                  width="79"
                  height="95"
                  viewBox="0 0 79 95"
                  fill="none"
                  className="w-16 h-20"
                >
                  <path
                    d="M39.5 10C22.5 10 8.5 24 8.5 41s14 31 31 31 31-14 31-31-14-31-31-31z"
                    fill="#51AD32"
                  />
                </svg>
              </div>
              <p className="text-base">
                Des conducteurs professionnels, attentifs, engagés pour votre
                sécurité
              </p>
            </div>
            <div>
              <div className="flex justify-center mb-4">
                <svg
                  width="41"
                  height="95"
                  viewBox="0 0 41 95"
                  fill="none"
                  className="w-12 h-20"
                >
                  <path
                    d="M20.5 10C10.5 10 2.5 18 2.5 28v39c0 10 8 18 18 18s18-8 18-18V28c0-10-8-18-18-18z"
                    fill="#51AD32"
                  />
                </svg>
              </div>
              <p className="text-base">
                Des volumes de soute adaptés selon la classe
              </p>
            </div>
            <div>
              <div className="flex justify-center mb-4">
                <svg
                  width="75"
                  height="83"
                  viewBox="0 0 75 83"
                  fill="none"
                  className="w-16 h-18"
                >
                  <path
                    d="M37.5 5C20.5 5 6.5 19 6.5 36s14 31 31 31 31-14 31-31S54.5 5 37.5 5z"
                    fill="#51AD32"
                  />
                </svg>
              </div>
              <p className="text-base">Une équipe à votre écoute</p>
            </div>
          </div>
        </div>
      </section>

      {/* Comparison Table Section */}
      <section className="py-20 bg-white">
        <div className="max-w-[1920px] mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-4">
            4 classes, 4 façons de voyager
          </h2>
          <p className="text-base font-bold text-center text-verbus-dark mb-12 max-w-2xl mx-auto">
            Comparez les niveaux de confort, services et options pour choisir
            l'autocar le plus adapté.
          </p>

          {/* Comparison Table - Simplified for responsive */}
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-4 text-left">Capacité</th>
                  <th className="p-4 text-center text-verbus-green font-bold uppercase">
                    ACCESS
                  </th>
                  <th className="p-4 text-center text-verbus-green font-bold uppercase">
                    ÉCO
                  </th>
                  <th className="p-4 text-center text-verbus-green font-bold uppercase">
                    CONFORT
                  </th>
                  <th className="p-4 text-center text-verbus-green font-bold uppercase">
                    STAR
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="p-4 font-bold">places</td>
                  <td className="p-4 text-center">8 à 63</td>
                  <td className="p-4 text-center">26 à 63</td>
                  <td className="p-4 text-center">41 à 79</td>
                  <td className="p-4 text-center">48</td>
                </tr>
                <tr className="border-b bg-gray-50">
                  <td className="p-4 font-bold">Climatisation</td>
                  <td className="p-4 text-center">✓</td>
                  <td className="p-4 text-center">✓</td>
                  <td className="p-4 text-center">✓</td>
                  <td className="p-4 text-center">✓</td>
                </tr>
                <tr className="border-b">
                  <td className="p-4 font-bold">Prises USB</td>
                  <td className="p-4 text-center">
                    Présente selon le véhicule
                  </td>
                  <td className="p-4 text-center">✓</td>
                  <td className="p-4 text-center">✓</td>
                  <td className="p-4 text-center">✓</td>
                </tr>
                <tr className="border-b bg-gray-50">
                  <td className="p-4 font-bold">Soute à bagages</td>
                  <td className="p-4 text-center">Petite</td>
                  <td className="p-4 text-center">Moyenne</td>
                  <td className="p-4 text-center">Grande</td>
                  <td className="p-4 text-center">Très grande</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="flex flex-wrap justify-center gap-4 mt-12">
            <Link
              to="/classe-access"
              className="px-6 py-3 rounded-full border border-verbus-dark text-verbus-dark font-normal text-base uppercase hover:bg-verbus-dark hover:text-white transition-colors"
            >
              découvrir Access
            </Link>
            <Link
              to="/classe-eco"
              className="px-6 py-3 rounded-full border border-verbus-dark text-verbus-dark font-normal text-base uppercase hover:bg-verbus-dark hover:text-white transition-colors"
            >
              découvrir éco
            </Link>
            <Link
              to="/classe-confort"
              className="px-6 py-3 rounded-full border border-verbus-dark text-verbus-dark font-normal text-base uppercase hover:bg-verbus-dark hover:text-white transition-colors"
            >
              découvrir confort
            </Link>
            <Link
              to="/classe-star"
              className="px-6 py-3 rounded-full border border-verbus-dark text-verbus-dark font-normal text-base uppercase hover:bg-verbus-dark hover:text-white transition-colors"
            >
              découvrir star
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="max-w-[1920px] mx-auto px-8">
          <div className="relative bg-verbus-green rounded-[40px] overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
              <div className="order-2 lg:order-1">
                <img
                  src="https://api.builder.io/api/v1/image/assets/TEMP/7dec3abfa46584ce4697b3cd8a3792339d63e416?width=1040"
                  alt="Personnalisez votre trajet"
                  className="w-full h-full object-cover rounded-[40px]"
                />
              </div>
              <div className="order-1 lg:order-2 flex flex-col items-center justify-center p-12 text-center text-white">
                <p className="text-base font-bold uppercase mb-2">
                  voyage sur-mesure
                </p>
                <div className="w-24 h-px bg-black mb-8"></div>
                <h2 className="text-[40px] font-bold mb-6 leading-tight">
                  Prêt à choisir la classe
                  <br />
                  la plus adaptée à votre déplacement ?
                </h2>
                <p className="text-xl mb-8 max-w-lg">
                  En quelques questions, nous préparons avec vous un devis
                  adapté à votre projet, au nombre de voyageurs et à votre
                  budget.
                </p>
                <Link
                  to="/voyage-sur-mesure"
                  className="px-8 py-4 rounded-full bg-white text-verbus-green font-normal text-base hover:bg-white/90 transition-colors"
                >
                  personnaliser mon trajet
                </Link>
                <p className="text-sm italic mt-4">
                  Réponse garantie sous 24h • Sans engagement
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
