export default function ModeVert() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative h-[928px] overflow-hidden rounded-b-[40px]">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/074e0ee3d14a6415b1c4fbaea93825678806be62?width=4024"
            alt="Mode Vert"
            className="w-full h-full object-cover rounded-b-[40px]"
          />
        </div>

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#1E1E1E] via-[#1E1E1E]/80 to-transparent rounded-b-[40px]" />

        {/* Decorative SVG Elements */}
        <div className="absolute -left-20 top-[180px]">
          <svg
            width="378"
            height="375"
            viewBox="0 0 378 375"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M33.5002 249.634C18.8485 240.827 5.41913 229.58 -3.94123 215.145C-12.5537 201.867 -17.1052 186.493 -17.9255 170.742C-18.4482 160.795 -17.5717 150.824 -15.8186 141.038C-15.8186 141.006 -18.8985 140.901 -19.0272 141.584C-22.0267 158.338 -22.4046 175.775 -17.7566 192.273C-13.4383 207.583 -4.81776 221.214 6.5771 232.269C13.7502 239.229 21.8721 245.162 30.4283 250.308C30.8867 250.581 31.9482 250.26 32.4307 250.156C32.5754 250.124 33.7575 249.802 33.4922 249.65L33.5002 249.634Z"
              fill="#E72475"
            />
            <path
              d="M34.5534 249.722C39.9493 254.177 45.9081 257.854 52.47 260.343C59.8521 263.145 67.7811 264.317 75.6618 264.309C92.4365 264.293 109.388 261.78 125.552 257.389C139.849 253.511 153.689 248.06 166.74 241.051C178.087 234.95 188.847 227.765 198.689 219.448C206.747 212.632 214.274 205.11 220.699 196.72C221.383 195.829 222.05 194.922 222.709 194.007C223.908 192.345 221.125 191.173 220.128 192.562C214.282 200.694 207.35 208.056 199.88 214.719C190.744 222.868 180.692 229.997 170.094 236.114C157.742 243.235 144.554 248.919 130.931 253.11C115.612 257.822 99.6658 260.592 83.6631 261.419C75.4769 261.844 67.3147 261.74 59.3375 259.628C52.671 257.862 46.4629 254.836 40.858 250.838C39.5713 249.914 38.3249 248.943 37.1026 247.932C36.4673 247.402 35.5184 247.345 34.8349 247.843C34.272 248.253 33.9181 249.184 34.5615 249.714L34.5534 249.722Z"
              fill="#E72475"
            />
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M267.365 146.361C278.197 155.473 286.681 167.065 292.318 181.676L292.342 181.724C296.411 191.655 296.524 198.6 294.176 203.874C253.035 200.117 237.933 162.064 232.304 127.19C245.701 131.814 257.514 138.076 267.365 146.361ZM293.661 163.509C293.701 159.19 295.51 151.603 297.352 148.673C298.976 146.104 301.188 144.185 303.785 143.141C306.367 142.098 309.318 142.042 312.518 142.812C319.064 144.402 326.478 151.073 326.478 151.073C306.359 160.145 323.551 180.071 310.259 197.797C307.919 200.92 304.734 202.935 300.544 203.681C302.257 197.773 301.59 190.154 297.336 179.75C291.353 164.247 282.338 151.94 270.823 142.25C259.364 132.609 245.46 125.6 229.634 120.655L225.268 119.29L226.2 123.762C234.186 162.168 243.45 200.992 290.838 208.883C286.753 213.355 280.553 216.502 273.951 219.85C263.875 224.956 252.979 230.479 246.151 240.956C246.151 240.956 237.997 252.171 241.423 267.288C248.709 243.79 248.299 243.035 276.38 224.659C285.177 220.203 293.363 216.053 297.843 209.405C305.184 209.173 310.942 206.427 314.545 201.016C333.716 172.227 302.145 153.466 348.834 153.144L371.125 152.703L332.606 149.098C332.606 149.098 323.117 140.099 314.698 137.795C310.058 136.518 305.402 136.687 301.751 138.148C298.116 139.617 294.843 142.756 293.17 146.61C290.099 153.69 293.645 163.517 293.645 163.517L293.661 163.509Z"
              fill="#E72475"
            />
            <path
              d="M-75.5176 194.304C-69.6955 161.1 -41.7672 138.236 -13.1232 143.245C15.5207 148.247 26.2884 179.075 28.2023 212.423C29.0868 227.813 36.9917 338.561 151.543 305.148C151.543 305.148 169.613 299.03 185.254 302.884C213.97 309.948 223.692 363.151 223.692 363.151"
              stroke="#57AD32"
              strokeWidth="15.36"
              strokeMiterlimit="10"
              strokeLinecap="square"
            />
          </svg>
        </div>

        {/* Main Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-8 pt-[555px]">
          <h1 className="text-white text-[60px] font-bold leading-[63px] uppercase mb-8">
            MODE VERT
          </h1>
          <div className="w-[527px] h-[1px] bg-[#51AD32] mb-12"></div>
          <h2 className="text-white text-[40px] font-bold leading-[45px] max-w-[740px]">
            Conduire l'avenir
            <br />
            de manière responsable
          </h2>
        </div>
      </section>

      {/* Environmental Commitment Section */}
      <section className="py-24 bg-white relative">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Left - Image */}
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/be98ba390f0cb55afabefbfb5c05b3ee3a9bc691?width=2196"
                alt="Autocar VERBUS"
                className="w-full h-[734px] object-cover rounded-[40px]"
              />
            </div>

            {/* Right - Content with overlay */}
            <div className="relative">
              {/* Blurred green background */}
              <div className="absolute -right-8 -top-8 w-[830px] h-[468px] bg-[#51AD32] rounded-[40px] blur-sm opacity-90 -z-10"></div>

              <div className="bg-[#51AD32] rounded-[40px] p-12 relative">
                <h2 className="text-white text-center text-[35px] font-bold leading-[40px] mb-12">
                  Notre engagement environnemental n'est pas qu'une promesse :
                  <br />
                  c'est une réalité mesurable qui transforme la mobilité
                  collective.
                </h2>

                <div className="text-center">
                  <button className="bg-white text-[#51AD32] px-12 py-4 rounded-full text-base hover:bg-gray-50 transition-colors">
                    demander un devis mode vert
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* What is Mode Vert Section */}
      <section className="py-24 bg-[#FAFAFC]">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Left Column */}
            <div>
              <div className="mb-8">
                <p className="text-[#51AD32] text-[25px] font-normal uppercase mb-4">
                  notre engagement
                </p>
                <h2 className="text-[#1E1E1E] text-[40px] font-bold leading-[40px] mb-8">
                  Qu'est-ce que
                  <br />
                  le Mode Vert ?
                </h2>
              </div>

              <div className="relative">
                {/* Decorative SVG */}
                <div className="absolute -left-12 top-12">
                  <svg
                    width="503"
                    height="318"
                    viewBox="0 0 503 318"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M106.291 26.8813C103.927 26.8468 101.424 10.9028 104.751 6.77697C106.832 4.19502 108.564 5.34844 109.566 6.71314C109.756 6.96826 110.553 8.34343 110.359 11.0876C109.943 17.0793 107.909 26.9009 106.291 26.8743L106.291 26.8813Z"
                      fill="#E72475"
                    />
                    <path
                      d="M153.709 64.9927C156.662 64.9725 161.594 68.1431 160.217 70.1464C158.841 72.1496 134.323 68.3214 135.583 66.28C136.843 64.2457 150.749 65.0123 153.709 64.9927Z"
                      fill="#E72475"
                    />
                    <path
                      d="M146.861 27.3191C141.092 31.8391 130.14 37.2555 129.51 35.7262C128.881 34.1968 135.981 27.7961 139.235 24.8373C142.49 21.8785 146.168 20.7053 149.305 21.3262C152.449 21.9546 148.929 25.6985 146.868 27.3197L146.861 27.3191Z"
                      fill="#E72475"
                    />
                    <path
                      d="M79.0127 34.2806C77.6305 36.0235 68.4203 30.9256 64.5092 27.2666C62.6841 25.5573 60.8108 23.5909 59.9713 21.3129C59.108 18.9837 65.1143 18.0949 67.0735 19.7174C69.6708 21.8655 80.3956 32.5308 79.0127 34.2806Z"
                      fill="#E72475"
                    />
                    <path
                      d="M48.5598 56.005C56.2195 55.462 64.7139 57.7446 64.8729 59.2545C65.19 62.3658 42.5133 63.5078 41.3324 60.6947C40.3491 58.3692 45.7752 56.2012 48.5668 56.0056L48.5598 56.005Z"
                      fill="#E72475"
                    />
                    <path
                      d="M89.6566 23.3515C88.3563 23.2398 86.5942 19.323 85.1653 16.2005C83.7363 13.078 82.0636 6.64693 84.6471 6.25076C87.2305 5.8546 88.6067 11.066 89.255 14.0932C89.9033 17.1205 90.9511 23.4488 89.6572 23.3446L89.6566 23.3515Z"
                      fill="#E72475"
                    />
                    <path
                      d="M49.839 39.3321C50.1844 36.7064 56.2797 38.305 57.5499 38.8498C61.0408 40.351 67.5977 44.3638 66.8618 45.3052C66.1259 46.2465 49.4942 41.9509 49.839 39.3321Z"
                      fill="#E72475"
                    />
                    <path
                      d="M116.72 27.5599C115.89 25.5005 118.371 14.7407 121.455 11.8866C125.341 8.29368 126.11 13.3546 125.512 14.6659C122.852 20.5351 117.37 29.1753 116.721 27.5529L116.72 27.5599Z"
                      fill="#E72475"
                    />
                    <path
                      d="M145.767 47.9138C148.619 46.9435 151.614 46.5055 154.596 46.0662C155.352 45.9556 156.211 45.8679 156.81 46.3549C157.863 47.2181 157.121 48.9668 156.074 49.8393C154.246 51.3611 151.817 51.9321 149.473 52.3208C146.437 52.8256 138.614 53.8744 138.263 52.7132C137.912 51.552 142.924 48.8777 145.774 47.9144L145.767 47.9138Z"
                      fill="#E72475"
                    />
                    <path
                      d="M84.9756 33.9852C90.8986 30.1317 98.6688 29.2049 105.563 30.7738C109.375 31.6424 113.142 32.8864 116.45 34.962C125.711 40.7738 129.938 52.1452 131.126 62.9955C131.339 64.9387 131.469 68.0127 130.641 68.9602C129.352 70.4371 124.053 69.1667 124.224 66.1958C124.447 62.4496 124.517 58.6832 123.783 55.0163C122.46 48.4536 118.395 42.4001 112.584 39.0485C106.773 35.697 95.3652 34.7025 89.4822 37.9271C79.5271 43.38 77.3979 56.1089 75.1267 64.8354C74.8015 66.079 73.4601 65.3806 71.7249 64.5922C69.942 63.7857 70.4564 62.8815 70.5688 61.9006C71.091 57.4636 72.4447 53.2666 73.8923 49.0426C76.0195 42.8116 79.4477 37.5846 84.9687 33.9846L84.9756 33.9852Z"
                      fill="#E72475"
                    />
                    <path
                      d="M493.922 135.582C482.72 142.761 471.574 150.022 460.391 157.231C449.207 164.44 437.322 172.031 425.654 179.227C413.985 186.422 402.369 193.341 390.476 199.962C378.582 206.583 367.407 212.387 355.504 217.883C344.445 222.989 333.153 227.61 321.562 231.37C310.442 234.973 299.031 237.617 287.552 239.82C275.357 242.165 263.041 243.952 250.676 245.158C238.311 246.365 225.677 247.014 213.149 246.928C201.261 246.847 189.359 246.105 177.602 244.336C167.034 242.747 156.512 240.374 146.525 236.53C144.241 235.653 141.978 234.699 139.757 233.658C139.08 233.34 138.45 232.401 138.851 231.663C139.286 230.864 140.349 231.033 141.026 231.344C150.08 235.564 159.954 238.345 169.813 240.239C181.169 242.416 192.731 243.494 204.274 243.903C216.583 244.336 228.91 243.983 241.188 243.043C253.467 242.103 265.917 240.553 278.161 238.465C289.633 236.501 301.116 234.172 312.308 230.954C323.71 227.676 334.833 223.469 345.704 218.741C357.476 213.627 368.969 207.892 380.266 201.817C392.088 195.457 403.703 188.713 415.189 181.762C426.674 174.811 438.313 167.466 449.754 160.132C460.941 152.965 472.071 145.716 483.24 138.513C485.917 136.783 488.6 135.061 491.284 133.339C492.029 132.862 492.948 132.99 493.617 133.56C494.096 133.967 494.662 135.083 493.916 135.567L493.923 135.568L493.922 135.582Z"
                      fill="#E72475"
                    />
                    <mask
                      id="mask0_148_2864"
                      style={{ maskType: "luminance" }}
                      maskUnits="userSpaceOnUse"
                      x="0"
                      y="40"
                      width="467"
                      height="275"
                    >
                      <path
                        d="M0.00105858 276.147L442.788 314.202L466.35 40.0542L92.2306 62.1129L88.7008 60.3273L50.535 62.8077L0.00105858 276.147Z"
                        fill="white"
                      />
                    </mask>
                    <g mask="url(#mask0_148_2864)">
                      <path
                        d="M149.792 237.114C106.463 222.396 79.7945 199.352 65.2583 171.085C48.8996 139.275 48.5006 106.223 88.7009 60.3205C90.0751 61.949 90.9828 61.0575 92.2417 63.6174C93.572 66.331 99.1723 67.7888 101.235 68.8653C105.239 70.9516 108.391 71.637 108.391 71.637C77.2707 101.621 80.9088 135.745 94.316 157.073C108.683 179.931 122.819 191.227 160.074 203.526C245.389 231.708 340.895 185.796 390.529 148.136C422.714 123.716 448.108 97.6721 470.799 69.3165C478.272 59.9762 494.267 81.344 486.828 90.6309C463.135 120.228 434.258 148.031 400.254 173.3C369.567 196.107 333.847 217.898 289.084 231.508C243.691 245.31 194.121 252.163 149.786 237.106L149.792 237.114Z"
                        fill="#52AE32"
                      />
                    </g>
                  </svg>
                </div>

                <p className="text-[#1E1E1E] text-base font-medium leading-relaxed">
                  Le Mode Vert est notre programme global de transition
                  écologique. Il englobe le renouvellement de notre flotte vers
                  des motorisations propres, l'optimisation de nos pratiques
                  opérationnelles et la sensibilisation de nos équipes et
                  clients aux enjeux environnementaux.
                  <br />
                  <br />
                  Concrètement, cela signifie que lorsque vous voyagez avec
                  Verbus en Mode Vert, vous réduisez votre empreinte carbone de
                  30% en moyenne par rapport à un transport classique.
                </p>
              </div>
            </div>

            {/* Right Column */}
            <div>
              <h2 className="text-[#1E1E1E] text-[40px] font-bold leading-[40px] mb-12">
                Nos actions
                <br />
                concrètes
              </h2>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-1 flex-shrink-0"
                  >
                    <path
                      d="M0.751953 5.64014L4.25195 9.64014L11.752 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <div>
                    <h3 className="text-[#1E1E1E] text-[25px] font-normal mb-2">
                      Réduction CO₂ jusqu'à -30%
                    </h3>
                    <p className="text-[#1E1E1E] text-base font-normal">
                      Grâce à notre flotte hybride et électrique en constante
                      expansion
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-1 flex-shrink-0"
                  >
                    <path
                      d="M0.751953 5.64014L4.25195 9.64014L11.752 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <div>
                    <h3 className="text-[#1E1E1E] text-[25px] font-normal mb-2">
                      Véhicules électriques
                    </h3>
                    <p className="text-[#1E1E1E] text-base font-normal">
                      50 nouveaux autocars 100% électriques d'ici fin 2025
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-1 flex-shrink-0"
                  >
                    <path
                      d="M0.751953 5.64014L4.25195 9.64014L11.752 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <div>
                    <h3 className="text-[#1E1E1E] text-[25px] font-normal mb-2">
                      Conduite éco-responsable
                    </h3>
                    <p className="text-[#1E1E1E] text-base font-normal">
                      Formation de nos chauffeurs aux techniques d'éco-conduite
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-1 flex-shrink-0"
                  >
                    <path
                      d="M0.751953 5.64014L4.25195 9.64014L11.752 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <div>
                    <h3 className="text-[#1E1E1E] text-[25px] font-normal mb-2">
                      Suivi en temps réel
                    </h3>
                    <p className="text-[#1E1E1E] text-base font-normal">
                      Monitoring des émissions et optimisation continue des
                      trajets
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Image Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/863648a61f18bca94bccbe03f6d69a4346585c10?width=1636"
              alt="Engagement environnemental VERBUS"
              className="w-full h-[468px] object-cover rounded-[40px]"
            />
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/e59ceac7950fccd5e97d8453b38158b9fd8583a0?width=988"
              alt="Autocar écologique VERBUS"
              className="w-full h-[741px] object-cover rounded-[40px]"
            />
          </div>
        </div>
      </section>

      {/* Roadmap Section */}
      <section className="py-24 bg-[#1E1E1E] relative">
        <div className="max-w-7xl mx-auto px-8">
          {/* Decorative SVG */}
          <div className="flex justify-center mb-12">
            <svg
              width="126"
              height="129"
              viewBox="0 0 126 129"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M36.3556 23.3989C45.7146 31.2754 53.0342 41.3122 57.914 53.9462L57.9383 53.9947C61.4464 62.5873 61.5435 68.5948 59.5284 73.1459C23.9983 69.8934 10.9492 36.9795 6.08153 6.80851C17.6498 10.8135 27.8584 16.2263 36.3677 23.3989M59.0672 38.2296C59.1036 34.4916 60.6573 27.9258 62.2597 25.4014C63.6556 23.1805 65.5735 21.5178 67.8192 20.6197C70.0527 19.7216 72.6019 19.6731 75.3574 20.3406C81.014 21.712 87.4112 27.4889 87.4112 27.4889C70.0406 35.3411 84.8741 52.5748 73.403 67.903C71.388 70.5973 68.6325 72.3449 65.0151 72.9881C66.4961 67.8787 65.9134 61.2887 62.2475 52.2835C57.0764 38.8728 49.2955 28.2292 39.3538 19.8551C29.4608 11.5174 17.4434 5.44923 3.77517 1.17723L0 0L0.801162 3.87151C7.69597 37.0888 15.6954 70.6822 56.6394 77.5029C53.1192 81.3744 47.7539 84.0929 42.0486 86.9814C33.3452 91.399 23.9376 96.1807 18.0382 105.234C18.0382 105.234 10.9977 114.931 13.9596 128.014C20.2474 107.686 19.8954 107.043 44.1608 91.1441C51.7596 87.2848 58.8244 83.7046 62.6966 77.9519C69.0452 77.7456 74.01 75.3669 77.1175 70.6944C93.6747 45.7905 66.4111 29.5642 106.736 29.2851L125.988 28.9088L92.7158 25.7898C92.7158 25.7898 84.5221 18.0104 77.251 16.0079C73.2452 14.9035 69.2151 15.0491 66.0712 16.3113C62.9273 17.5735 60.099 20.292 58.6545 23.6295C55.9961 29.7584 59.0672 38.2538 59.0672 38.2538V38.2296Z"
                fill="#E71D74"
              />
            </svg>
          </div>

          <h2 className="text-white text-center text-[40px] font-bold leading-[40px] mb-16">
            Feuille de route 2025-2030
          </h2>

          {/* Timeline */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {/* 2025 */}
            <div>
              <h3 className="text-[#51AD32] text-center text-[40px] font-bold mb-4">
                2025
              </h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="h-[42px] bg-[#51AD32] rounded-full flex-1"></div>
                  <div className="h-[42px] bg-[#F5F5F5] rounded-full w-20"></div>
                </div>
                <p className="text-center text-[#1E1E1E] text-base font-bold bg-[#F5F5F5] rounded-lg py-2">
                  65%
                </p>
              </div>
              <div className="mt-4">
                <p className="text-[#51AD32] text-lg font-bold">En cours</p>
                <p className="text-white text-lg font-bold">
                  40% de flotte bas carbone
                </p>
              </div>
            </div>

            {/* 2027 */}
            <div>
              <h3 className="text-[#51AD32] text-center text-[40px] font-bold mb-4">
                2027
              </h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="h-[42px] bg-[#51AD32] rounded-full w-[141px]"></div>
                  <div className="h-[42px] bg-[#F5F5F5] rounded-full flex-1"></div>
                </div>
                <p className="text-center text-[#1E1E1E] text-base font-bold bg-[#F5F5F5] rounded-lg py-2">
                  35%
                </p>
              </div>
              <div className="mt-4">
                <p className="text-[#51AD32] text-lg font-bold">Planifié</p>
                <p className="text-white text-lg font-bold">
                  70% de flotte bas carbone
                </p>
              </div>
            </div>

            {/* 2030 */}
            <div>
              <h3 className="text-[#51AD32] text-center text-[40px] font-bold mb-4">
                2030
              </h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="h-[42px] bg-[#51AD32] rounded-full w-[71px]"></div>
                  <div className="h-[42px] bg-[#F5F5F5] rounded-full flex-1"></div>
                </div>
                <p className="text-center text-[#1E1E1E] text-base font-bold bg-[#F5F5F5] rounded-lg py-2">
                  10%
                </p>
              </div>
              <div className="mt-4">
                <p className="text-[#51AD32] text-lg font-bold">Objectif</p>
                <p className="text-white text-lg font-bold">
                  100% de flotte bas carbone
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Daily Commitments Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Left - Image */}
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/fa047caa7148546133d881543099e4171f70ebae?width=2196"
              alt="Nos engagements quotidiens"
              className="w-full h-[734px] object-cover rounded-[40px]"
            />

            {/* Right - Content */}
            <div>
              <h2 className="text-[#1E1E1E] text-[40px] font-bold leading-[40px] mb-12">
                Nos engagements
                <br />
                quotidiens
              </h2>

              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-2 flex-shrink-0"
                  >
                    <path
                      d="M0.751953 5.64014L4.25195 9.64014L11.752 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <p className="text-[#1E1E1E] text-[25px] font-normal">
                    Renouvellement accéléré de la flotte vers l'électrique et
                    l'hybride
                  </p>
                </div>

                <div className="flex items-start gap-4">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-2 flex-shrink-0"
                  >
                    <path
                      d="M0.751953 5.64014L4.25195 9.64014L11.752 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <p className="text-[#1E1E1E] text-[25px] font-normal">
                    Optimisation des trajets pour réduire les kilomètres
                    parcourus
                  </p>
                </div>

                <div className="flex items-start gap-4">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-2 flex-shrink-0"
                  >
                    <path
                      d="M0.751953 5.64014L4.25195 9.64014L11.752 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <p className="text-[#1E1E1E] text-[25px] font-normal">
                    Sensibilisation des passagers aux gestes éco-responsables
                  </p>
                </div>

                <div className="flex items-start gap-4">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-2 flex-shrink-0"
                  >
                    <path
                      d="M0.751953 5.64014L4.25195 9.64014L11.752 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <p className="text-[#1E1E1E] text-[25px] font-normal">
                    Partenariat avec des fournisseurs d'énergie verte
                  </p>
                </div>

                <div className="flex items-start gap-4">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-2 flex-shrink-0"
                  >
                    <path
                      d="M0.751953 5.64014L4.25195 9.64014L11.752 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <p className="text-[#1E1E1E] text-[25px] font-normal">
                    Recyclage et valorisation des déchets (pneus, batteries,
                    huiles)
                  </p>
                </div>

                <div className="flex items-start gap-4">
                  <svg
                    width="13"
                    height="12"
                    viewBox="0 0 13 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="mt-2 flex-shrink-0"
                  >
                    <path
                      d="M0.751953 5.64014L4.25195 9.64014L11.752 0.640137"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                  <p className="text-[#1E1E1E] text-[25px] font-normal">
                    Compensation carbone pour les trajets restants
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section - Prêt pour vos déplacements */}
      <section className="py-24 relative">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex items-stretch gap-0">
            {/* Left - Image */}
            <div className="w-[350px] flex-shrink-0">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/02ad66be908d49d76636739feca12a8a54c09030?width=700"
                alt="Prêt pour vos déplacements"
                className="w-full h-full object-cover rounded-l-[40px]"
              />
            </div>

            {/* Right - Content */}
            <div className="flex-1 bg-[#51AD32] rounded-r-[40px] px-16 py-12 flex flex-col justify-center">
              <div className="text-center uppercase text-[#1E1E1E] text-base font-extrabold mb-4">
                voyage sur-mesure
              </div>
              <div className="w-[185px] h-[1px] bg-black mx-auto mb-12"></div>

              <h2 className="text-white text-[40px] font-bold text-center leading-tight mb-8">
                Prêt à créer votre
                <br />
                voyage idéal ?
              </h2>

              <p className="text-white text-xl text-center mb-12 max-w-[530px] mx-auto">
                En quelques questions, nous préparons avec vous un devis adapté
                à votre projet, au nombre de voyageurs et à votre budget.
              </p>

              <div className="text-center">
                <button className="bg-white text-[#51AD32] px-12 py-4 rounded-full text-base hover:bg-gray-50 transition-colors mb-4">
                  personnaliser mon trajet
                </button>
                <p className="text-white text-sm italic">
                  Réponse garantie sous 24h • Sans engagement
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
