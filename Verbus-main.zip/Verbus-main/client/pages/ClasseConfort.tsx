import Layout from "@/components/Layout";
import { Link } from "react-router-dom";

export default function ClasseConfort() {
  return (
    <Layout>
      {/* Breadcrumb */}
      <div className="bg-white py-6 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex items-center gap-2 text-base italic text-verbus-dark">
            <Link
              to="/vehicules"
              className="hover:text-verbus-green transition-colors"
            >
              Nos véhicules
            </Link>
            <span className="mx-2">|</span>
            <span>Classe confort</span>
          </div>
          <div className="w-[206px] h-px bg-white mt-2"></div>
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 items-stretch">
            {/* Left Content - Black Background */}
            <div className="relative bg-black px-8 lg:px-16 py-16 lg:py-24 flex flex-col justify-center min-h-[600px]">
              {/* Decorative SVG - Pink Curve */}
              <div className="absolute -left-60 top-4">
                <svg
                  width="407"
                  height="359"
                  viewBox="0 0 82 359"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M77.3474 168.141C75.2361 162.938 72.9077 157.805 70.3623 152.762C67.6327 147.345 64.6531 142.03 61.4434 136.832C58.0429 131.327 54.3727 125.952 50.4592 120.725C46.3681 115.261 41.9942 109.969 37.3572 104.872C32.4439 99.4675 27.2281 94.2879 21.7491 89.345C16.2702 84.4021 10.0809 79.3586 3.83244 74.7946C-2.78436 69.9583 -9.684 65.4357 -16.8467 61.2742C-24.4501 56.8463 -32.3298 52.8032 -40.4331 49.1568C-49.0099 45.2972 -57.8367 41.8756 -66.828 38.8922C-76.4572 35.6956 -86.2837 32.9962 -96.2418 30.7527C-98.7938 30.1785 -101.352 29.6339 -103.924 29.1189C-104.404 29.0242 -105.148 29.0538 -104.904 29.6576C-104.661 30.2614 -103.648 30.6817 -103.036 30.806C-93.0124 32.8186 -83.0937 35.2753 -73.3724 38.2469C-64.3483 40.9995 -55.4755 44.1784 -46.8394 47.813C-38.7559 51.2168 -30.863 55.0053 -23.2531 59.1964C-15.6431 63.3875 -8.99995 67.5253 -2.28448 72.2018C4.0495 76.606 10.1138 81.3239 15.8953 86.3023C21.4137 91.0558 26.6624 96.0578 31.6283 101.285C36.3969 106.305 40.8958 111.526 45.1184 116.919C49.1174 122.027 52.8665 127.296 56.3525 132.706C59.8385 138.117 62.7589 143.125 65.6003 148.494C68.2707 153.537 70.724 158.67 72.9538 163.885C73.4734 165.098 73.9798 166.312 74.4731 167.537C74.7165 168.141 75.7031 168.555 76.3411 168.686C76.8212 168.786 77.5711 168.762 77.3211 168.147L77.3474 168.141Z"
                    fill="#E71D74"
                  />
                  <path
                    d="M-154.491 352.697C-104.937 365.649 -51.154 357.716 -6.67798 335.044C15.606 323.685 35.3512 307.572 49.8871 288.575C67.4618 265.607 77.5712 238.59 80.6362 210.928C83.425 185.764 77.4397 160.357 63.1471 138.561C49.578 117.866 29.1949 101.605 7.42383 88.1079C-11.6965 76.2569 -32.494 66.4777 -53.6073 57.8409C-73.8655 49.5594 -94.5052 42.373 -115.836 36.6428C-138.093 30.664 -160.752 25.9816 -183.477 21.6721C-214.963 15.6993 -246.587 10.3302 -278.191 4.87821C-287.142 3.33319 -296.094 1.78817 -305.046 0.237232C-314.465 -1.39658 -326.534 5.61816 -325.982 14.8291C-325.712 19.2747 -323.64 23.6374 -319.911 26.6505C-315.478 30.226 -310.591 31.7414 -304.789 32.7537C-271.107 38.6022 -237.378 44.2377 -203.762 50.3822C-203.163 50.4947 -202.558 50.6013 -201.959 50.7137C-198.184 51.4063 -207.747 49.6423 -203.992 50.3408C-202.236 50.6664 -200.486 50.992 -198.73 51.3175C-195.323 51.9569 -191.916 52.6021 -188.515 53.2592C-182.333 54.4549 -176.15 55.6862 -169.987 56.9648C-158.477 59.3564 -147.012 61.9196 -135.64 64.7965C-115.132 69.9761 -94.9722 76.2391 -75.4441 83.9109C-74.1813 84.4082 -72.925 84.9113 -71.6621 85.4145C-70.1625 86.0124 -68.0117 86.9299 -74.9771 84.0648C-74.3457 84.3253 -73.7143 84.5798 -73.0828 84.8462C-70.5308 85.8999 -67.992 86.9773 -65.4597 88.0724C-60.1255 90.381 -54.8373 92.7844 -49.6017 95.2588C-38.5452 100.48 -27.686 106.062 -17.2938 112.295C-14.3866 114.036 -11.5189 115.835 -8.69064 117.682C-8.03949 118.108 -7.3949 118.535 -6.75034 118.967C-2.896 121.554 -10.5192 116.327 -7.8685 118.191C-6.61221 119.073 -5.35593 119.961 -4.11938 120.867C1.18195 124.738 6.25964 128.864 11.015 133.275C13.3632 135.453 15.606 137.714 17.8029 140.017C19.9997 142.32 14.4287 136.222 16.5137 138.59C17.1517 139.318 17.7963 140.047 18.4277 140.781C19.3683 141.888 20.2891 143.006 21.1836 144.137C25.2287 149.263 28.7542 154.698 31.7271 160.386L29.6552 156.379C33.9568 164.761 36.9166 173.587 38.5346 182.703L37.7914 178.471C39.8304 190.505 39.5081 202.676 37.5152 214.699L38.2452 210.443C35.417 226.846 29.9183 242.894 21.519 257.687L23.7027 253.851C16.4545 266.436 7.17389 277.938 -3.87604 288.037L-0.515015 285C-11.315 294.773 -23.6015 303.073 -36.9535 309.815L-32.6651 307.66C-40.354 311.502 -48.3455 314.835 -56.5869 317.605C-60.7174 318.996 -64.9006 320.245 -69.1364 321.352C-70.1296 321.613 -71.1228 321.855 -72.116 322.11C-74.2865 322.661 -67.1961 320.973 -69.3798 321.465C-69.8797 321.577 -70.373 321.696 -70.8728 321.808C-72.9842 322.282 -75.1087 322.72 -77.2397 323.128C-85.5074 324.697 -93.9001 325.739 -102.339 326.218C-103.332 326.277 -104.325 326.325 -105.312 326.366C-106.239 326.402 -110.39 326.508 -105.943 326.414C-101.497 326.319 -105.634 326.396 -106.562 326.402C-107.667 326.402 -108.765 326.402 -109.87 326.39C-113.987 326.337 -118.111 326.141 -122.209 325.804C-126.701 325.431 -131.174 324.88 -135.607 324.14C-136.067 324.064 -136.528 323.981 -136.988 323.904C-139.988 323.395 -131.404 324.975 -133.785 324.49C-134.805 324.283 -135.824 324.087 -136.844 323.868C-139.08 323.389 -141.303 322.856 -143.513 322.276C-148.643 320.932 -154.451 320.695 -159.496 322.548C-163.646 324.069 -168.125 327.503 -169.323 331.576C-172.092 340.976 -164.442 350.116 -154.464 352.726L-154.491 352.697Z"
                    fill="#55AD32"
                  />
                </svg>
              </div>

              {/* Black Triangle on Left Edge */}
              <div className="absolute left-0 top-0 bottom-0 w-32 lg:w-48">
                <svg
                  viewBox="0 0 114 850"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-full w-full"
                  preserveAspectRatio="none"
                >
                  <path
                    d="M114.001 424.5L0.380536 0.000323736L9.45882e-05 849.381L114.001 424.5Z"
                    fill="black"
                  />
                </svg>
              </div>

              {/* Decorative Stars */}
              <div className="absolute right-8 top-12 flex gap-2">
                <svg
                  width="40"
                  height="43"
                  viewBox="0 0 42 45"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M21.0125 0.5C22.5147 0.500124 23.7235 1.45364 24.3113 2.84668L24.3152 2.85645L28.3982 13.0967L38.2732 14.3037C39.7292 14.4622 40.8774 15.5639 41.3181 17.0068C41.7648 18.4692 41.3676 20.0335 40.323 21.0957L40.324 21.0967L32.906 28.6758L34.9548 39.7324L34.9998 40.0146C35.1803 41.4245 34.6414 42.8126 33.6042 43.6748L33.5955 43.6816C32.4329 44.6059 30.8911 44.7191 29.6541 43.9336L29.6501 43.9316L21.0554 38.3818L12.4607 43.9307L12.4617 43.9316C11.9166 44.2841 11.299 44.5 10.6609 44.5H10.53C9.75227 44.4999 9.03463 44.2335 8.38843 43.7285L8.38452 43.7256C7.2177 42.7976 6.73218 41.2697 7.02612 39.7764L9.07397 28.7207L1.65503 21.0957V21.0947C0.603082 20.0237 0.267091 18.4611 0.657959 17.0215L0.660889 17.0107C1.10088 15.521 2.20485 14.4654 3.69995 14.3047L13.5828 13.0967L17.7097 2.85449L17.7126 2.84668C18.3004 1.45347 19.51 0.5 21.0125 0.5Z"
                    fill="#E71D73"
                    stroke="#E72475"
                  />
                </svg>
                <svg
                  width="40"
                  height="43"
                  viewBox="0 0 42 45"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M21.0125 0.5C22.5147 0.500124 23.7235 1.45364 24.3113 2.84668L24.3152 2.85645L28.3982 13.0967L38.2732 14.3037C39.7292 14.4622 40.8774 15.5639 41.3181 17.0068C41.7648 18.4692 41.3676 20.0335 40.323 21.0957L40.324 21.0967L32.906 28.6758L34.9548 39.7324L34.9998 40.0146C35.1803 41.4245 34.6414 42.8126 33.6042 43.6748L33.5955 43.6816C32.4329 44.6059 30.8911 44.7191 29.6541 43.9336L29.6501 43.9316L21.0554 38.3818L12.4607 43.9307L12.4617 43.9316C11.9166 44.2841 11.299 44.5 10.6609 44.5H10.53C9.75227 44.4999 9.03463 44.2335 8.38843 43.7285L8.38452 43.7256C7.2177 42.7976 6.73218 41.2697 7.02612 39.7764L9.07397 28.7207L1.65503 21.0957V21.0947C0.603082 20.0237 0.267091 18.4611 0.657959 17.0215L0.660889 17.0107C1.10088 15.521 2.20485 14.4654 3.69995 14.3047L13.5828 13.0967L17.7097 2.85449L17.7126 2.84668C18.3004 1.45347 19.51 0.5 21.0125 0.5Z"
                    fill="#E71D73"
                    stroke="#E72475"
                  />
                </svg>
                <svg
                  width="40"
                  height="43"
                  viewBox="0 0 42 45"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M21.0125 0.5C22.5147 0.500124 23.7235 1.45364 24.3113 2.84668L24.3152 2.85645L28.3982 13.0967L38.2732 14.3037C39.7292 14.4622 40.8774 15.5639 41.3181 17.0068C41.7648 18.4692 41.3676 20.0335 40.323 21.0957L40.324 21.0967L32.906 28.6758L34.9548 39.7324L34.9998 40.0146C35.1803 41.4245 34.6414 42.8126 33.6042 43.6748L33.5955 43.6816C32.4329 44.6059 30.8911 44.7191 29.6541 43.9336L29.6501 43.9316L21.0554 38.3818L12.4607 43.9307L12.4617 43.9316C11.9166 44.2841 11.299 44.5 10.6609 44.5H10.53C9.75227 44.4999 9.03463 44.2335 8.38843 43.7285L8.38452 43.7256C7.2177 42.7976 6.73218 41.2697 7.02612 39.7764L9.07397 28.7207L1.65503 21.0957V21.0947C0.603082 20.0237 0.267091 18.4611 0.657959 17.0215L0.660889 17.0107C1.10088 15.521 2.20485 14.4654 3.69995 14.3047L13.5828 13.0967L17.7097 2.85449L17.7126 2.84668C18.3004 1.45347 19.51 0.5 21.0125 0.5Z"
                    fill="#E71D73"
                    stroke="#E72475"
                  />
                </svg>
              </div>

              {/* Pink Parenthesis */}
              <div className="absolute left-12 bottom-1/4 text-[100px] font-light text-verbus-pink leading-none">
                (
              </div>

              {/* Content */}
              <div className="relative z-10 max-w-md space-y-6">
                <h1 className="text-[40px] lg:text-[60px] font-bold text-verbus-green uppercase leading-tight">
                  Classe
                  <br />
                  <span className="text-[50px] lg:text-[70px]">CONFORT</span>
                </h1>

                <p className="text-white text-base font-bold uppercase">
                  Une ambiance spacieuse, soignée et apaisante
                </p>

                <div className="space-y-1 text-verbus-pink text-sm font-semibold uppercase">
                  <p>CAPACITÉ : 41 à 79 places</p>
                  <p>écartement de sièges : 77 cm</p>
                </div>

                <p className="text-verbus-green text-sm font-semibold uppercase">
                  GRAND TOURISME
                </p>

                <p className="text-white text-base leading-relaxed">
                  En Classe Confort, le trajet ne s'impose pas : il ressource !
                  Chaque détail est pensé pour favoriser le bien-être de votre
                  groupe : sellerie enveloppante, ambiance lumineuse, matériaux
                  nobles…
                </p>

                <div className="flex flex-col gap-3 pt-4">
                  <Link
                    to="/voyage-sur-mesure"
                    className="px-6 py-3 rounded-full bg-verbus-green text-white font-normal text-base text-center hover:bg-verbus-green/90 transition-colors"
                  >
                    Personnaliser mon trajet
                  </Link>
                  <Link
                    to="/devis"
                    className="px-6 py-3 rounded-full bg-white text-verbus-dark font-normal text-base text-center hover:bg-white/90 transition-colors"
                  >
                    Demander un devis
                  </Link>
                </div>
              </div>
            </div>

            {/* Right Image */}
            <div className="relative min-h-[600px]">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/d3d08ea5884bda4863fdb988136cbfb7a071ab39?width=4024"
                alt="Autocar Classe Confort"
                className="absolute inset-0 w-full h-full object-cover rounded-tl-[40px] rounded-bl-[40px] lg:rounded-bl-none lg:rounded-tr-[40px]"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Green Banner */}
      <section className="bg-verbus-green py-8">
        <div className="max-w-7xl mx-auto px-8">
          <p className="text-white text-center text-lg lg:text-xl">
            Pensée pour le grand tourisme et les voyages à la journée où le
            confort est essentiel
          </p>
        </div>
      </section>

      {/* Quote Section */}
      <section className="py-20 bg-[#FAFAFC]">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid lg:grid-cols-3 gap-8 items-center">
            {/* Left Image */}
            <div className="hidden lg:block">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/302679c7a10b4450730c4322f9209a5978c749a0?width=1200"
                alt="Groupe embarquant dans l'autocar"
                className="w-full h-auto rounded-lg"
              />
            </div>

            {/* Center Quote */}
            <div className="text-center space-y-6">
              <p className="text-verbus-green text-xl lg:text-2xl font-normal uppercase">
                l'esprit de cette classe
              </p>
              <h2 className="text-verbus-dark text-2xl lg:text-[35px] font-bold leading-tight">
                "Élégance, sérénité,
                <br />
                accueil soigné"
              </h2>
              <p className="text-verbus-dark text-lg lg:text-2xl font-bold leading-relaxed max-w-xl mx-auto">
                La Classe Confort a été conçue pour offrir un confort optimal
                pendant les trajets longs et exigeants. Le détail fait la
                différence : ambiance soignée, sièges spacieux et confortables,
                équipements adaptés pour voyager sereinement.
              </p>
            </div>

            {/* Right Image */}
            <div className="hidden lg:block">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/1e17d61524edf33008822d6a1eb97dfc393c74c5?width=1194"
                alt="Intérieur de l'autocar"
                className="w-full h-auto rounded-lg"
              />
            </div>
          </div>

          <div className="text-center mt-12 text-verbus-dark text-base font-bold max-w-xl mx-auto">
            <p>
              La Classe CONFORT est disponible selon les sites en : 41, 49, 55,
              59, 63 et 79 places.
            </p>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-4">
            L'expérience à bord
          </h2>

          <div className="text-center mb-12 space-y-4">
            {/* Decorative SVG */}
            <div className="flex justify-center">
              <svg
                width="92"
                height="111"
                viewBox="0 0 92 111"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M0.166211 50.3606C-0.625408 46.6499 1.46888 42.9297 5.0368 41.7082C7.03087 41.0233 9.231 41.227 11.0698 42.2707C11.3998 42.4574 11.6917 42.6945 11.9854 42.9266L11.5257 40.771C10.7554 37.1612 11.6365 33.4449 13.94 30.5742C15.1675 29.0442 16.7194 27.875 18.4499 27.1044C13.2574 25.0605 9.56418 19.98 9.56418 14.0362C9.56355 6.29633 15.8176 0 23.5039 0C31.1903 0 37.4437 6.29633 37.4437 14.0368C37.4437 19.449 34.3812 24.1473 29.9139 26.4889C31.2698 26.8193 32.5819 27.3257 33.7975 28.0339L51.8726 38.2995L60.4564 31.1544C63.869 28.4432 68.6782 28.7907 71.6618 31.937C72.7778 33.1144 73.4755 34.5863 73.7749 36.1491L77.8638 27.3371C78.3874 26.2076 79.3162 25.3525 80.4786 24.9268C81.6422 24.5023 82.8985 24.556 84.0221 25.0857C85.1425 25.6135 85.9917 26.5488 86.4145 27.7193C86.8359 28.891 86.7802 30.1573 86.2566 31.2862L83.2242 37.8215H90.9969C91.5506 37.8215 91.999 38.2731 91.999 38.8305V68.9721C91.999 69.3883 91.7454 69.7617 91.3602 69.9124C91.2418 69.9591 91.1197 69.9811 90.9969 69.9811C90.7208 69.9811 90.4521 69.867 90.2579 69.6532L75.8222 53.7742L74.1882 57.2958C73.6058 58.5501 72.5098 59.4727 71.1821 59.8284C70.7913 59.9337 70.3911 59.9861 69.9921 59.9861C69.3189 59.9861 68.6475 59.8385 68.03 59.5478C66.9096 59.0206 66.0603 58.0847 65.6376 56.9136C65.2149 55.7418 65.2712 54.4755 65.7954 53.3467L69.5556 45.2435L56.9661 54.548C54.781 56.1631 51.9615 56.5503 49.4294 55.5873L37.356 50.9994L39.1948 61.8017C40.282 61.7998 41.3273 62.1574 42.1715 62.8694C43.1197 63.6697 43.7021 64.7928 43.8105 66.0346C43.8205 66.1493 43.8054 66.261 43.8073 66.3751L65.9063 69.8506C68.5892 70.2731 70.8908 71.9973 72.0614 74.4663L83.4108 98.396C84.5049 100.703 84.5488 103.369 83.5336 105.711C82.5177 108.054 80.5456 109.833 78.1231 110.594C77.2463 110.868 76.3595 111 75.4877 111C72.2204 111 69.1617 109.15 67.6592 106.035L59.1437 88.3807C58.6865 87.4348 57.717 86.8231 56.6718 86.8231H54.7722V95.2775C54.7722 98.7479 51.969 101.571 48.522 101.571H16.1451C13.2192 101.571 10.6495 99.4801 10.0351 96.5999L0.166211 50.3606Z"
                  fill="#51AD32"
                />
              </svg>
            </div>

            <p className="text-verbus-green text-xl lg:text-2xl font-normal uppercase">
              Un confort spacieux pour voyager sereinement
            </p>
            <p className="text-verbus-green text-base">
              Une assise confortable et un espace optimisé pour les longues
              distances
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            <div>
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/7077245fef01e88d9bf72cf8ee8ea3e603b25a43?width=1570"
                alt="Équipements conviviaux"
                className="w-full h-auto rounded-[40px]"
              />
            </div>
            <div>
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/141b1c976a9e6adc7e6d116acd049a840231b135?width=1572"
                alt="Autocar moderne et confortable"
                className="w-full h-auto rounded-[40px]"
              />
            </div>
          </div>

          <div className="text-center space-y-4">
            <p className="text-verbus-green text-xl lg:text-2xl font-normal uppercase">
              Des équipements pensés pour les LONGS trajets
            </p>
            <p className="text-verbus-green text-base">
              Tout ce qu'il faut à bord pour plus d'autonomie et de confort
            </p>
          </div>

          <div className="text-center mt-12 text-verbus-dark text-base font-bold max-w-2xl mx-auto space-y-4">
            <p>
              Une ambiance lumineuse travaillée avec des matériaux qualitatifs.
              Chaque détail est pensé pour les longs trajets.
            </p>
            <p>
              Sièges inclinables avec repose-pieds • Écartement entre les
              sièges de 77 cm, favorisant l'aisance sur les longs trajets •
              Éclairage et aération individuels • Ambiance intérieure soignée
              et apaisante
            </p>
            <p>
              Prises USB et 230 V pour recharger les appareils • Système vidéo
              et sonorisation • Climatisation • Toilettes à bord • Réfrigérateur
              • Soutes adaptés aux voyages longue distance
            </p>
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="py-20 bg-[#FAFAFC]">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-12">
            Idéale pour
          </h2>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Enterprises */}
            <div className="text-center">
              <div className="w-80 h-80 mx-auto rounded-full bg-white mb-6 flex items-center justify-center">
                <div className="text-white text-[35px] font-bold">
                  <span className="text-verbus-dark">entreprises</span>
                </div>
              </div>
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/13a66adb32faa8732d43992d1a374494850fe74e?width=1574"
                alt="Entreprises"
                className="w-full h-auto rounded-[40px] mb-4"
              />
            </div>

            {/* Administrations */}
            <div className="text-center">
              <div className="w-80 h-80 mx-auto rounded-full bg-white mb-6 flex items-center justify-center">
                <div className="text-white text-[35px] font-bold">
                  <span className="text-verbus-dark">administrations</span>
                </div>
              </div>
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/a28bb398d1cda9e08fdcefff09aec908e9098b67?width=1572"
                alt="Administrations"
                className="w-full h-auto rounded-[40px] mb-4"
              />
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 mt-12">
            {/* Travel Agencies */}
            <div className="text-center">
              <div className="w-80 h-80 mx-auto rounded-full bg-white mb-6 flex items-center justify-center">
                <div className="text-white text-[35px] font-bold text-center">
                  <span className="text-verbus-dark">agences de voyage</span>
                </div>
              </div>
            </div>

            {/* Long Distance Groups */}
            <div className="text-center">
              <div className="w-80 h-80 mx-auto rounded-full bg-white mb-6 flex items-center justify-center">
                <div className="text-white text-[35px] font-bold text-center">
                  <span className="text-verbus-dark">
                    groupes longues distances
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Vehicle Discovery Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-verbus-dark mb-12">
            Découvrez nos véhicules
          </h2>

          <div className="grid lg:grid-cols-3 gap-8">
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/cb5c10ab8ae7c3fc484efcf41ddd74b56623754f?width=1012"
                alt="Équipements conviviaux"
                className="w-full h-auto"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-verbus-dark text-white text-center py-2 text-base italic uppercase">
                équipements CONVIVAUX
              </div>
            </div>

            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/f5fc71a9c43da0283967995ec9301fa6af2b6763?width=1750"
                alt="Autocar moderne et confortable"
                className="w-full h-auto"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-verbus-dark text-white text-center py-2 text-base italic uppercase">
                Autocar moderne et confortable
              </div>
            </div>

            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/36683a9074a563b417bd5d3d2674f261e33874c5?width=1230"
                alt="Intérieur spacieux"
                className="w-full h-auto"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-verbus-dark text-white text-center py-2 text-base italic uppercase">
                Intérieur spacieux
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Technical Specs Section */}
      <section className="bg-verbus-dark py-20">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-center text-white mb-12">
            Caractéristiques principales
          </h2>

          <div className="grid lg:grid-cols-2 gap-x-24 gap-y-6 max-w-4xl mx-auto">
            {/* Left Column */}
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <svg
                  className="w-3 h-3 mt-1 flex-shrink-0"
                  viewBox="0 0 13 12"
                  fill="none"
                >
                  <path
                    d="M0.752686 5.64014L4.25269 9.64014L11.7527 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <p className="text-white text-xl lg:text-2xl">climatisation</p>
              </div>

              <div className="flex items-start gap-3">
                <svg
                  className="w-3 h-3 mt-1 flex-shrink-0"
                  viewBox="0 0 13 12"
                  fill="none"
                >
                  <path
                    d="M0.752686 5.64014L4.25269 9.64014L11.7527 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <p className="text-white text-xl lg:text-2xl">repose-pieds</p>
              </div>

              <div className="flex items-start gap-3">
                <svg
                  className="w-3 h-3 mt-1 flex-shrink-0"
                  viewBox="0 0 13 12"
                  fill="none"
                >
                  <path
                    d="M0.752686 5.64014L4.25269 9.64014L11.7527 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <p className="text-white text-xl lg:text-2xl">
                  connectiques USB
                </p>
              </div>

              <div className="flex items-start gap-3">
                <svg
                  className="w-3 h-3 mt-1 flex-shrink-0"
                  viewBox="0 0 13 12"
                  fill="none"
                >
                  <path
                    d="M0.752686 5.64014L4.25269 9.64014L11.7527 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <p className="text-white text-xl lg:text-2xl">prises 230 V</p>
              </div>
            </div>

            {/* Right Column */}
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <svg
                  className="w-3 h-3 mt-1 flex-shrink-0"
                  viewBox="0 0 13 12"
                  fill="none"
                >
                  <path
                    d="M0.752686 5.64014L4.25269 9.64014L11.7527 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <p className="text-white text-xl lg:text-2xl">liseuses</p>
              </div>

              <div className="flex items-start gap-3">
                <svg
                  className="w-3 h-3 mt-1 flex-shrink-0"
                  viewBox="0 0 13 12"
                  fill="none"
                >
                  <path
                    d="M0.752686 5.64014L4.25269 9.64014L11.7527 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <p className="text-white text-xl lg:text-2xl">
                  ambiance feutrée
                </p>
              </div>

              <div className="flex items-start gap-3">
                <svg
                  className="w-3 h-3 mt-1 flex-shrink-0"
                  viewBox="0 0 13 12"
                  fill="none"
                >
                  <path
                    d="M0.752686 5.64014L4.25269 9.64014L11.7527 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <p className="text-white text-xl lg:text-2xl">réfrigérateur</p>
              </div>

              <div className="flex items-start gap-3">
                <svg
                  className="w-3 h-3 mt-1 flex-shrink-0"
                  viewBox="0 0 13 12"
                  fill="none"
                >
                  <path
                    d="M0.752686 5.64014L4.25269 9.64014L11.7527 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <p className="text-white text-xl lg:text-2xl">toilettes</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why This Class Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            {/* Left - Reasons */}
            <div className="bg-verbus-green rounded-[40px] p-12 space-y-8">
              <div className="flex items-start gap-3">
                <div className="flex gap-2 mt-2">
                  <svg
                    width="68"
                    height="72"
                    viewBox="0 0 70 74"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M35.0212 0.5C37.4056 0.500168 39.3499 1.98743 40.3064 4.2207L40.3103 4.23047L47.3269 21.5664L64.3259 23.6113H64.3269C66.635 23.8588 68.4882 25.5845 69.2058 27.8984C69.9294 30.2318 69.2854 32.7259 67.5974 34.416L67.5984 34.417L54.864 47.2334L58.3787 65.918L58.4197 66.1426C58.8038 68.4734 57.9253 70.7863 56.2009 72.1982L56.1921 72.2051C54.327 73.6657 51.871 73.8379 49.9021 72.6064L49.8992 72.6045L35.0945 63.1895L20.2917 72.6045C19.4105 73.1657 18.4276 73.5 17.4246 73.5H17.2019C15.9674 73.5 14.822 73.0849 13.7781 72.2812L13.7751 72.2793C11.904 70.8138 11.1102 68.3869 11.5886 65.9922L15.1023 47.3076L2.36792 34.416V34.415C0.672196 32.7159 0.11969 30.2236 0.756592 27.9131L0.759521 27.9023C1.47633 25.5116 3.25574 23.862 5.63354 23.6123L22.6414 21.5654L29.7322 4.22852L29.7351 4.2207C30.6917 1.98727 32.6367 0.5 35.0212 0.5Z"
                      fill="#E71D73"
                      stroke="#E72475"
                    />
                  </svg>
                  <svg
                    width="68"
                    height="72"
                    viewBox="0 0 70 74"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M35.0212 0.5C37.4056 0.500168 39.3499 1.98743 40.3064 4.2207L40.3103 4.23047L47.3269 21.5664L64.3259 23.6113H64.3269C66.635 23.8588 68.4882 25.5845 69.2058 27.8984C69.9294 30.2318 69.2854 32.7259 67.5974 34.416L67.5984 34.417L54.864 47.2334L58.3787 65.918L58.4197 66.1426C58.8038 68.4734 57.9253 70.7863 56.2009 72.1982L56.1921 72.2051C54.327 73.6657 51.871 73.8379 49.9021 72.6064L49.8992 72.6045L35.0945 63.1895L20.2917 72.6045C19.4105 73.1657 18.4276 73.5 17.4246 73.5H17.2019C15.9674 73.5 14.822 73.0849 13.7781 72.2812L13.7751 72.2793C11.904 70.8138 11.1102 68.3869 11.5886 65.9922L15.1023 47.3076L2.36792 34.416V34.415C0.672196 32.7159 0.11969 30.2236 0.756592 27.9131L0.759521 27.9023C1.47633 25.5116 3.25574 23.862 5.63354 23.6123L22.6414 21.5654L29.7322 4.22852L29.7351 4.2207C30.6917 1.98727 32.6367 0.5 35.0212 0.5Z"
                      fill="#E71D73"
                      stroke="#E72475"
                    />
                  </svg>
                  <svg
                    width="68"
                    height="72"
                    viewBox="0 0 70 74"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M35.0212 0.5C37.4056 0.500168 39.3499 1.98743 40.3064 4.2207L40.3103 4.23047L47.3269 21.5664L64.3259 23.6113H64.3269C66.635 23.8588 68.4882 25.5845 69.2058 27.8984C69.9294 30.2318 69.2854 32.7259 67.5974 34.416L67.5984 34.417L54.864 47.2334L58.3787 65.918L58.4197 66.1426C58.8038 68.4734 57.9253 70.7863 56.2009 72.1982L56.1921 72.2051C54.327 73.6657 51.871 73.8379 49.9021 72.6064L49.8992 72.6045L35.0945 63.1895L20.2917 72.6045C19.4105 73.1657 18.4276 73.5 17.4246 73.5H17.2019C15.9674 73.5 14.822 73.0849 13.7781 72.2812L13.7751 72.2793C11.904 70.8138 11.1102 68.3869 11.5886 65.9922L15.1023 47.3076L2.36792 34.416V34.415C0.672196 32.7159 0.11969 30.2236 0.756592 27.9131L0.759521 27.9023C1.47633 25.5116 3.25574 23.862 5.63354 23.6123L22.6414 21.5654L29.7322 4.22852L29.7351 4.2207C30.6917 1.98727 32.6367 0.5 35.0212 0.5Z"
                      fill="#E71D73"
                      stroke="#E72475"
                    />
                  </svg>
                </div>
              </div>

              <h2 className="text-[40px] font-bold text-white uppercase leading-tight">
                Pourquoi
                <br />
                cette classe ?
              </h2>

              <div className="space-y-6">
                <div className="flex gap-4">
                  <span className="text-[40px] font-medium text-verbus-dark flex-shrink-0">
                    1 )
                  </span>
                  <p className="text-xl lg:text-2xl font-medium text-verbus-dark pt-2">
                    un confort pensé pour les longs trajets
                  </p>
                </div>

                <div className="flex gap-4">
                  <span className="text-[40px] font-medium text-verbus-dark flex-shrink-0">
                    2 )
                  </span>
                  <p className="text-xl lg:text-2xl font-medium text-verbus-dark pt-2">
                    une ambiance spacieuse, soignée et apaisante
                  </p>
                </div>

                <div className="flex gap-4">
                  <span className="text-[40px] font-medium text-verbus-dark flex-shrink-0">
                    3 )
                  </span>
                  <p className="text-xl lg:text-2xl font-medium text-verbus-dark pt-2">
                    des équipements adaptés pour voyager sereinement sur la
                    durée
                  </p>
                </div>
              </div>
            </div>

            {/* Right - CTA */}
            <div className="relative bg-verbus-green rounded-[40px] rounded-l-none lg:rounded-l-[40px] p-12 lg:p-16 space-y-8">
              <div className="absolute top-8 left-8">
                <p className="text-verbus-dark text-base font-extrabold text-center uppercase">
                  voyage sur-mesure
                </p>
                <div className="w-full h-px bg-verbus-dark mt-2"></div>
              </div>

              <div className="pt-12 space-y-6 text-center">
                <h3 className="text-[40px] font-bold text-white leading-tight">
                  Prêt à créer
                  <br />
                  votre voyage idéal ?
                </h3>

                <p className="text-white text-lg leading-relaxed">
                  En quelques questions, nous préparons avec vous un devis
                  adapté à votre projet, au nombre de voyageurs et à votre
                  budget.
                </p>

                <Link
                  to="/voyage-sur-mesure"
                  className="inline-block px-8 py-4 rounded-full bg-white text-verbus-green font-normal text-base hover:bg-white/90 transition-colors"
                >
                  personnaliser mon trajet
                </Link>

                <p className="text-white text-xs italic">
                  Réponse garantie sous 24h à 48h ouvrées • Sans engagement
                </p>
              </div>

              <div className="absolute -right-16 -bottom-16">
                <img
                  src="https://api.builder.io/api/v1/image/assets/TEMP/f07739647149f370499aa620aa42aa385fa8ba1d?width=700"
                  alt="Voyage sur mesure"
                  className="w-[350px] h-auto rounded-[40px]"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
