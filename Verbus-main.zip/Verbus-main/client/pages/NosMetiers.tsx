import PlaceholderPage from "@/components/PlaceholderPage";

export default function NosMetiers() {
  return (
    <PlaceholderPage
      title="Nos Métiers"
      description="Découvrez les métiers et l'expertise de nos équipes"
    />
  );
}
