import { Link } from "react-router-dom";

export default function Tourisme() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative h-[926px] overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/b36125763327ed6b5a3a4cf234c958af296bf603?width=4456"
            alt="Tourisme"
            className="w-full h-full object-cover rounded-[40px]"
          />
        </div>

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#1E1E1E] via-[#1E1E1E]/80 to-transparent" />

        {/* Decorative SVG Elements */}
        <div className="absolute left-[137px] top-[191px]">
          <svg
            width="36"
            height="33"
            viewBox="0 0 36 33"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M28.3742 28.7757H25.6863C23.6289 28.7757 21.5722 28.7757 19.5147 28.7757C17.2429 28.7757 14.971 28.7757 12.6984 28.7757C11.1578 28.7757 9.61708 28.7757 8.07641 28.7757C7.75778 28.7757 7.40376 28.8071 7.09195 28.7369C6.1783 28.5304 5.6602 27.7398 5.65816 26.8368C5.65612 25.7354 5.65816 24.6341 5.65816 23.5327C5.65816 21.4684 5.65816 19.404 5.65816 17.3397C5.65816 15.0266 5.65816 12.7135 5.65816 10.401C5.65816 8.5541 5.65816 6.70715 5.65816 4.86021C5.65816 4.3368 5.65816 3.8127 5.65816 3.28929C5.65816 2.8865 5.63978 2.49326 5.80794 2.11092C6.14426 1.3442 6.8809 1.02729 7.6686 1.02729C8.13972 1.02729 8.61016 1.02729 9.08128 1.02729C10.9447 1.02729 12.8081 1.02729 14.6714 1.02729C16.978 1.02729 19.2853 1.02729 21.5919 1.02729C23.3961 1.02729 25.1995 1.02729 27.0037 1.02729C27.4203 1.02729 27.837 1.02661 28.2537 1.02729C29.2007 1.02934 30.0592 1.63317 30.1749 2.62411C30.2055 2.88378 30.1851 3.15775 30.1851 3.41809C30.1851 3.98717 30.1851 4.55693 30.1851 5.12601C30.1851 7.02338 30.1851 8.92076 30.1851 10.8181C30.1851 13.1367 30.1851 15.4553 30.1851 17.7731C30.1851 20.091 30.1851 21.8228 30.1851 23.8483C30.1851 24.8651 30.1906 25.8827 30.1851 26.8995C30.1797 27.9163 29.4172 28.756 28.3742 28.7771C27.7179 28.7907 27.7158 29.813 28.3742 29.7994C29.9414 29.7674 31.1832 28.5222 31.2063 26.952C31.2104 26.6712 31.2063 26.3904 31.2063 26.1103V21.3955C31.2063 19.0953 31.2063 16.7945 31.2063 14.4943C31.2063 12.1941 31.2063 9.98054 31.2063 7.72331C31.2063 6.2812 31.2063 4.83908 31.2063 3.39697C31.2063 3.03848 31.2179 2.68341 31.158 2.32833C30.9258 0.961183 29.6854 0.0138578 28.3326 0.00363482C27.2106 -0.00454353 26.0887 0.00363482 24.9667 0.00363482C22.7772 0.00363482 20.5877 0.00363482 18.3982 0.00363482C16.2087 0.00363482 13.8674 0.00363482 11.6023 0.00363482C10.2863 0.00363482 8.97031 0.00363482 7.65498 0.00363482C6.67597 0.00363482 5.77662 0.365527 5.18295 1.17246C4.75608 1.75244 4.6383 2.42374 4.6383 3.12231C4.6383 4.40972 4.6383 5.69713 4.6383 6.98454C4.6383 9.1811 4.6383 11.377 4.6383 13.5736C4.6383 15.7701 4.6383 18.2284 4.6383 20.5558C4.6383 22.2719 4.6383 23.9873 4.6383 25.7034C4.6383 26.0878 4.63694 26.4722 4.6383 26.8572C4.6417 27.9497 5.18499 28.9904 6.18647 29.4886C6.74065 29.764 7.30777 29.798 7.90484 29.798C8.50191 29.798 9.05882 29.798 9.63615 29.798C11.6663 29.798 13.6965 29.798 15.7274 29.798C18.0694 29.798 20.4114 29.798 22.7534 29.798C24.386 29.798 26.0185 29.798 27.6511 29.798H28.3755C29.0325 29.798 29.0339 28.7757 28.3755 28.7757H28.3742Z"
              fill="#51AD32"
            />
          </svg>
        </div>

        <div className="absolute left-[187px] top-[224px] w-[139px] h-[1px] bg-[#51AD32]" />

        {/* Decorative Curve SVG - Left */}
        <div className="absolute -left-[445px] top-[4524px]">
          <svg
            width="261"
            height="336"
            viewBox="0 0 261 336"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M-74.9413 235.113C-88.2166 235.113 -102.238 232.5 -117.888 226.529C-168.083 207.38 -192.395 161.346 -211.196 114.448C-225.186 79.5405 -247.839 58.2854 -278.51 51.269C-323.259 41.0295 -382.823 62.2846 -430.24 105.42L-442.499 116.571L-464.857 92.1162L-452.598 80.966C-397.377 30.7346 -326.125 6.41473 -271.078 19.0142C-229.76 28.4697 -198.389 57.2242 -180.374 102.166C-158.5 156.737 -136.959 183.812 -106.026 195.612C-70.5109 209.162 -48.0571 200.102 -5.29327 176.21C36.9862 152.579 81.2347 140.106 122.712 140.106C122.982 140.106 123.252 140.106 123.522 140.106C172.106 140.297 214.608 158.083 246.43 191.55L257.848 203.555L233.766 226.339L222.349 214.333C164.023 152.999 74.8988 169.352 10.9357 205.091C-20.2122 222.498 -45.7704 235.113 -74.9254 235.113H-74.9413Z"
              fill="#55AD32"
            />
          </svg>
        </div>

        {/* Main Content */}
        <div className="relative z-10 max-w-[600px] pt-[514px] pl-[119px]">
          <div className="flex items-center gap-2 mb-6">
            <span className="text-white text-base italic">
              Services l Tourisme
            </span>
          </div>

          <h1 className="text-white text-[40px] font-bold leading-tight mb-8">
            tourisme
          </h1>

          <p className="text-white text-base leading-tight mb-12 max-w-[401px]">
            Voyager avec confort, sérénité et accompagnement en France et en
            Europe. VERBUS accompagne clubs, associations et groupes constitués
            pour leurs circuits découverte, séjours organisés et voyages
            touristiques, en assurant un transport confortable et attentif tout
            au long du trajet.
          </p>

          <Link to="/contact">
            <button className="bg-[#51AD32] text-white px-8 py-3 rounded-full text-base font-normal hover:bg-[#459629] transition-colors">
              demander un devis
            </button>
          </Link>
        </div>
      </section>

      {/* Pourquoi les clubs choisissent Verbus Section */}
      <section className="py-24 bg-[#FAFAFC]">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-[#1E1E1E] text-center leading-[45px] lowercase mb-20">
            Pourquoi les clubs choisissent Verbus ?
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-16 max-w-6xl mx-auto">
            {/* Benefit 1 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg
                  width="130"
                  height="132"
                  viewBox="0 0 130 132"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <circle
                    cx="65"
                    cy="66"
                    r="64"
                    fill="#51AD32"
                    fillOpacity="0.1"
                  />
                  <path
                    d="M67.092 13.1482C67.0993 14.4948 66.4789 15.3521 65.492 15.5532C64.7482 15.7011 63.4022 15.1852 63.3986 14.051L63.3877 1.61234C63.3877 0.535007 64.5124 0.000132855 65.2235 0.00392629C66.0689 0.00771972 67.0376 0.614669 67.0412 1.692L67.092 13.152V13.1482Z"
                    fill="#F1BDBF"
                    transform="translate(32, 32)"
                  />
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-[#1E1E1E] mb-4">
                Accompagnement humain
              </h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px]">
                Un interlocuteur unique pour organiser votre voyage, de la
                planification jusqu'au retour.
              </p>
            </div>

            {/* Benefit 2 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg
                  width="92"
                  height="111"
                  viewBox="0 0 92 111"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <circle
                    cx="46"
                    cy="55.5"
                    r="44"
                    fill="#51AD32"
                    fillOpacity="0.1"
                  />
                  <path
                    d="M46 0C54.2843 0 61 6.71573 61 15C61 23.2843 54.2843 30 46 30C37.7157 30 31 23.2843 31 15C31 6.71573 37.7157 0 46 0Z"
                    fill="#51AD32"
                    transform="translate(0, 10)"
                  />
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-[#1E1E1E] mb-4">
                Flexibilité des itinéraires
              </h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px]">
                Adaptation aux envies du groupe, arrêts personnalisés et
                découvertes sur mesure.
              </p>
            </div>

            {/* Benefit 3 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg
                  width="127"
                  height="127"
                  viewBox="0 0 127 127"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <circle
                    cx="63.5"
                    cy="63.5"
                    r="63.5"
                    fill="#51AD32"
                    fillOpacity="0.1"
                  />
                  <path
                    d="M52.4929 91.8959C52.4929 92.7518 51.8003 93.4493 50.9395 93.4493H25.2001C21.4206 93.4493 18.3436 90.3722 18.3436 86.5927V72.3552C18.3436 68.5806 21.4206 65.5085 25.2001 65.5085H62.3869C66.1664 65.5085 69.2435 68.5806 69.2435 72.3552V79.8202C69.2435 80.6761 68.5509 81.3736 67.6901 81.3736C66.8293 81.3736 66.1368 80.681 66.1368 79.8202V72.3552C66.1368 70.2873 64.4548 68.6103 62.382 68.6103H25.2001C23.1323 68.6103 21.4453 70.2923 21.4453 72.3552V86.5927C21.4453 88.6606 23.1273 90.3475 25.2001 90.3475H50.9395C51.7953 90.3475 52.4929 91.0401 52.4929 91.9009V91.8959Z"
                    fill="#51AD32"
                    transform="translate(15, 0)"
                  />
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-[#1E1E1E] mb-4">
                Confort long trajet
              </h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px]">
                Sièges inclinables, climatisation, ambiance lumineuse soignée
                pour voyager sereinement.
              </p>
            </div>

            {/* Benefit 4 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg
                  width="146"
                  height="106"
                  viewBox="0 0 146 106"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <circle
                    cx="73"
                    cy="53"
                    r="50"
                    fill="#51AD32"
                    fillOpacity="0.1"
                  />
                  <path
                    d="M114.714 106C114.202 106 113.7 105.798 113.323 105.422L98.8987 90.8971H84.9522C69.4892 90.8971 56.9043 78.2282 56.9043 62.6526C56.9043 47.0771 69.485 34.4082 84.9522 34.4082H117.952C133.415 34.4082 146 47.0771 146 62.6526C146 78.2282 133.419 90.8971 117.952 90.8971H116.678V104.022C116.678 104.823 116.201 105.545 115.463 105.848C115.22 105.95 114.965 106 114.714 106Z"
                    fill="#51AD32"
                    transform="translate(-40, -20)"
                  />
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-[#1E1E1E] mb-4">
                Conducteurs expérimentés
              </h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px]">
                Habitués aux voyages de groupes, connaissance des routes et des
                sites touristiques.
              </p>
            </div>

            {/* Benefit 5 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg
                  width="92"
                  height="111"
                  viewBox="0 0 92 111"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <circle
                    cx="46"
                    cy="55.5"
                    r="44"
                    fill="#51AD32"
                    fillOpacity="0.1"
                  />
                  <path
                    d="M46 20C54.2843 20 61 26.7157 61 35C61 43.2843 54.2843 50 46 50C37.7157 50 31 43.2843 31 35C31 26.7157 37.7157 20 46 20Z"
                    fill="#51AD32"
                  />
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-[#1E1E1E] mb-4">
                Organisation complète
              </h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px]">
                Gestion des horaires, coordination avec hébergements et sites de
                visite.
              </p>
            </div>

            {/* Benefit 6 */}
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <svg
                  width="117"
                  height="104"
                  viewBox="0 0 117 104"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <circle
                    cx="58.5"
                    cy="52"
                    r="50"
                    fill="#51AD32"
                    fillOpacity="0.1"
                  />
                  <path
                    d="M64.8352 100.996H24.5174C23.8294 100.996 23.2683 100.439 23.2683 99.7478C23.2683 99.0563 23.8256 98.4993 24.5174 98.4993H64.8352C66.999 98.4993 68.5095 97.3508 68.5095 96.3175V86.3607C68.5095 85.435 67.3565 84.5323 65.8268 84.2634C53.6623 82.1237 36.4359 86.4837 21.1928 91.0356C20.5318 91.2315 19.8361 90.8589 19.6401 90.1982C19.4441 89.5375 19.8169 88.8422 20.478 88.6463C36.7819 83.7794 53.6123 79.5808 66.2573 81.8088C69.0514 82.3005 71.0001 84.175 71.0001 86.3646V96.3213C71.0001 98.9449 68.2904 100.996 64.8313 100.996H64.8352Z"
                    fill="#51AD32"
                    transform="translate(10, -20)"
                  />
                </svg>
              </div>
              <h3 className="text-[30px] font-bold text-[#1E1E1E] mb-4">
                Expérience conviviale
              </h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px]">
                Créer des souvenirs ensemble, dans une ambiance chaleureuse et
                détendue.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Types de voyages Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-8 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left - Image */}
          <div>
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/ca6aa3eb57b459a2417c767a7ce7a1c2a3e970cd?width=1452"
              alt="Types de voyages"
              className="w-full h-[726px] object-cover rounded-[40px]"
            />
          </div>

          {/* Right - Content */}
          <div>
            <h2 className="text-[40px] font-bold text-[#1E1E1E] leading-[45px] lowercase mb-12">
              Types de voyages
            </h2>

            <div className="space-y-10">
              <div className="flex items-start gap-4">
                <svg
                  width="13"
                  height="12"
                  viewBox="0 0 13 12"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="flex-shrink-0 mt-1"
                >
                  <path
                    d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <span className="text-[25px] text-[#1E1E1E]">
                  Séjours France
                </span>
              </div>

              <div className="flex items-start gap-4">
                <svg
                  width="13"
                  height="12"
                  viewBox="0 0 13 12"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="flex-shrink-0 mt-1"
                >
                  <path
                    d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <span className="text-[25px] text-[#1E1E1E]">
                  Circuits Europe
                </span>
              </div>

              <div className="flex items-start gap-4">
                <svg
                  width="13"
                  height="12"
                  viewBox="0 0 13 12"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="flex-shrink-0 mt-1"
                >
                  <path
                    d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <span className="text-[25px] text-[#1E1E1E]">
                  Voyages clubs & associations
                </span>
              </div>

              <div className="flex items-start gap-4">
                <svg
                  width="13"
                  height="12"
                  viewBox="0 0 13 12"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="flex-shrink-0 mt-1"
                >
                  <path
                    d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <span className="text-[25px] text-[#1E1E1E]">
                  Sorties culturelles
                </span>
              </div>

              <div className="flex items-start gap-4">
                <svg
                  width="13"
                  height="12"
                  viewBox="0 0 13 12"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="flex-shrink-0 mt-1"
                >
                  <path
                    d="M0.75293 5.64014L4.25293 9.64014L11.7529 0.640137"
                    stroke="#51AD32"
                    strokeWidth="2"
                  />
                </svg>
                <span className="text-[25px] text-[#1E1E1E]">
                  Voyages organisés
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-24 bg-[#FAFAFC]">
        <div className="max-w-4xl mx-auto px-8 text-center relative">
          {/* Decorative Quote SVG */}
          <div className="absolute left-0 top-0">
            <svg
              width="66"
              height="58"
              viewBox="0 0 66 58"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M91.6719 21.971C80.9191 22.8208 70.5399 25.4873 60.5254 29.027C59.6221 29.3467 56.2173 30.4226 57.3985 31.7091C63.105 37.9465 69.8363 43.2639 76.0552 49.0646C77.9139 50.7955 87.5723 47.3649 85.9481 45.8524C79.7205 40.0516 72.9979 34.742 67.2914 28.4968L64.1646 31.1789C71.5908 28.5514 79.1386 26.4073 87.1294 25.7758C88.9794 25.6277 93.0963 25.1287 94.156 23.5225C95.2156 21.9164 93.244 21.8462 91.6719 21.971Z"
                fill="#E71D74"
              />
            </svg>
          </div>

          <p className="text-[25px] font-bold text-[#1E1E1E] text-center leading-[30px] mb-8 max-w-[640px] mx-auto">
            "Notre voyage en Italie était parfaitement organisé. Le conducteur
            connaissait tous les bons endroits pour les pauses, et l'ambiance à
            bord était vraiment conviviale."
          </p>

          <div className="text-center">
            <p className="text-[25px] text-[#1E1E1E] font-normal">
              Catherine L.
            </p>
            <p className="text-base text-[#1E1E1E] italic">
              Présidente d'association
            </p>
          </div>
        </div>
      </section>

      {/* Classes recommandées Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-8">
          {/* Decorative SVG */}
          <div className="relative mb-16">
            <div className="absolute left-1/2 -translate-x-1/2 -top-12">
              <svg
                width="206"
                height="210"
                viewBox="0 0 206 210"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M178.75 168.141C176.633 162.938 174.298 157.805 171.746 152.762C169.01 147.345 166.022 142.03 162.804 136.832C159.395 131.327 155.715 125.952 151.791 120.725C147.69 115.261 143.304 109.969 138.655 104.872C133.729 99.4675 128.5 94.2879 123.007 89.345C117.513 84.4021 111.308 79.3586 105.043 74.7946C98.4092 69.9583 91.4916 65.4357 84.3102 61.2742C76.687 56.8463 68.7868 52.8032 60.6624 49.1568C52.0632 45.2972 43.2135 41.8756 34.1988 38.8922C24.5445 35.6956 14.6924 32.9962 4.70833 30.7527C2.14968 30.1785 -0.415568 29.6339 -2.99401 29.1189C-3.4754 29.0242 -4.22059 29.0538 -3.9766 29.6576C-3.7326 30.2614 -2.71705 30.6817 -2.10377 30.806C7.94621 32.8186 17.8907 35.2753 27.6373 38.2469C36.6849 40.9995 45.5809 44.1784 54.2394 47.813C62.344 51.2168 70.2574 55.0053 77.8872 59.1964C85.517 63.3875 92.1774 67.5253 98.9104 72.2018C105.261 76.606 111.341 81.3239 117.137 86.3023C122.67 91.0558 127.933 96.0578 132.911 101.285C137.692 106.305 142.203 111.526 146.437 116.919C150.446 122.027 154.205 127.296 157.7 132.706C161.195 138.117 164.123 143.125 166.972 148.494C169.649 153.537 172.109 158.67 174.345 163.885C174.865 165.098 175.373 166.312 175.868 167.537C176.112 168.141 177.101 168.555 177.741 168.686C178.222 168.786 178.974 168.762 178.723 168.147L178.75 168.141Z"
                  fill="#E71D74"
                  transform="translate(15, 20)"
                />
              </svg>
            </div>
          </div>

          <h2 className="text-[40px] font-bold text-[#1E1E1E] text-center leading-[45px] lowercase mb-6">
            Classes recommandées pour le tourisme
          </h2>

          <p className="text-base font-bold text-[#1E1E1E] text-center lowercase mb-20">
            Nos véhicules adaptés aux besoins des voyages de groupe.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto mb-12">
            {/* Classe Confort */}
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/4ba67a6a7e91808ee4e75a8b597d873dbae72a2a?width=1452"
                alt="Classe Confort"
                className="w-full h-[726px] object-cover rounded-[40px]"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-[#51AD32] rounded-b-[40px] p-8 text-center">
                <div className="mb-4">
                  <div className="text-white text-[40px] font-bold uppercase">
                    CLASSE
                  </div>
                  <div className="text-white text-[55px] font-bold uppercase leading-tight">
                    confort
                  </div>
                </div>
                <div className="flex justify-center gap-2 mb-6">
                  {[...Array(3)].map((_, i) => (
                    <svg
                      key={i}
                      width="40"
                      height="43"
                      viewBox="0 0 40 43"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M9.53057 43C8.87546 43 8.26402 42.7781 7.69625 42.3344C6.69174 41.5356 6.255 40.2043 6.51704 38.8731L8.61341 27.5573L1.01408 19.7472C0.0969229 18.8153 -0.208797 17.4396 0.140597 16.1527C0.533666 14.8215 1.4945 13.934 2.76105 13.8008L12.9372 12.5583L17.1736 2.04128C17.6977 0.798762 18.7458 0 20.0124 0C21.279 0 22.3271 0.798762 22.8512 2.04128L27.044 12.5583L37.2201 13.8008C38.443 13.934 39.4475 14.8658 39.8405 16.1527C40.2336 17.4396 39.8842 18.8153 38.967 19.7472L31.3677 27.5129L33.4641 38.8287C33.7261 40.16 33.2457 41.4912 32.2849 42.29C31.2804 43.0887 29.9701 43.1775 28.922 42.5119L20.0561 36.7874L11.1902 42.5119C10.7098 42.8225 10.1857 43 9.66159 43H9.53057Z"
                        fill="#E71D74"
                      />
                    </svg>
                  ))}
                </div>
                <p className="text-white text-base mb-6">
                  Idéale pour les circuits découverte et séjours en groupe.
                </p>
                <Link to="/classe-confort">
                  <button className="bg-white text-[#1E1E1E] px-8 py-3 rounded-full text-base border border-[#1E1E1E] hover:bg-gray-50 transition-colors">
                    découvrir
                  </button>
                </Link>
              </div>
            </div>

            {/* Classe Star */}
            <div className="relative">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/bbcedb7f9c88bf2f04cbd9f1345f00871fbd5ce6?width=1452"
                alt="Classe Star"
                className="w-full h-[726px] object-cover rounded-[40px]"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-[#51AD32] rounded-b-[40px] p-8 text-center">
                <div className="mb-4">
                  <div className="text-white text-[40px] font-bold uppercase">
                    CLASSE
                  </div>
                  <div className="text-white text-[55px] font-bold uppercase leading-tight">
                    star
                  </div>
                </div>
                <div className="flex justify-center gap-2 mb-6">
                  {[...Array(4)].map((_, i) => (
                    <svg
                      key={i}
                      width="40"
                      height="43"
                      viewBox="0 0 40 43"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M9.53057 43C8.87546 43 8.26402 42.7781 7.69625 42.3344C6.69174 41.5356 6.255 40.2043 6.51704 38.8731L8.61341 27.5573L1.01408 19.7472C0.0969229 18.8153 -0.208797 17.4396 0.140597 16.1527C0.533666 14.8215 1.4945 13.934 2.76105 13.8008L12.9372 12.5583L17.1736 2.04128C17.6977 0.798762 18.7458 0 20.0124 0C21.279 0 22.3271 0.798762 22.8512 2.04128L27.044 12.5583L37.2201 13.8008C38.443 13.934 39.4475 14.8658 39.8405 16.1527C40.2336 17.4396 39.8842 18.8153 38.967 19.7472L31.3677 27.5129L33.4641 38.8287C33.7261 40.16 33.2457 41.4912 32.2849 42.29C31.2804 43.0887 29.9701 43.1775 28.922 42.5119L20.0561 36.7874L11.1902 42.5119C10.7098 42.8225 10.1857 43 9.66159 43H9.53057Z"
                        fill="#E71D74"
                      />
                    </svg>
                  ))}
                </div>
                <p className="text-white text-base mb-6">
                  L'excellence pour les voyages longue distance et circuits
                  premium.
                </p>
                <Link to="/classe-star">
                  <button className="bg-white text-[#1E1E1E] px-8 py-3 rounded-full text-base border border-[#1E1E1E] hover:bg-gray-50 transition-colors">
                    découvrir
                  </button>
                </Link>
              </div>
            </div>
          </div>

          <div className="text-center">
            <Link to="/nos-vehicules">
              <button className="bg-[#51AD32] text-white px-8 py-3 rounded-full text-base hover:bg-[#459629] transition-colors">
                voir toutes nos classes
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* Découvrez nos autres services Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-[40px] font-bold text-[#1E1E1E] text-center leading-[45px] lowercase mb-20">
            Découvrez nos autres services
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Service 1 - Événements Professionnels */}
            <div className="border border-[#51AD32] rounded-[40px] p-8 text-center hover:shadow-lg transition-shadow">
              <div className="flex justify-center mb-6">
                <svg
                  width="50"
                  height="116"
                  viewBox="0 0 50 116"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M43.9331 41.0727H39.1562V7.47746C39.1562 3.35418 35.7581 0 31.5809 0H18.3416C14.1644 0 10.7663 3.35418 10.7663 7.47746V41.0727H5.98943C2.68724 41.0727 0 43.7252 0 46.9848V105.119C0 108.379 2.68724 111.031 5.98943 111.031H7.26218C7.4539 113.623 9.65061 115.675 12.3246 115.675C14.9986 115.675 17.1943 113.623 17.387 111.031H32.5355C32.7272 113.623 34.9239 115.675 37.5979 115.675C40.2719 115.675 42.4676 113.623 42.6603 111.031H43.9331C47.2352 111.031 49.9225 108.379 49.9225 105.119V46.9848C49.9225 43.7252 47.2352 41.0727 43.9331 41.0727Z"
                    fill="#51AD32"
                  />
                </svg>
              </div>
              <h3 className="text-[25px] font-bold text-[#1E1E1E] lowercase mb-4">
                Événements Professionnels
              </h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px] lowercase mb-6">
                Séminaires, congrès et transferts VIP
              </p>
              <Link to="/evenements-professionnels">
                <button className="inline-flex items-center justify-center">
                  <svg
                    width="99"
                    height="58"
                    viewBox="0 0 99 58"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <circle cx="29" cy="29" r="28.5" stroke="#51AD32" />
                    <path
                      d="M20 29H38M38 29L31 22M38 29L31 36"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                </button>
              </Link>
            </div>

            {/* Service 2 - Sport & Loisirs */}
            <div className="border border-[#51AD32] rounded-[40px] p-8 text-center hover:shadow-lg transition-shadow">
              <div className="flex justify-center mb-6">
                <svg
                  width="127"
                  height="98"
                  viewBox="0 0 127 98"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M126.924 79.6082L123.353 42.0957C122.527 33.4285 115.353 26.8935 106.665 26.8935H95.2302C94.1377 20.2646 91.0576 14.2584 86.2487 9.43804C80.1699 3.35273 72.0935 0 63.4993 0C54.905 0 46.8287 3.35273 40.7523 9.44051C35.9434 14.2584 32.8608 20.2671 31.7708 26.896H20.3357C11.6477 26.896 4.47148 33.4309 3.64535 42.0981L0.0769502 79.6082C-0.369408 84.3074 1.19161 89.0092 4.36051 92.5027C7.53187 95.9963 12.0522 98 16.7648 98H110.234C114.946 98 119.467 95.9963 122.638 92.5027C125.809 89.0092 127.37 84.3099 126.922 79.6082H126.924Z"
                    fill="#51AD32"
                  />
                </svg>
              </div>
              <h3 className="text-[25px] font-bold text-[#1E1E1E] lowercase mb-4">
                Sport & loisirs
              </h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px] lowercase mb-6">
                clubs sportifs, colonies et évènements
              </p>
              <Link to="/sport-loisirs">
                <button className="inline-flex items-center justify-center">
                  <svg
                    width="99"
                    height="58"
                    viewBox="0 0 99 58"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <circle cx="29" cy="29" r="28.5" stroke="#51AD32" />
                    <path
                      d="M20 29H38M38 29L31 22M38 29L31 36"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                </button>
              </Link>
            </div>

            {/* Service 3 - Groupes Scolaires */}
            <div className="border border-[#51AD32] rounded-[40px] p-8 text-center hover:shadow-lg transition-shadow">
              <div className="flex justify-center mb-6">
                <svg
                  width="91"
                  height="109"
                  viewBox="0 0 91 109"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M64.5732 81.8713H26.4276C24.7218 81.8713 23.334 83.2642 23.334 84.9769V94.0546C23.334 95.7666 24.7218 97.1594 26.4276 97.1594H64.5732C66.279 97.1594 67.6668 95.7666 67.6668 94.0546V84.9769C67.6668 83.2649 66.279 81.8713 64.5732 81.8713Z"
                    fill="#51AD32"
                  />
                </svg>
              </div>
              <h3 className="text-[25px] font-bold text-[#1E1E1E] lowercase mb-4">
                Groupes scolaires
              </h3>
              <p className="text-base font-bold text-[#1E1E1E] leading-[18px] lowercase mb-6">
                sorties pédagogiques, séjour scolaires et transferts
              </p>
              <Link to="/groupes-scolaires">
                <button className="inline-flex items-center justify-center">
                  <svg
                    width="99"
                    height="58"
                    viewBox="0 0 99 58"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <circle cx="29" cy="29" r="28.5" stroke="#51AD32" />
                    <path
                      d="M20 29H38M38 29L31 22M38 29L31 36"
                      stroke="#51AD32"
                      strokeWidth="2"
                    />
                  </svg>
                </button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section - Prêt à planifier votre voyage */}
      <section className="py-24 relative">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex items-stretch gap-0">
            {/* Left - Image */}
            <div className="w-[520px] flex-shrink-0">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/96b62ce5855ac98bc92546b5e5188e1d7fd6fa99?width=1040"
                alt="Prêt à planifier votre voyage"
                className="w-full h-full object-cover rounded-l-[40px]"
              />
            </div>

            {/* Right - Content */}
            <div className="flex-1 bg-[#51AD32] rounded-r-[40px] px-16 py-12 flex flex-col justify-center">
              <div className="text-center uppercase text-[#1E1E1E] text-base font-extrabold mb-4">
                voyage sur-mesure
              </div>
              <div className="w-[263px] h-[1px] bg-black mx-auto mb-12"></div>

              <h2 className="text-white text-[40px] font-bold text-center leading-tight mb-8">
                Prêt à planifier
                <br />
                votre voyage ?
              </h2>

              <p className="text-white text-xl text-center mb-12 max-w-[526px] mx-auto">
                En quelques questions, nous préparons
                <br />
                avec vous un devis
                <br />
                adapté à votre projet, au nombre
                <br />
                de voyageurs et à votre budget.
              </p>

              <div className="text-center mb-4">
                <Link to="/contact">
                  <button className="bg-white text-[#51AD32] px-12 py-5 rounded-full text-base hover:bg-gray-50 transition-colors">
                    personnaliser mon trajet
                  </button>
                </Link>
              </div>

              <p className="text-white text-[13px] italic text-center">
                Réponse garantie sous 24h à 48h ouvrées • Sans engagement
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
