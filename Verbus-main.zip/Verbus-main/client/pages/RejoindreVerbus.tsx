import PlaceholderPage from "@/components/PlaceholderPage";

export default function RejoindreVerbus() {
  return (
    <PlaceholderPage
      title="Rejoindre Verbus"
      description="Découvrez nos opportunités de carrière et rejoignez nos équipes"
    />
  );
}
