import PlaceholderPage from "@/components/PlaceholderPage";

export default function Sorties() {
  return (
    <PlaceholderPage
      title="Nos Sorties du Moment"
      description="Découvrez nos offres et destinations du moment"
    />
  );
}
