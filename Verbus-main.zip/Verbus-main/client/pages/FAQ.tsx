import PlaceholderPage from "@/components/PlaceholderPage";

export default function FAQ() {
  return (
    <PlaceholderPage
      title="FAQ"
      description="Retrouvez les réponses aux questions fréquentes"
    />
  );
}
