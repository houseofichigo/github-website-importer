import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";

// Pages
import Index from "./pages/Index";
import Services from "./pages/Services";
import Vehicules from "./pages/Vehicules";
import ClasseAccess from "./pages/ClasseAccess";
import ClasseEco from "./pages/ClasseEco";
import ClasseConfort from "./pages/ClasseConfort";
import ClasseStar from "./pages/ClasseStar";
import Sorties from "./pages/Sorties";
import PourquoiVerbus from "./pages/PourquoiVerbus";
import NosMetiers from "./pages/NosMetiers";
import ModeVert from "./pages/ModeVert";
import Contact from "./pages/Contact";
import RejoindreVerbus from "./pages/RejoindreVerbus";
import GroupesScolaires from "./pages/GroupesScolaires";
import EvenementsProfessionnels from "./pages/EvenementsProfessionnels";
import Tourisme from "./pages/Tourisme";
import SportLoisirs from "./pages/SportLoisirs";
import Devis from "./pages/Devis";
import FAQ from "./pages/FAQ";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/services" element={<Services />} />
          <Route path="/vehicules" element={<Vehicules />} />
          <Route path="/classe-access" element={<ClasseAccess />} />
          <Route path="/classe-eco" element={<ClasseEco />} />
          <Route path="/classe-confort" element={<ClasseConfort />} />
          <Route path="/classe-star" element={<ClasseStar />} />
          <Route path="/sorties" element={<Sorties />} />
          <Route path="/pourquoi-verbus" element={<PourquoiVerbus />} />
          <Route path="/nos-metiers" element={<NosMetiers />} />
          <Route path="/mode-vert" element={<ModeVert />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/rejoindre-verbus" element={<RejoindreVerbus />} />
          <Route path="/groupes-scolaires" element={<GroupesScolaires />} />
          <Route
            path="/evenements-professionnels"
            element={<EvenementsProfessionnels />}
          />
          <Route path="/tourisme" element={<Tourisme />} />
          <Route path="/sport-loisirs" element={<SportLoisirs />} />
          <Route path="/devis" element={<Devis />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/voyage-sur-mesure" element={<Devis />} />
          <Route path="/notre-histoire" element={<PourquoiVerbus />} />
          {/* Catch-all route for 404 */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
